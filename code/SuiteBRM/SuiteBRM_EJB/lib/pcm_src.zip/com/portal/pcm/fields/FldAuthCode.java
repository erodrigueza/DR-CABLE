// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAuthCode extends StrField
{

    public FldAuthCode()
    {
        super(190, 5);
    }

    public static synchronized FldAuthCode getInst()
    {
        if(me == null)
            me = new FldAuthCode();
        return me;
    }

    private static FldAuthCode me;
    public static final int id = 190;
}
