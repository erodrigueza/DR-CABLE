// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCancelReasonId extends IntField
{

    public FldCancelReasonId()
    {
        super(6015, 1);
    }

    public static synchronized FldCancelReasonId getInst()
    {
        if(me == null)
            me = new FldCancelReasonId();
        return me;
    }

    private static FldCancelReasonId me;
    public static final int id = 6015;
}
