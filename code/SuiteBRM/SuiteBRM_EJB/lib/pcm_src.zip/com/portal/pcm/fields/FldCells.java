// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldCells extends ArrayField
{

    public FldCells()
    {
        super(1105, 9);
    }

    public static synchronized FldCells getInst()
    {
        if(me == null)
            me = new FldCells();
        return me;
    }

    private static FldCells me;
    public static final int id = 1105;
}
