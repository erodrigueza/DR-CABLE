// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:16 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldAcctinfo extends ArrayField
{

    public FldAcctinfo()
    {
        super(1554, 9);
    }

    public static synchronized FldAcctinfo getInst()
    {
        if(me == null)
            me = new FldAcctinfo();
        return me;
    }

    private static FldAcctinfo me;
    public static final int id = 1554;
}