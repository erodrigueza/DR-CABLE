// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldBytesDownlink extends DecimalField
{

    public FldBytesDownlink()
    {
        super(428, 14);
    }

    public static synchronized FldBytesDownlink getInst()
    {
        if(me == null)
            me = new FldBytesDownlink();
        return me;
    }

    private static FldBytesDownlink me;
    public static final int id = 428;
}
