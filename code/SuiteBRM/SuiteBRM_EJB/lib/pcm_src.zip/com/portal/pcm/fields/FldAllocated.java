// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldAllocated extends DecimalField
{

    public FldAllocated()
    {
        super(2426, 14);
    }

    public static synchronized FldAllocated getInst()
    {
        if(me == null)
            me = new FldAllocated();
        return me;
    }

    private static FldAllocated me;
    public static final int id = 2426;
}
