// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBankAccount extends StrField
{

    public FldBankAccount()
    {
        super(1052, 5);
    }

    public static synchronized FldBankAccount getInst()
    {
        if(me == null)
            me = new FldBankAccount();
        return me;
    }

    private static FldBankAccount me;
    public static final int id = 1052;
}
