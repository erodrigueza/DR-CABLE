// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAuditProcess extends StrField
{

    public FldAuditProcess()
    {
        super(8226, 5);
    }

    public static synchronized FldAuditProcess getInst()
    {
        if(me == null)
            me = new FldAuditProcess();
        return me;
    }

    private static FldAuditProcess me;
    public static final int id = 8226;
}
