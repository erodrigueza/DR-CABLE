// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldBatchId2 extends DecimalField
{

    public FldBatchId2()
    {
        super(9105, 14);
    }

    public static synchronized FldBatchId2 getInst()
    {
        if(me == null)
            me = new FldBatchId2();
        return me;
    }

    private static FldBatchId2 me;
    public static final int id = 9105;
}
