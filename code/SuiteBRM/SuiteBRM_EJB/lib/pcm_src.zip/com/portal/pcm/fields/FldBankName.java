// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBankName extends StrField
{

    public FldBankName()
    {
        super(1061, 5);
    }

    public static synchronized FldBankName getInst()
    {
        if(me == null)
            me = new FldBankName();
        return me;
    }

    private static FldBankName me;
    public static final int id = 1061;
}
