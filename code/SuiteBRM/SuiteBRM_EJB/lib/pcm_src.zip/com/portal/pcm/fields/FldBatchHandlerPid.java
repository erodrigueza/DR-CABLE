// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBatchHandlerPid extends IntField
{

    public FldBatchHandlerPid()
    {
        super(2606, 1);
    }

    public static synchronized FldBatchHandlerPid getInst()
    {
        if(me == null)
            me = new FldBatchHandlerPid();
        return me;
    }

    private static FldBatchHandlerPid me;
    public static final int id = 2606;
}
