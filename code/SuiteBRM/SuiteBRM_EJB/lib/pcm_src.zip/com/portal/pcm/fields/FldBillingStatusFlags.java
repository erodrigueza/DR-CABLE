// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBillingStatusFlags extends IntField
{

    public FldBillingStatusFlags()
    {
        super(288, 1);
    }

    public static synchronized FldBillingStatusFlags getInst()
    {
        if(me == null)
            me = new FldBillingStatusFlags();
        return me;
    }

    private static FldBillingStatusFlags me;
    public static final int id = 288;
}
