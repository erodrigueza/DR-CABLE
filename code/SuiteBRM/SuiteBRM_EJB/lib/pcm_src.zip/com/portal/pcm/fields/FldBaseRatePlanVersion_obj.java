// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBaseRatePlanVersion_obj extends PoidField
{

    public FldBaseRatePlanVersion_obj()
    {
        super(9845, 7);
    }

    public static synchronized FldBaseRatePlanVersion_obj getInst()
    {
        if(me == null)
            me = new FldBaseRatePlanVersion_obj();
        return me;
    }

    private static FldBaseRatePlanVersion_obj me;
    public static final int id = 9845;
}
