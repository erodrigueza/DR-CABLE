// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:15 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldAccounting extends SubStructField
{

    public FldAccounting()
    {
        super(225, 10);
    }

    public static synchronized FldAccounting getInst()
    {
        if(me == null)
            me = new FldAccounting();
        return me;
    }

    private static FldAccounting me;
    public static final int id = 225;
}