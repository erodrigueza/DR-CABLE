// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBasic extends IntField
{

    public FldBasic()
    {
        super(9666, 1);
    }

    public static synchronized FldBasic getInst()
    {
        if(me == null)
            me = new FldBasic();
        return me;
    }

    private static FldBasic me;
    public static final int id = 9666;
}
