// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

// Referenced classes of package com.portal.pcm:
//            PortalException, PortalConst, FList, PortalContext, 
//            PortalProperties, Field, PortalFacility, ErrorLog, 
//            LocalizedStringTable

public class EBufException extends PortalException
{

    public EBufException(int i, int j, int k, int l, int i1, int j1, String s, 
            FList flist, int k1, int l1, Date date, int i2, FList flist1, EBufException ebufexception, 
            int j2)
    {
        super(null);
        location = i;
        error = j;
        field = k;
        recordID = l;
        reserved = i1;
        line = j1;
        fileName = s;
        failData = flist;
        mFacility = k1;
        mMsgID = l1;
        mTime = date;
        mVersion = i2;
        mArgs = flist1;
        mChain = ebufexception;
        String s1 = PortalProperties.getSystemProperty("log.logallebuf");
        if(s1 != null && s1.trim().equalsIgnoreCase("true"))
            log();
    }

    public EBufException(int i, int j, int k, int l, int i1, int j1, Object obj)
    {
        this(i, j, k, l, i1, j1, obj.getClass().getName(), null, 0, 0, new Date(), 0, null, null, 0);
    }

    public EBufException(int i, int j, int k, int l, Object obj)
    {
        this(i, j, k, l, 0, 0, obj);
    }

    public EBufException(int i, int j, int k, Object obj)
    {
        this(0, i, j, k, 0, 0, obj);
    }

    public EBufException(int i, int j, Object obj)
    {
        this(i, j, 0, 0, 0, 0, obj);
    }

    public EBufException(int i, Object obj)
    {
        this(0, i, 0, 0, 0, 0, obj);
    }

    public String getMessage()
    {
        return getErrorString();
    }

    public int getLocation()
    {
        return location;
    }

    public String getLocationString()
    {
        String s = PortalProperties.getResource("pin.loc.maxloc");
        int i = Integer.parseInt(s);
        if(location < i && location >= 0)
            return PortalProperties.getResource((new StringBuilder()).append("pin.loc.").append(location).toString());
        else
            return PortalProperties.getResource("pin.loc.0");
    }

    public int getError()
    {
        return error;
    }

    public String getErrorString()
    {
        Field afield[];
        int i;
        afield = com/portal/pcm/PortalConst.getFields();
        i = afield.length - 1;
_L1:
        if(i < 0)
            break MISSING_BLOCK_LABEL_74;
        try
        {
            int j = afield[i].getInt(null);
            if(j == error)
            {
                String s = afield[i].getName();
                if(s.startsWith("ERR_"))
                    return s;
            }
        }
        catch(IllegalAccessException illegalaccessexception) { }
        catch(IllegalArgumentException illegalargumentexception) { }
        i--;
          goto _L1
        SecurityException securityexception;
        securityexception;
        return null;
    }

    public String getDetailedErrorString(PortalContext portalcontext, Locale locale)
    {
        if(error == 83)
        {
            loadDetailedInfo(portalcontext, locale);
            if(mMsgStringInfo != null)
                return mFormattedDetailedMessage;
        }
        return null;
    }

    public String getDetailedHelpString(PortalContext portalcontext, Locale locale)
    {
        if(error == 83)
        {
            loadDetailedInfo(portalcontext, locale);
            if(mMsgStringInfo != null)
                return mMsgStringInfo.mHelpText;
        }
        return null;
    }

    public int getField()
    {
        return field;
    }

    public String getFieldString()
    {
        return Field.getNameString(field);
    }

    public int getRecordID()
    {
        return recordID;
    }

    public int getReserved()
    {
        return reserved;
    }

    public int getLine()
    {
        return line;
    }

    public String getFileName()
    {
        return fileName;
    }

    public int getFacility()
    {
        return mFacility;
    }

    public String getFacilityString()
    {
        return PortalFacility.facilityToString(getFacility());
    }

    public int getMessageID()
    {
        return mMsgID;
    }

    public Date getErrorTime()
    {
        return mTime;
    }

    public int getVersion()
    {
        return mVersion;
    }

    public int getReserved2()
    {
        return mReserved2;
    }

    public FList getArgsFList()
    {
        return mArgs;
    }

    public EBufException getNestedError()
    {
        return mChain;
    }

    public void log()
    {
        ErrorLog errorlog = ErrorLog.getDefaultLog();
        log(errorlog);
    }

    public void log(ErrorLog errorlog)
    {
        try
        {
            errorlog.log("EBufException thrown", 2, this);
        }
        catch(IOException ioexception) { }
    }

    public FList getOpcodeFList()
    {
        return failData;
    }

    void setOpcodeFList(FList flist)
    {
        failData = flist;
    }

    public String toString()
    {
        String s = getMessage();
        StringBuffer stringbuffer = new StringBuffer(s != null ? s : "");
        if(mDateFormat == null)
            synchronized(java/text/DateFormat)
            {
                if(mDateFormat == null)
                    mDateFormat = DateFormat.getTimeInstance(3);
            }
        stringbuffer.append("\n").append(fileName).append(":").append(line);
        stringbuffer.append(": ErrBuf Fields:\n");
        stringbuffer.append("Error=").append(getErrorString());
        stringbuffer.append("    Loc=").append(getLocationString());
        stringbuffer.append("\nField=").append(Field.getNameString(field));
        stringbuffer.append("    Rec=").append(recordID);
        stringbuffer.append("    reserved=").append(reserved);
        stringbuffer.append("\nFacility=").append(mFacility);
        stringbuffer.append("    MessageID=").append(mMsgID);
        stringbuffer.append("    Time=");
        String s1 = "";
        synchronized(mDateFormat)
        {
            s1 = mDateFormat.format(mTime);
        }
        stringbuffer.append(s1);
        stringbuffer.append("    Version=").append(mVersion);
        stringbuffer.append("    Reserved2=").append(mReserved2);
        stringbuffer.append("\nArgs=");
        if(mArgs != null)
            stringbuffer.append(mArgs.toString());
        else
            stringbuffer.append("<none>");
        stringbuffer.append("\nNested Error:\n");
        if(mChain == null)
            stringbuffer.append("<none>\n");
        else
            stringbuffer.append(mChain.toString());
        return stringbuffer.toString();
    }

    private LocalizedStringTable.Entry getLocalizedErrorMessage(PortalContext portalcontext, String s)
    {
        String s1 = getFacilityString();
        LocalizedStringTable.Entry entry = null;
        if(s1 == null)
            s1 = new String("Errors");
        entry = LocalizedStringTable.getInstance().lookupEntry(portalcontext, s1, s, mMsgID, mVersion);
        if(entry == null && !s1.equals("Errors"))
            entry = LocalizedStringTable.getInstance().lookupEntry(portalcontext, "Errors", s, mMsgID, mVersion);
        return entry;
    }

    private void loadDetailedInfo(PortalContext portalcontext, Locale locale)
    {
        if(error == 83 && mMsgStringInfo == null)
        {
            StringBuffer stringbuffer = new StringBuffer(locale.getLanguage());
            String s = locale.getCountry();
            if(s != null && s.length() > 0)
                stringbuffer.append("_").append(s);
            String s1 = stringbuffer.toString();
            mMsgStringInfo = getLocalizedErrorMessage(portalcontext, s1);
            if(mMsgStringInfo == null)
                return;
            int i = mMsgStringInfo.mMessage.indexOf("%");
            if(i != -1 && mArgs != null)
            {
                StringBuffer stringbuffer1 = new StringBuffer();
                boolean flag = false;
                int k = 0;
                String s2 = mMsgStringInfo.mMessage;
                for(int j = s2.indexOf("%"); j != -1; j = s2.indexOf("%", j + 1))
                {
                    if(s2.charAt(j - 1) == '\\')
                        continue;
                    stringbuffer1.append(s2.substring(k, j));
                    if(Character.isDigit(s2.charAt(j + 1)))
                    {
                        int l = 1;
                        if(Character.isDigit(s2.charAt(j + 2)))
                            l++;
                        String s3 = s2.substring(j + 1, j + l + 1);
                        j += l;
                        k = j + 1;
                        int i1 = 0;
                        try
                        {
                            i1 = Integer.parseInt(s3);
                        }
                        catch(NumberFormatException numberformatexception) { }
                    } else
                    {
                        k = j;
                    }
                }

                stringbuffer1.append(s2.substring(k));
                mFormattedDetailedMessage = stringbuffer1.toString();
            } else
            {
                mFormattedDetailedMessage = mMsgStringInfo.mMessage;
            }
        }
    }

    private int location;
    private int error;
    private int field;
    private int recordID;
    private int reserved;
    private int line;
    private String fileName;
    private FList failData;
    private int mFacility;
    private int mMsgID;
    private Date mTime;
    private int mVersion;
    private int mReserved2;
    private FList mArgs;
    private EBufException mChain;
    private LocalizedStringTable.Entry mMsgStringInfo;
    private String mFormattedDetailedMessage;
    private static DateFormat mDateFormat;
}