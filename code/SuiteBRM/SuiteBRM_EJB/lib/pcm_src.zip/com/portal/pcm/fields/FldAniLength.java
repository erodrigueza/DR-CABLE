// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldAniLength extends IntField
{

    public FldAniLength()
    {
        super(2517, 1);
    }

    public static synchronized FldAniLength getInst()
    {
        if(me == null)
            me = new FldAniLength();
        return me;
    }

    private static FldAniLength me;
    public static final int id = 2517;
}
