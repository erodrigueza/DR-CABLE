// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldCall extends SubStructField
{

    public FldCall()
    {
        super(1561, 10);
    }

    public static synchronized FldCall getInst()
    {
        if(me == null)
            me = new FldCall();
        return me;
    }

    private static FldCall me;
    public static final int id = 1561;
}
