// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.*;

public abstract class Buffer
{

    protected Buffer(int i, boolean flag)
    {
        offset = i;
        read = flag;
    }

    protected Buffer()
    {
        this(0, false);
    }

    public int getOffset()
    {
        return offset;
    }

    public void setOffset(int i)
    {
        offset = i;
    }

    public boolean isReadBuffer()
    {
        return read;
    }

    public void setReadFlag(boolean flag)
    {
        read = flag;
    }

    public abstract long getSize();

    public abstract InputStream getInputStream()
        throws IOException;

    public abstract OutputStream getOutputStream()
        throws IOException;

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        try
        {
            InputStreamReader inputstreamreader = new InputStreamReader(getInputStream(), "UTF-8");
            int i;
            while((i = inputstreamreader.read()) != -1) 
                stringbuffer.append((char)i);
        }
        catch(Exception exception) { }
        return stringbuffer.toString();
    }

    private int offset;
    private boolean read;
}