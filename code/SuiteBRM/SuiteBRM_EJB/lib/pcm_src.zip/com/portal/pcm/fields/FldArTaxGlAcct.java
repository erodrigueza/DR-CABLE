// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldArTaxGlAcct extends StrField
{

    public FldArTaxGlAcct()
    {
        super(1819, 5);
    }

    public static synchronized FldArTaxGlAcct getInst()
    {
        if(me == null)
            me = new FldArTaxGlAcct();
        return me;
    }

    private static FldArTaxGlAcct me;
    public static final int id = 1819;
}
