// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import oracle.jdbc.pool.OracleDataSource;

// Referenced classes of package com.portal.pcm:
//            Crypt

public class DatabaseConnection
{

    public DatabaseConnection()
    {
    }

    public static Connection createOracleConnection(String s, String s1, String s2)
        throws Exception
    {
        OracleDataSource oracledatasource = new OracleDataSource();
        String s3 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s3 = Crypt.decryptPassword(s1);
        oracledatasource.setURL((new StringBuilder()).append("jdbc:oracle:oci8:@").append(s2).toString());
        oracledatasource.setUser(s);
        oracledatasource.setPassword(s3);
        Connection connection = oracledatasource.getConnection();
        return connection;
    }

    public static Connection createOracleThinConnection(String s, String s1, String s2, String s3, String s4)
        throws Exception
    {
        OracleDataSource oracledatasource = new OracleDataSource();
        String s5 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s5 = Crypt.decryptPassword(s1);
        oracledatasource.setURL((new StringBuilder()).append("jdbc:oracle:thin:@").append(s2).append(":").append(s3).append(":").append(s4).toString());
        oracledatasource.setUser(s);
        oracledatasource.setPassword(s5);
        Connection connection = oracledatasource.getConnection();
        return connection;
    }

    public static Process exec_sql_cmd(String s, String s1)
        throws Exception
    {
        String s2 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s2 = Crypt.decryptPassword(s1);
        String s3 = s.replaceAll("PASSWORD", s2);
        return Runtime.getRuntime().exec(s3);
    }

    public static Process exec_sql_cmd(String s, String as[], String s1)
        throws Exception
    {
        String s2 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s2 = Crypt.decryptPassword(s1);
        String s3 = s.replaceAll("PASSWORD", s2);
        return Runtime.getRuntime().exec(s3, as);
    }

    public static Process exec_sql_cmd(String s, String as[], File file, String s1)
        throws Exception
    {
        String s2 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s2 = Crypt.decryptPassword(s1);
        String s3 = s.replaceAll("PASSWORD", s2);
        return Runtime.getRuntime().exec(s3, as, file);
    }

    public static Connection createTimesTenConnection(String s, String s1, String s2)
        throws Exception
    {
        String s3 = (new StringBuilder()).append("jdbc:timesten:client:DSN=").append(s2).toString();
        Class.forName("com.timesten.jdbc.TimesTenDriver");
        String s4 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s4 = Crypt.decryptPassword(s1);
        Connection connection = DriverManager.getConnection(s3, s, s4);
        return connection;
    }

    public static Connection createTimesTenConnection(String s, String s1, String s2, String s3)
        throws Exception
    {
        String s4 = (new StringBuilder()).append("jdbc:timesten:client:DSN=").append(s2).toString();
        Class.forName("com.timesten.jdbc.TimesTenDriver");
        String s5 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s5 = Crypt.decryptPassword(s1);
        String s6 = s3;
        if(s3.length() > 5 && "&aes|".compareTo(s3.substring(0, 5)) == 0)
            s6 = Crypt.decryptPassword(s3);
        String s7 = (new StringBuilder()).append(s5).append(";OraclePwd=").append(s6).toString();
        Connection connection = DriverManager.getConnection(s4, s, s7);
        return connection;
    }

    public static Connection createSqlserverConnection(String s, String s1, String s2, String s3, String s4)
        throws Exception
    {
        String s5 = (new StringBuilder()).append("jdbc:microsoft:sqlserver://").append(s3).append(":").append(s4).append(";databaseName=").append(s2).append(";selectMethod=").append("cursor").append(";").toString();
        Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver").newInstance();
        String s6 = s1;
        if(s1.length() > 5 && "&aes|".compareTo(s1.substring(0, 5)) == 0)
            s6 = Crypt.decryptPassword(s1);
        Connection connection = DriverManager.getConnection(s5, s, s6);
        return connection;
    }

    public static final String TIMESTEN_DRIVER = "com.timesten.jdbc.TimesTenDriver";
    public static final String TIMESTENDSNPREFIX = "jdbc:timesten:client:DSN=";
    public static final String SQLSERVER_DRIVER = "com.microsoft.jdbc.sqlserver.SQLServerDriver";
    public static final String SQLSERVER_URL = "jdbc:microsoft:sqlserver://";
    public static final String SQLSERVER_SELECTMETHOD = "cursor";
    private static final String ORACLE_OCI_CLIENT_URL = "jdbc:oracle:oci8:@";
    private static final String ORACLE_THIN_CLIENT_URL = "jdbc:oracle:thin:@";

    static 
    {
        System.loadLibrary("portal");
    }
}