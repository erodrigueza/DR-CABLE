// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.*;

// Referenced classes of package com.portal.pcm:
//            ErrorLog

public class DefaultLog
{

    public DefaultLog()
    {
    }

    public static void setName(String s)
    {
        ErrorLog.getDefaultLog().setName(s);
    }

    public static void setPath(String s)
    {
        ErrorLog.getDefaultLog().setPath(s);
    }

    public static void setWriter(Writer writer)
    {
        ErrorLog.getDefaultLog().setWriter(writer);
    }

    public static void setFlags(int i)
    {
        ErrorLog.getDefaultLog().setFlags(i);
    }

    public static void log(String s)
    {
        try
        {
            ErrorLog.getDefaultLog().log(s);
        }
        catch(IOException ioexception) { }
    }

    public static void log(Object obj, String s)
    {
        try
        {
            ErrorLog.getDefaultLog().log(obj, s);
        }
        catch(IOException ioexception) { }
    }

    public static void log(int i, String s)
    {
        try
        {
            ErrorLog.getDefaultLog().log(i, s);
        }
        catch(IOException ioexception) { }
    }

    public static void log(Object obj, int i, Throwable throwable)
    {
        try
        {
            ErrorLog.getDefaultLog().log(obj, i, throwable);
        }
        catch(IOException ioexception) { }
    }

    public static void log(Object obj, int i, String s, byte abyte0[])
    {
        try
        {
            ErrorLog.getDefaultLog().log(obj, i, s, abyte0);
        }
        catch(IOException ioexception) { }
    }

    public static void log(Object obj, int i, String s, byte abyte0[], int j, int k)
    {
        try
        {
            ErrorLog.getDefaultLog().log(obj, i, s, abyte0, j, k);
        }
        catch(IOException ioexception) { }
    }

    public static void log(Object obj, int i, String s)
    {
        try
        {
            ErrorLog.getDefaultLog().log(obj, i, s);
        }
        catch(IOException ioexception) { }
    }

    public static InputStream getLog()
    {
        try
        {
            return ErrorLog.getDefaultLog().getLog();
        }
        catch(IOException ioexception)
        {
            return null;
        }
    }

    public static boolean isLogInMemory()
    {
        return ErrorLog.getDefaultLog().isLogInMemory();
    }

    public static boolean doLog(int i)
    {
        return ErrorLog.getDefaultLog().doLog(i);
    }
}