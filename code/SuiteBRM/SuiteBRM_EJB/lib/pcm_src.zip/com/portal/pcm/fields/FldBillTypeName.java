// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBillTypeName extends StrField
{

    public FldBillTypeName()
    {
        super(1420, 5);
    }

    public static synchronized FldBillTypeName getInst()
    {
        if(me == null)
            me = new FldBillTypeName();
        return me;
    }

    private static FldBillTypeName me;
    public static final int id = 1420;
}
