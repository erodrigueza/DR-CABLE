// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBaseRatePlanObj extends PoidField
{

    public FldBaseRatePlanObj()
    {
        super(9844, 7);
    }

    public static synchronized FldBaseRatePlanObj getInst()
    {
        if(me == null)
            me = new FldBaseRatePlanObj();
        return me;
    }

    private static FldBaseRatePlanObj me;
    public static final int id = 9844;
}
