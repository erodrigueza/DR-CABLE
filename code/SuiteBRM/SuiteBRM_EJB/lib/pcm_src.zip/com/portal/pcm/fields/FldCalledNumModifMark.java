// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldCalledNumModifMark extends EnumField
{

    public FldCalledNumModifMark()
    {
        super(6402, 3);
    }

    public static synchronized FldCalledNumModifMark getInst()
    {
        if(me == null)
            me = new FldCalledNumModifMark();
        return me;
    }

    private static FldCalledNumModifMark me;
    public static final int id = 6402;
}
