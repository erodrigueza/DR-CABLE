// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldAggregateMode extends EnumField
{

    public FldAggregateMode()
    {
        super(6433, 3);
    }

    public static synchronized FldAggregateMode getInst()
    {
        if(me == null)
            me = new FldAggregateMode();
        return me;
    }

    private static FldAggregateMode me;
    public static final int id = 6433;
}
