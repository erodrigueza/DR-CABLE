// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldArBillObj extends PoidField
{

    public FldArBillObj()
    {
        super(796, 7);
    }

    public static synchronized FldArBillObj getInst()
    {
        if(me == null)
            me = new FldArBillObj();
        return me;
    }

    private static FldArBillObj me;
    public static final int id = 796;
}
