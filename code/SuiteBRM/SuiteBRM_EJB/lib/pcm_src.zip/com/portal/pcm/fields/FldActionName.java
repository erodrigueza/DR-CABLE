// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldActionName extends StrField
{

    public FldActionName()
    {
        super(1852, 5);
    }

    public static synchronized FldActionName getInst()
    {
        if(me == null)
            me = new FldActionName();
        return me;
    }

    private static FldActionName me;
    public static final int id = 1852;
}
