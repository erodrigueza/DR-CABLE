// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBillingRao extends StrField
{

    public FldBillingRao()
    {
        super(2521, 5);
    }

    public static synchronized FldBillingRao getInst()
    {
        if(me == null)
            me = new FldBillingRao();
        return me;
    }

    private static FldBillingRao me;
    public static final int id = 2521;
}
