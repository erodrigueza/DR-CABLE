// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBrandName extends StrField
{

    public FldBrandName()
    {
        super(1832, 5);
    }

    public static synchronized FldBrandName getInst()
    {
        if(me == null)
            me = new FldBrandName();
        return me;
    }

    private static FldBrandName me;
    public static final int id = 1832;
}
