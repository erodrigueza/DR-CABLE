// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:15 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAccessCode1 extends StrField
{

    public FldAccessCode1()
    {
        super(104, 5);
    }

    public static synchronized FldAccessCode1 getInst()
    {
        if(me == null)
            me = new FldAccessCode1();
        return me;
    }

    private static FldAccessCode1 me;
    public static final int id = 104;
}