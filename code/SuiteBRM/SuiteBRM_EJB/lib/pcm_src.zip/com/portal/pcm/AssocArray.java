// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.util.*;

public class AssocArray extends Dictionary
{
    public class PairEnumeration
        implements Enumeration
    {

        public boolean hasMoreElements()
        {
            return index < keys.size();
        }

        public Object nextElement()
        {
            Pair pair = new Pair(keys.elementAt(index), values.elementAt(index));
            index++;
            return pair;
        }

        public Pair nextPair()
        {
            return (Pair)nextElement();
        }

        private int index;
        final AssocArray this$0;

        PairEnumeration()
        {
            this$0 = AssocArray.this;
            super();
            index = 0;
        }
    }

    public class Pair
    {

        public Object key()
        {
            return key;
        }

        public Object value()
        {
            return value;
        }

        private Object key;
        private Object value;
        final AssocArray this$0;

        Pair(Object obj, Object obj1)
        {
            this$0 = AssocArray.this;
            super();
            key = obj;
            value = obj1;
        }
    }


    public AssocArray()
    {
        keys = new Vector(20);
        values = new Vector(20);
    }

    public Enumeration elements()
    {
        return values.elements();
    }

    public Object get(Object obj)
    {
        int i = keys.indexOf(obj);
        if(i >= 0)
            return values.elementAt(i);
        else
            return null;
    }

    public boolean isEmpty()
    {
        return keys.isEmpty();
    }

    public Enumeration keys()
    {
        return keys.elements();
    }

    public Object put(Object obj, Object obj1)
        throws NullPointerException
    {
        if(obj == null || obj1 == null)
            throw new NullPointerException();
        int i = keys.indexOf(obj);
        if(i == -1)
        {
            keys.addElement(obj);
            values.addElement(obj1);
            return null;
        }
        if(Integer.parseInt(obj.toString()) == -2)
        {
            keys.addElement(obj);
            values.addElement(obj1);
            Object obj2 = values.elementAt(i);
            return obj2;
        } else
        {
            Object obj3 = values.elementAt(i);
            values.setElementAt(obj1, i);
            return obj3;
        }
    }

    public Object remove(Object obj)
    {
        int i = keys.indexOf(obj);
        if(i == -1)
        {
            return null;
        } else
        {
            Object obj1 = values.elementAt(i);
            keys.removeElementAt(i);
            values.removeElementAt(i);
            return obj1;
        }
    }

    public int size()
    {
        return keys.size();
    }

    public void clear()
    {
        keys.removeAllElements();
        values.removeAllElements();
    }

    public boolean containsKey(Object obj)
    {
        return keys.indexOf(obj) >= 0;
    }

    public PairEnumeration getPairs()
    {
        return new PairEnumeration();
    }

    private Vector keys;
    private Vector values;


}