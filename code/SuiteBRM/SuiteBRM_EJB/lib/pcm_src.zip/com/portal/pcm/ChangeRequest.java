// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.nio.channels.SocketChannel;

class ChangeRequest
{

    public ChangeRequest(SocketChannel socketchannel, int i, int j)
    {
        socketChannel = socketchannel;
        type = i;
        ops = j;
    }

    public ChangeRequest(SocketChannel socketchannel, int i)
    {
        this(socketchannel, 2, i);
    }

    public static final int REGISTER = 1;
    public static final int CHANGEOPS = 2;
    public SocketChannel socketChannel;
    public int type;
    public int ops;
}