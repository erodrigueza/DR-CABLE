// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldClassName extends StrField
{

    public FldClassName()
    {
        super(9885, 5);
    }

    public static synchronized FldClassName getInst()
    {
        if(me == null)
            me = new FldClassName();
        return me;
    }

    private static FldClassName me;
    public static final int id = 9885;
}
