// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBusinessProfileObj extends PoidField
{

    public FldBusinessProfileObj()
    {
        super(151, 7);
    }

    public static synchronized FldBusinessProfileObj getInst()
    {
        if(me == null)
            me = new FldBusinessProfileObj();
        return me;
    }

    private static FldBusinessProfileObj me;
    public static final int id = 151;
}
