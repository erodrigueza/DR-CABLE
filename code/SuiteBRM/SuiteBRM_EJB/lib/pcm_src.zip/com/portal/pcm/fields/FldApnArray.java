// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldApnArray extends ArrayField
{

    public FldApnArray()
    {
        super(3054, 9);
    }

    public static synchronized FldApnArray getInst()
    {
        if(me == null)
            me = new FldApnArray();
        return me;
    }

    private static FldApnArray me;
    public static final int id = 3054;
}
