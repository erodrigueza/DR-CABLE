// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:11 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Referenced classes of package com.portal.pcm:
//            IntField, UIntField, EnumField, NumField, 
//            StrField, BufField, PoidField, TStampField, 
//            ArrayField, SubStructField, ObjField, BinStrField, 
//            ErrField, DecimalField, TimeField, TextBufField, 
//            PortalProperties

public class Field
    implements Cloneable, Serializable
{

    public Field(int i, int j)
    {
        nameType = (j & 0xff) << 24 | i & 0xffffff;
        cache();
    }

    Field(int i)
    {
        nameType = i;
        cache();
    }

    private void cache()
    {
        Field field = (Field)mFieldCache.get(new Integer(nameType));
        if(field == null)
        {
            mFieldCache.put(getClass().getName(), this);
            mFieldCache.put(new Integer(nameType), this);
        }
    }

    public static Field fromPINName(String s)
    {
        if(s.indexOf(".") != -1)
            return fromName(s);
        else
            return fromName(macroToClass(s));
    }

    public static Field fromName(String s)
    {
        String s1;
        s1 = null;
        Object obj = null;
        Object obj1 = null;
        if(s.indexOf(".") == -1)
        {
            s1 = (new StringBuilder()).append("com.portal.pcm.fields.").append(s).toString();
            break MISSING_BLOCK_LABEL_67;
        }
        if(s.startsWith("UnknownField"))
        {
            int i = Integer.parseInt(s.substring(12));
            return fromName(i);
        }
        s1 = s;
        Field field = (Field)mFieldCache.get(s1);
        if(field != null)
            return field;
        String s2;
        Class class1;
        Method method;
        Field field2;
        try
        {
            String s4 = PortalProperties.getSystemProperty("custom.field.package");
            if(s4 != null)
                s2 = (new StringBuilder()).append(s4).append(".").append(s).toString();
            else
                s2 = s;
            Field field1 = (Field)mFieldCache.get(s2);
            if(field1 != null)
                return field1;
        }
        catch(Exception exception)
        {
            return null;
        }
        class1 = null;
        try
        {
            class1 = Class.forName(s1);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            try
            {
                class1 = Class.forName(s2);
            }
            catch(ClassNotFoundException classnotfoundexception1)
            {
                String s3 = s;
                class1 = Class.forName(s3);
            }
        }
        method = class1.getMethod("getInst", new Class[0]);
        field2 = (Field)method.invoke(null, null);
        return field2;
    }

    public static Field fromName(int i)
    {
        Field field = (Field)mFieldCache.get(new Integer(i));
        if(field != null)
            return field;
        String s = getNameString(i);
        if(s != null)
        {
            Field field1 = fromPINName(s);
            if(field1 != null)
                return field1;
        }
        int j = i & 0xffffff;
        int k = i >> 24;
        Object obj = null;
        switch(k)
        {
        case 1: // '\001'
            return new IntField(j, k);

        case 2: // '\002'
            return new UIntField(j, k);

        case 3: // '\003'
            return new EnumField(j, k);

        case 4: // '\004'
            return new NumField(j, k);

        case 5: // '\005'
            return new StrField(j, k);

        case 6: // '\006'
            return new BufField(j, k);

        case 7: // '\007'
            return new PoidField(j, k);

        case 8: // '\b'
            return new TStampField(j, k);

        case 9: // '\t'
            return new ArrayField(j, k);

        case 10: // '\n'
            return new SubStructField(j, k);

        case 11: // '\013'
            return new ObjField(j, k);

        case 12: // '\f'
            return new BinStrField(j, k);

        case 13: // '\r'
            return new ErrField(j, k);

        case 14: // '\016'
            return new DecimalField(j, k);

        case 15: // '\017'
            return new TimeField(j, k);

        case 16: // '\020'
            return new TextBufField(j, k);
        }
        return null;
    }

    public Object clone()
        throws CloneNotSupportedException
    {
        return super.clone();
    }

    public int getTypeID()
    {
        return nameType >> 24;
    }

    public int getNameID()
    {
        return nameType & 0xffffff;
    }

    public int getName()
    {
        return nameType;
    }

    public String getNameString()
    {
        return getNameString(getNameID());
    }

    public static String getNameString(int i)
    {
        String s = PortalProperties.getProperty((new StringBuilder()).append("pin.field.").append(i & 0xffffff).toString());
        if(s != null)
            return s;
        else
            return makeName(i);
    }

    private static String makeName(int i)
    {
        int j = i & 0xffffff;
        String s = PortalProperties.getSystemProperty((new StringBuilder()).append("custom.field.").append(j).toString());
        if(s != null)
        {
            int k = s.lastIndexOf(".");
            return s.substring(k + 1);
        } else
        {
            return (new StringBuilder()).append("UnknownField").append(i).toString();
        }
    }

    private static String classToMacro(String s)
    {
        StringBuffer stringbuffer = new StringBuffer();
        char ac[] = s.toCharArray();
        for(int i = 0; i < ac.length; i++)
        {
            if(Character.isUpperCase(ac[i]) && i > 0)
                stringbuffer.append("_");
            stringbuffer.append(Character.toUpperCase(ac[i]));
        }

        return stringbuffer.toString();
    }

    public static String macroToClass(String s)
    {
        if(s == null)
            return null;
        char ac[] = null;
        if(s.startsWith("PIN_"))
            ac = s.substring(4).toCharArray();
        else
            ac = s.toCharArray();
        boolean flag = true;
        int i = 0;
        for(int j = 0; j < ac.length; j++)
        {
            if(flag)
            {
                ac[i] = Character.toUpperCase(ac[j]);
                flag = false;
                i++;
                continue;
            }
            ac[i] = Character.toLowerCase(ac[j]);
            if(ac[j] == '_')
                flag = true;
            else
                i++;
        }

        return new String(ac, 0, i);
    }

    public String getPINType()
    {
        int i = getTypeID();
        return typeStrings[i];
    }

    public int hashCode()
    {
        return nameType;
    }

    public boolean equals(Object obj)
    {
        if(obj instanceof Field)
            return nameType == ((Field)obj).getName();
        else
            return false;
    }

    public String toString()
    {
        return (new StringBuilder()).append(macroToClass(getNameString())).append("(").append(getNameID()).append(") : ").append(getPINType()).toString();
    }

    public static final int TYPE_UNUSED = 0;
    public static final int TYPE_INT = 1;
    public static final int TYPE_UINT = 2;
    public static final int TYPE_ENUM = 3;
    public static final int TYPE_NUM = 4;
    public static final int TYPE_STR = 5;
    public static final int TYPE_BUF = 6;
    public static final int TYPE_POID = 7;
    public static final int TYPE_TSTAMP = 8;
    public static final int TYPE_ARRAY = 9;
    public static final int TYPE_SUBSTRUCT = 10;
    public static final int TYPE_OBJ = 11;
    public static final int TYPE_BINSTR = 12;
    public static final int TYPE_ERR = 13;
    public static final int TYPE_DECIMAL = 14;
    public static final int TYPE_TIME = 15;
    public static final int TYPE_TEXTBUF = 16;
    private int nameType;
    private static Map mFieldCache = new ConcurrentHashMap();
    private static String typeStrings[];

    static 
    {
        typeStrings = new String[17];
        typeStrings[0] = "PIN_FLDT_UNUSED";
        typeStrings[1] = "PIN_FLDT_INT";
        typeStrings[2] = "PIN_FLDT_UINT";
        typeStrings[3] = "PIN_FLDT_ENUM";
        typeStrings[4] = "PIN_FLDT_NUM";
        typeStrings[5] = "PIN_FLDT_STR";
        typeStrings[6] = "PIN_FLDT_BUF";
        typeStrings[7] = "PIN_FLDT_POID";
        typeStrings[8] = "PIN_FLDT_TSTAMP";
        typeStrings[9] = "PIN_FLDT_ARRAY";
        typeStrings[10] = "PIN_FLDT_SUBSTRUCT";
        typeStrings[11] = "PIN_FLDT_OBJ";
        typeStrings[12] = "PIN_FLDT_BINSTR";
        typeStrings[13] = "PIN_FLDT_ERR";
        typeStrings[14] = "PIN_FLDT_DECIMAL";
        typeStrings[15] = "PIN_FLDT_TIME";
        typeStrings[16] = "PIN_FLDT_TEXTBUF";
    }
}