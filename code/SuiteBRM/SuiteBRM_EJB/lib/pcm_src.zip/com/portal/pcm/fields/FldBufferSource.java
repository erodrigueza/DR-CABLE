// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.BufField;

public class FldBufferSource extends BufField
{

    public FldBufferSource()
    {
        super(1568, 6);
    }

    public static synchronized FldBufferSource getInst()
    {
        if(me == null)
            me = new FldBufferSource();
        return me;
    }

    private static FldBufferSource me;
    public static final int id = 1568;
}
