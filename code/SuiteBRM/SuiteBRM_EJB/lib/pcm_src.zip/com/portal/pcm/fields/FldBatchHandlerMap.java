// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBatchHandlerMap extends ArrayField
{

    public FldBatchHandlerMap()
    {
        super(2607, 9);
    }

    public static synchronized FldBatchHandlerMap getInst()
    {
        if(me == null)
            me = new FldBatchHandlerMap();
        return me;
    }

    private static FldBatchHandlerMap me;
    public static final int id = 2607;
}
