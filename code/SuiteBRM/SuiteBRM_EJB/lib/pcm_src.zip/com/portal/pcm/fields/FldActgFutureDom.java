// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldActgFutureDom extends IntField
{

    public FldActgFutureDom()
    {
        super(753, 1);
    }

    public static synchronized FldActgFutureDom getInst()
    {
        if(me == null)
            me = new FldActgFutureDom();
        return me;
    }

    private static FldActgFutureDom me;
    public static final int id = 753;
}
