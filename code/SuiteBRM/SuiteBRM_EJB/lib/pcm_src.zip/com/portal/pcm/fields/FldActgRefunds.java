// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldActgRefunds extends DecimalField
{

    public FldActgRefunds()
    {
        super(222, 14);
    }

    public static synchronized FldActgRefunds getInst()
    {
        if(me == null)
            me = new FldActgRefunds();
        return me;
    }

    private static FldActgRefunds me;
    public static final int id = 222;
}
