// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBills extends ArrayField
{

    public FldBills()
    {
        super(794, 9);
    }

    public static synchronized FldBills getInst()
    {
        if(me == null)
            me = new FldBills();
        return me;
    }

    private static FldBills me;
    public static final int id = 794;
}
