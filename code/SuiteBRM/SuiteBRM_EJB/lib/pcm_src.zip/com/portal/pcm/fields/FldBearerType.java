// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBearerType extends StrField
{

    public FldBearerType()
    {
        super(2901, 5);
    }

    public static synchronized FldBearerType getInst()
    {
        if(me == null)
            me = new FldBearerType();
        return me;
    }

    private static FldBearerType me;
    public static final int id = 2901;
}
