// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldChargeshareFlag extends StrField
{

    public FldChargeshareFlag()
    {
        super(7816, 5);
    }

    public static synchronized FldChargeshareFlag getInst()
    {
        if(me == null)
            me = new FldChargeshareFlag();
        return me;
    }

    private static FldChargeshareFlag me;
    public static final int id = 7816;
}
