// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.TStampField;

public class FldActgLastT extends TStampField
{

    public FldActgLastT()
    {
        super(756, 8);
    }

    public static synchronized FldActgLastT getInst()
    {
        if(me == null)
            me = new FldActgLastT();
        return me;
    }

    private static FldActgLastT me;
    public static final int id = 756;
}
