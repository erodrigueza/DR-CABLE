// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldChargeBase extends IntField
{

    public FldChargeBase()
    {
        super(9698, 1);
    }

    public static synchronized FldChargeBase getInst()
    {
        if(me == null)
            me = new FldChargeBase();
        return me;
    }

    private static FldChargeBase me;
    public static final int id = 9698;
}
