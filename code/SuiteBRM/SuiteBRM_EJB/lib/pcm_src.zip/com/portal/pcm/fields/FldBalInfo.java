// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBalInfo extends ArrayField
{

    public FldBalInfo()
    {
        super(7789, 9);
    }

    public static synchronized FldBalInfo getInst()
    {
        if(me == null)
            me = new FldBalInfo();
        return me;
    }

    private static FldBalInfo me;
    public static final int id = 7789;
}
