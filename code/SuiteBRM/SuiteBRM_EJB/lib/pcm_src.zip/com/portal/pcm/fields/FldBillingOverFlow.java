// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBillingOverFlow extends StrField
{

    public FldBillingOverFlow()
    {
        super(2503, 5);
    }

    public static synchronized FldBillingOverFlow getInst()
    {
        if(me == null)
            me = new FldBillingOverFlow();
        return me;
    }

    private static FldBillingOverFlow me;
    public static final int id = 2503;
}
