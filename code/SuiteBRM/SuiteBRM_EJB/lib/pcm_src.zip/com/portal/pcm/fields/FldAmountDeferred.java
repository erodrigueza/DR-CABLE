// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldAmountDeferred extends DecimalField
{

    public FldAmountDeferred()
    {
        super(539, 14);
    }

    public static synchronized FldAmountDeferred getInst()
    {
        if(me == null)
            me = new FldAmountDeferred();
        return me;
    }

    private static FldAmountDeferred me;
    public static final int id = 539;
}
