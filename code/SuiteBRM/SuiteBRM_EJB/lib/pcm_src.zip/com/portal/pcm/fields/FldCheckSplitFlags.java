// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCheckSplitFlags extends IntField
{

    public FldCheckSplitFlags()
    {
        super(8232, 1);
    }

    public static synchronized FldCheckSplitFlags getInst()
    {
        if(me == null)
            me = new FldCheckSplitFlags();
        return me;
    }

    private static FldCheckSplitFlags me;
    public static final int id = 8232;
}
