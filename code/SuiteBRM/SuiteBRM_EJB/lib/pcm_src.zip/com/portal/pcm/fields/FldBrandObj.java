// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBrandObj extends PoidField
{

    public FldBrandObj()
    {
        super(1905, 7);
    }

    public static synchronized FldBrandObj getInst()
    {
        if(me == null)
            me = new FldBrandObj();
        return me;
    }

    private static FldBrandObj me;
    public static final int id = 1905;
}
