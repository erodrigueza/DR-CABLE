// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBottomIndex extends IntField
{

    public FldBottomIndex()
    {
        super(8181, 1);
    }

    public static synchronized FldBottomIndex getInst()
    {
        if(me == null)
            me = new FldBottomIndex();
        return me;
    }

    private static FldBottomIndex me;
    public static final int id = 8181;
}
