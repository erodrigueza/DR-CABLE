// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.BufField;

public class FldBuffer extends BufField
{

    public FldBuffer()
    {
        super(34, 6);
    }

    public static synchronized FldBuffer getInst()
    {
        if(me == null)
            me = new FldBuffer();
        return me;
    }

    private static FldBuffer me;
    public static final int id = 34;
}
