// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldCity extends StrField
{

    public FldCity()
    {
        super(167, 5);
    }

    public static synchronized FldCity getInst()
    {
        if(me == null)
            me = new FldCity();
        return me;
    }

    private static FldCity me;
    public static final int id = 167;
}
