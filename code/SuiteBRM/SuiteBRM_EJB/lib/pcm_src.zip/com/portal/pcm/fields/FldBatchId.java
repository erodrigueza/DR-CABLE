// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBatchId extends StrField
{

    public FldBatchId()
    {
        super(933, 5);
    }

    public static synchronized FldBatchId getInst()
    {
        if(me == null)
            me = new FldBatchId();
        return me;
    }

    private static FldBatchId me;
    public static final int id = 933;
}
