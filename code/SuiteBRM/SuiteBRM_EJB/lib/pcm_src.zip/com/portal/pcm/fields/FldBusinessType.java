// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldBusinessType extends EnumField
{

    public FldBusinessType()
    {
        super(282, 3);
    }

    public static synchronized FldBusinessType getInst()
    {
        if(me == null)
            me = new FldBusinessType();
        return me;
    }

    private static FldBusinessType me;
    public static final int id = 282;
}
