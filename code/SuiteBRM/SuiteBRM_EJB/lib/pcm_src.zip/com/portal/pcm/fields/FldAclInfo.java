// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldAclInfo extends SubStructField
{

    public FldAclInfo()
    {
        super(1901, 10);
    }

    public static synchronized FldAclInfo getInst()
    {
        if(me == null)
            me = new FldAclInfo();
        return me;
    }

    private static FldAclInfo me;
    public static final int id = 1901;
}
