// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldAmountFrom extends DecimalField
{

    public FldAmountFrom()
    {
        super(2422, 14);
    }

    public static synchronized FldAmountFrom getInst()
    {
        if(me == null)
            me = new FldAmountFrom();
        return me;
    }

    private static FldAmountFrom me;
    public static final int id = 2422;
}
