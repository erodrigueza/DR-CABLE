// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBillDirection extends StrField
{

    public FldBillDirection()
    {
        super(6508, 5);
    }

    public static synchronized FldBillDirection getInst()
    {
        if(me == null)
            me = new FldBillDirection();
        return me;
    }

    private static FldBillDirection me;
    public static final int id = 6508;
}
