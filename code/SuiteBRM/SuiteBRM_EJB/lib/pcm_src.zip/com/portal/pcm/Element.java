// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;


// Referenced classes of package com.portal.pcm:
//            Field

public class Element extends Field
{

    public Element(int i, int j, int k)
    {
        super(i, j);
        elemID = k;
        real = true;
    }

    Element(int i, int j)
    {
        super(i);
        elemID = j;
        real = true;
    }

    Element(int i)
    {
        super(i);
        elemID = -1;
        real = false;
    }

    public int getElementID()
    {
        return elemID;
    }

    public void setElementID(int i)
    {
        elemID = i;
    }

    public String toString()
    {
        return (new StringBuilder()).append("[").append(elemID).append("] ").append(super.toString()).toString();
    }

    private int elemID;
    private boolean real;
    public static final int ELEMID_ANY = -1;
    public static final int ELEMID_ASSIGN = -2;
    public static final int ELEMID_MAX = 0xffff0000;
}