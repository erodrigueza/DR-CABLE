// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldAchInfo extends ArrayField
{

    public FldAchInfo()
    {
        super(7853, 9);
    }

    public static synchronized FldAchInfo getInst()
    {
        if(me == null)
            me = new FldAchInfo();
        return me;
    }

    private static FldAchInfo me;
    public static final int id = 7853;
}
