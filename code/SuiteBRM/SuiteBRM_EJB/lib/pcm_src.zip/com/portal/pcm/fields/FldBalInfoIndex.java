// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBalInfoIndex extends IntField
{

    public FldBalInfoIndex()
    {
        super(472, 1);
    }

    public static synchronized FldBalInfoIndex getInst()
    {
        if(me == null)
            me = new FldBalInfoIndex();
        return me;
    }

    private static FldBalInfoIndex me;
    public static final int id = 472;
}
