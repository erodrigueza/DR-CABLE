// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBasicRateplan extends IntField
{

    public FldBasicRateplan()
    {
        super(9667, 1);
    }

    public static synchronized FldBasicRateplan getInst()
    {
        if(me == null)
            me = new FldBasicRateplan();
        return me;
    }

    private static FldBasicRateplan me;
    public static final int id = 9667;
}
