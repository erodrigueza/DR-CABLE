// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldCheckInfo extends ArrayField
{

    public FldCheckInfo()
    {
        super(927, 9);
    }

    public static synchronized FldCheckInfo getInst()
    {
        if(me == null)
            me = new FldCheckInfo();
        return me;
    }

    private static FldCheckInfo me;
    public static final int id = 927;
}
