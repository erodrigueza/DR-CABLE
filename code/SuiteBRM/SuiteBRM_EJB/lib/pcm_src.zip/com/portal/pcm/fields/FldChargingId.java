// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldChargingId extends StrField
{

    public FldChargingId()
    {
        super(6404, 5);
    }

    public static synchronized FldChargingId getInst()
    {
        if(me == null)
            me = new FldChargingId();
        return me;
    }

    private static FldChargingId me;
    public static final int id = 6404;
}
