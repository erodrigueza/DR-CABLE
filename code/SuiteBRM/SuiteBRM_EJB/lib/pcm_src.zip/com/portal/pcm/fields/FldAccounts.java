// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:16 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldAccounts extends ArrayField
{

    public FldAccounts()
    {
        super(2704, 9);
    }

    public static synchronized FldAccounts getInst()
    {
        if(me == null)
            me = new FldAccounts();
        return me;
    }

    private static FldAccounts me;
    public static final int id = 2704;
}