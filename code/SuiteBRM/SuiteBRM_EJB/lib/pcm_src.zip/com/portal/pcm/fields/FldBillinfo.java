// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBillinfo extends ArrayField
{

    public FldBillinfo()
    {
        super(126, 9);
    }

    public static synchronized FldBillinfo getInst()
    {
        if(me == null)
            me = new FldBillinfo();
        return me;
    }

    private static FldBillinfo me;
    public static final int id = 126;
}
