// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldChannelObj extends PoidField
{

    public FldChannelObj()
    {
        super(1408, 7);
    }

    public static synchronized FldChannelObj getInst()
    {
        if(me == null)
            me = new FldChannelObj();
        return me;
    }

    private static FldChannelObj me;
    public static final int id = 1408;
}
