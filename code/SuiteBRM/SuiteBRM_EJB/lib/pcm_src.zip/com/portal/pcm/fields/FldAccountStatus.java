// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:16 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAccountStatus extends StrField
{

    public FldAccountStatus()
    {
        super(1412, 5);
    }

    public static synchronized FldAccountStatus getInst()
    {
        if(me == null)
            me = new FldAccountStatus();
        return me;
    }

    private static FldAccountStatus me;
    public static final int id = 1412;
}