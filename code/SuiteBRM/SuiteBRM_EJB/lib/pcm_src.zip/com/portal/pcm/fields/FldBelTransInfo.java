// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldBelTransInfo extends SubStructField
{

    public FldBelTransInfo()
    {
        super(5677, 10);
    }

    public static synchronized FldBelTransInfo getInst()
    {
        if(me == null)
            me = new FldBelTransInfo();
        return me;
    }

    private static FldBelTransInfo me;
    public static final int id = 5677;
}
