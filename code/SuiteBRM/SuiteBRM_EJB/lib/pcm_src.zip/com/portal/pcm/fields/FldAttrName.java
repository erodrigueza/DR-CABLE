// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAttrName extends StrField
{

    public FldAttrName()
    {
        super(1252, 5);
    }

    public static synchronized FldAttrName getInst()
    {
        if(me == null)
            me = new FldAttrName();
        return me;
    }

    private static FldAttrName me;
    public static final int id = 1252;
}
