// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBackwardLinks extends ArrayField
{

    public FldBackwardLinks()
    {
        super(9002, 9);
    }

    public static synchronized FldBackwardLinks getInst()
    {
        if(me == null)
            me = new FldBackwardLinks();
        return me;
    }

    private static FldBackwardLinks me;
    public static final int id = 9002;
}
