// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.TStampField;

public class FldBalDate extends TStampField
{

    public FldBalDate()
    {
        super(9235, 8);
    }

    public static synchronized FldBalDate getInst()
    {
        if(me == null)
            me = new FldBalDate();
        return me;
    }

    private static FldBalDate me;
    public static final int id = 9235;
}
