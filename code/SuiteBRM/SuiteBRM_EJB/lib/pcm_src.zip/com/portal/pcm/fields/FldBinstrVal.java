// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.BinStrField;

public class FldBinstrVal extends BinStrField
{

    public FldBinstrVal()
    {
        super(1121, 12);
    }

    public static synchronized FldBinstrVal getInst()
    {
        if(me == null)
            me = new FldBinstrVal();
        return me;
    }

    private static FldBinstrVal me;
    public static final int id = 1121;
}
