// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBatchApplicationPid extends IntField
{

    public FldBatchApplicationPid()
    {
        super(2601, 1);
    }

    public static synchronized FldBatchApplicationPid getInst()
    {
        if(me == null)
            me = new FldBatchApplicationPid();
        return me;
    }

    private static FldBatchApplicationPid me;
    public static final int id = 2601;
}
