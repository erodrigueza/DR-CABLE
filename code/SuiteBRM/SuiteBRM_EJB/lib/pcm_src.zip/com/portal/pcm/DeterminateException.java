// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.util.Date;

// Referenced classes of package com.portal.pcm:
//            EBufException, FList

public class DeterminateException extends EBufException
{

    public DeterminateException(int i, int j, int k, int l, int i1, int j1, String s, 
            FList flist, int k1, int l1, Date date, int i2, FList flist1, EBufException ebufexception, 
            int j2)
    {
        super(i, j, k, l, i1, j1, s, flist, k1, l1, date, i2, flist1, ebufexception, j2);
    }

    public String toString()
    {
        return (new StringBuilder()).append("DeterminateError - ").append(super.toString()).toString();
    }
}