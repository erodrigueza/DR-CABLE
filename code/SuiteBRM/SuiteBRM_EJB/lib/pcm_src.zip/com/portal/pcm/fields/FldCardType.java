// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldCardType extends EnumField
{

    public FldCardType()
    {
        super(5708, 3);
    }

    public static synchronized FldCardType getInst()
    {
        if(me == null)
            me = new FldCardType();
        return me;
    }

    private static FldCardType me;
    public static final int id = 5708;
}
