// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.TStampField;

public class FldChargedFromT extends TStampField
{

    public FldChargedFromT()
    {
        super(2348, 8);
    }

    public static synchronized FldChargedFromT getInst()
    {
        if(me == null)
            me = new FldChargedFromT();
        return me;
    }

    private static FldChargedFromT me;
    public static final int id = 2348;
}
