// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBankAddr extends StrField
{

    public FldBankAddr()
    {
        super(1053, 5);
    }

    public static synchronized FldBankAddr getInst()
    {
        if(me == null)
            me = new FldBankAddr();
        return me;
    }

    private static FldBankAddr me;
    public static final int id = 1053;
}
