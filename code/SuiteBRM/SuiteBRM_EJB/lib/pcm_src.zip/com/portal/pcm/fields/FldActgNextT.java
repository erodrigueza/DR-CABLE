// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.TStampField;

public class FldActgNextT extends TStampField
{

    public FldActgNextT()
    {
        super(755, 8);
    }

    public static synchronized FldActgNextT getInst()
    {
        if(me == null)
            me = new FldActgNextT();
        return me;
    }

    private static FldActgNextT me;
    public static final int id = 755;
}
