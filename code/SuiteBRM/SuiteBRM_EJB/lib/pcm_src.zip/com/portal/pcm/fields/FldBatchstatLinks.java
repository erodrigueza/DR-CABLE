// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBatchstatLinks extends ArrayField
{

    public FldBatchstatLinks()
    {
        super(9024, 9);
    }

    public static synchronized FldBatchstatLinks getInst()
    {
        if(me == null)
            me = new FldBatchstatLinks();
        return me;
    }

    private static FldBatchstatLinks me;
    public static final int id = 9024;
}
