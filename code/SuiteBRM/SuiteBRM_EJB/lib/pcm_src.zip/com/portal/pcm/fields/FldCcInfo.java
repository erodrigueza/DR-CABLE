// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldCcInfo extends ArrayField
{

    public FldCcInfo()
    {
        super(142, 9);
    }

    public static synchronized FldCcInfo getInst()
    {
        if(me == null)
            me = new FldCcInfo();
        return me;
    }

    private static FldCcInfo me;
    public static final int id = 142;
}
