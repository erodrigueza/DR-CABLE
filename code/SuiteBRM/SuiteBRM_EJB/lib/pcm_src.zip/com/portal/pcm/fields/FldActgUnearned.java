// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldActgUnearned extends DecimalField
{

    public FldActgUnearned()
    {
        super(220, 14);
    }

    public static synchronized FldActgUnearned getInst()
    {
        if(me == null)
            me = new FldActgUnearned();
        return me;
    }

    private static FldActgUnearned me;
    public static final int id = 220;
}
