// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAni extends StrField
{

    public FldAni()
    {
        super(419, 5);
    }

    public static synchronized FldAni getInst()
    {
        if(me == null)
            me = new FldAni();
        return me;
    }

    private static FldAni me;
    public static final int id = 419;
}
