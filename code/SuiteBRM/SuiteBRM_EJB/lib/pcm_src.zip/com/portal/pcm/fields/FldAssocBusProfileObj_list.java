// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAssocBusProfileObj_list extends StrField
{

    public FldAssocBusProfileObj_list()
    {
        super(987, 5);
    }

    public static synchronized FldAssocBusProfileObj_list getInst()
    {
        if(me == null)
            me = new FldAssocBusProfileObj_list();
        return me;
    }

    private static FldAssocBusProfileObj_list me;
    public static final int id = 987;
}
