// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBaseExpr extends StrField
{

    public FldBaseExpr()
    {
        super(7822, 5);
    }

    public static synchronized FldBaseExpr getInst()
    {
        if(me == null)
            me = new FldBaseExpr();
        return me;
    }

    private static FldBaseExpr me;
    public static final int id = 7822;
}
