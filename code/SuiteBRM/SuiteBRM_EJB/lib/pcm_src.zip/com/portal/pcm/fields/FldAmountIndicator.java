// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldAmountIndicator extends IntField
{

    public FldAmountIndicator()
    {
        super(2430, 1);
    }

    public static synchronized FldAmountIndicator getInst()
    {
        if(me == null)
            me = new FldAmountIndicator();
        return me;
    }

    private static FldAmountIndicator me;
    public static final int id = 2430;
}
