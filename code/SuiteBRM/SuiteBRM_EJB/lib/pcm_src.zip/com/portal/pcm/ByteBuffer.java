// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.*;

// Referenced classes of package com.portal.pcm:
//            Buffer

public class ByteBuffer extends Buffer
{

    public ByteBuffer(byte abyte0[], int i, boolean flag)
    {
        super(i, flag);
        bytes = abyte0;
        os = null;
    }

    public ByteBuffer()
    {
        bytes = null;
        os = new ByteArrayOutputStream();
    }

    public byte[] getBytes()
    {
        if(os != null)
            bytes = os.toByteArray();
        return bytes;
    }

    public void setBytes(byte abyte0[])
    {
        bytes = abyte0;
        if(os != null)
            os = null;
    }

    public long getSize()
    {
        long l = 0L;
        if(os != null)
            l = os.size();
        else
        if(bytes == null)
            l = 0L;
        else
            l = bytes.length;
        return l;
    }

    public InputStream getInputStream()
        throws IOException
    {
        int i = getOffset();
        return new ByteArrayInputStream(bytes, i, bytes.length - i);
    }

    public OutputStream getOutputStream()
        throws IOException
    {
        if(os == null)
        {
            os = new ByteArrayOutputStream();
            setOffset(0);
        }
        return os;
    }

    private byte bytes[];
    private ByteArrayOutputStream os;
}