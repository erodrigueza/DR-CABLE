// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;


public interface BRMListener
{
    public static final class EventType extends Enum
    {

        public static EventType[] values()
        {
            return (EventType[])$VALUES.clone();
        }

        public static EventType valueOf(String s)
        {
            return (EventType)Enum.valueOf(com/portal/pcm/BRMListener$EventType, s);
        }

        public static final EventType EVENT_READ_DATA_AVAILABLE;
        public static final EventType EVENT_CHANNEL_CLOSED;
        private static final EventType $VALUES[];

        static 
        {
            EVENT_READ_DATA_AVAILABLE = new EventType("EVENT_READ_DATA_AVAILABLE", 0);
            EVENT_CHANNEL_CLOSED = new EventType("EVENT_CHANNEL_CLOSED", 1);
            $VALUES = (new EventType[] {
                EVENT_READ_DATA_AVAILABLE, EVENT_CHANNEL_CLOSED
            });
        }

        private EventType(String s, int i)
        {
            super(s, i);
        }
    }

}