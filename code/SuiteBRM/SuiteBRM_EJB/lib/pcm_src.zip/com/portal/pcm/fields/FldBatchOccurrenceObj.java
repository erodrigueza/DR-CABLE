// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBatchOccurrenceObj extends PoidField
{

    public FldBatchOccurrenceObj()
    {
        super(2613, 7);
    }

    public static synchronized FldBatchOccurrenceObj getInst()
    {
        if(me == null)
            me = new FldBatchOccurrenceObj();
        return me;
    }

    private static FldBatchOccurrenceObj me;
    public static final int id = 2613;
}
