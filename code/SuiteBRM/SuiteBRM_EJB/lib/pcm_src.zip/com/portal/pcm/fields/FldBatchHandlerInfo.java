// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldBatchHandlerInfo extends SubStructField
{

    public FldBatchHandlerInfo()
    {
        super(2605, 10);
    }

    public static synchronized FldBatchHandlerInfo getInst()
    {
        if(me == null)
            me = new FldBatchHandlerInfo();
        return me;
    }

    private static FldBatchHandlerInfo me;
    public static final int id = 2605;
}
