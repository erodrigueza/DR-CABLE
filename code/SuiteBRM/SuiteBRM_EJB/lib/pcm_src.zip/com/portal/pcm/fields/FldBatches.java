// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBatches extends ArrayField
{

    public FldBatches()
    {
        super(9152, 9);
    }

    public static synchronized FldBatches getInst()
    {
        if(me == null)
            me = new FldBatches();
        return me;
    }

    private static FldBatches me;
    public static final int id = 9152;
}
