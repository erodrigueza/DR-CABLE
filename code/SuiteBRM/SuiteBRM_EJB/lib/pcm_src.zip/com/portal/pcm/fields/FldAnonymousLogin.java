// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldAnonymousLogin extends IntField
{

    public FldAnonymousLogin()
    {
        super(3000, 1);
    }

    public static synchronized FldAnonymousLogin getInst()
    {
        if(me == null)
            me = new FldAnonymousLogin();
        return me;
    }

    private static FldAnonymousLogin me;
    public static final int id = 3000;
}
