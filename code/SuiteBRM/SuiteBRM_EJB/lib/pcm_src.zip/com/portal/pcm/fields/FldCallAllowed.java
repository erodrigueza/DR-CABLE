// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCallAllowed extends IntField
{

    public FldCallAllowed()
    {
        super(8036, 1);
    }

    public static synchronized FldCallAllowed getInst()
    {
        if(me == null)
            me = new FldCallAllowed();
        return me;
    }

    private static FldCallAllowed me;
    public static final int id = 8036;
}
