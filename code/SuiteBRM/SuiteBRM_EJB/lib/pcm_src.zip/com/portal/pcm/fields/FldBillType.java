// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldBillType extends EnumField
{

    public FldBillType()
    {
        super(127, 3);
    }

    public static synchronized FldBillType getInst()
    {
        if(me == null)
            me = new FldBillType();
        return me;
    }

    private static FldBillType me;
    public static final int id = 127;
}
