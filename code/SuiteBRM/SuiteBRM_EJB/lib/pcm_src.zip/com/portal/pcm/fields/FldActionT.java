// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.TStampField;

public class FldActionT extends TStampField
{

    public FldActionT()
    {
        super(8151, 8);
    }

    public static synchronized FldActionT getInst()
    {
        if(me == null)
            me = new FldActionT();
        return me;
    }

    private static FldActionT me;
    public static final int id = 8151;
}
