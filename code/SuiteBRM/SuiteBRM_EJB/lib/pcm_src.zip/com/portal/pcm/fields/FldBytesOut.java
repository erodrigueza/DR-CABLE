// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBytesOut extends IntField
{

    public FldBytesOut()
    {
        super(422, 1);
    }

    public static synchronized FldBytesOut getInst()
    {
        if(me == null)
            me = new FldBytesOut();
        return me;
    }

    private static FldBytesOut me;
    public static final int id = 422;
}
