// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldAcDiscount extends SubStructField
{

    public FldAcDiscount()
    {
        super(2342, 10);
    }

    public static synchronized FldAcDiscount getInst()
    {
        if(me == null)
            me = new FldAcDiscount();
        return me;
    }

    private static FldAcDiscount me;
    public static final int id = 2342;
}
