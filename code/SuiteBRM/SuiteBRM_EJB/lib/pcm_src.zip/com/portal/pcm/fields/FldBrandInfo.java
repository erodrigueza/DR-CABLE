// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldBrandInfo extends SubStructField
{

    public FldBrandInfo()
    {
        super(1902, 10);
    }

    public static synchronized FldBrandInfo getInst()
    {
        if(me == null)
            me = new FldBrandInfo();
        return me;
    }

    private static FldBrandInfo me;
    public static final int id = 1902;
}
