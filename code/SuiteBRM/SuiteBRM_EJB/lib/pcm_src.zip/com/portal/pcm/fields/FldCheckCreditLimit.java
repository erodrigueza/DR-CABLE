// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCheckCreditLimit extends IntField
{

    public FldCheckCreditLimit()
    {
        super(2920, 1);
    }

    public static synchronized FldCheckCreditLimit getInst()
    {
        if(me == null)
            me = new FldCheckCreditLimit();
        return me;
    }

    private static FldCheckCreditLimit me;
    public static final int id = 2920;
}
