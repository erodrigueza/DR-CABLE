// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBillDayOfMonth extends IntField
{

    public FldBillDayOfMonth()
    {
        super(9155, 1);
    }

    public static synchronized FldBillDayOfMonth getInst()
    {
        if(me == null)
            me = new FldBillDayOfMonth();
        return me;
    }

    private static FldBillDayOfMonth me;
    public static final int id = 9155;
}
