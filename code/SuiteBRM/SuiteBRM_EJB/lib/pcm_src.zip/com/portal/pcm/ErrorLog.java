// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:11 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.io.IOException;

// Referenced classes of package com.portal.pcm:
//            Log, PortalProperties

public class ErrorLog extends Log
{

    public ErrorLog()
    {
        setControlStyle(2);
    }

    public ErrorLog(String s, String s1, int i)
    {
        super(s, s1, 2, i);
    }

    public ErrorLog(String s)
    {
        super(s);
        setControlState(0);
        setControlStyle(2);
    }

    public void setFlags(int i)
    {
        setControlState(i);
    }

    public void setInMemoryFlag(int i)
    {
        setInMemoryFlagValue(i);
    }

    public void setInMemorySize(long l)
    {
        setInMemoryLogSize(l);
    }

    public void log(String s)
        throws IOException
    {
        log(32, s);
    }

    public void log(Object obj, String s)
        throws IOException
    {
        log(obj, 32, s);
    }

    public static synchronized ErrorLog getDefaultLog()
    {
        if(defLog == null)
        {
            String s = PortalProperties.getSystemProperty("log.file");
            if(s == null || s.length() == 0)
                s = "javapcm.log";
            defLog = new ErrorLog(s);
            String s1 = PortalProperties.getSystemProperty("log.level");
            if(s1 != null)
            {
                int i = 0;
                try
                {
                    i = Integer.parseInt(s1.trim());
                }
                catch(NumberFormatException numberformatexception)
                {
                    i = 0;
                }
                switch(i)
                {
                case 0: // '\0'
                    defLog.setFlags(0);
                    break;

                case 1: // '\001'
                    defLog.setFlags(2);
                    break;

                case 2: // '\002'
                    defLog.setFlags(6);
                    break;

                case 3: // '\003'
                    defLog.setFlags(-1);
                    break;

                default:
                    defLog.setFlags(0);
                    break;
                }
            }
            String s2 = PortalProperties.getSystemProperty("log.name");
            if(s2 != null)
                defLog.setName(s2);
            String s3 = PortalProperties.getSystemProperty("log.inmemoryflag");
            if(s3 != null)
            {
                int j = 0;
                try
                {
                    j = Integer.parseInt(s3.trim());
                }
                catch(NumberFormatException numberformatexception1)
                {
                    j = 0;
                }
                defLog.setInMemoryFlag(j);
            }
            String s4 = PortalProperties.getSystemProperty("log.inmemorylogsize");
            if(s4 != null)
            {
                int k = 0;
                try
                {
                    k = Integer.parseInt(s4.trim());
                }
                catch(NumberFormatException numberformatexception2)
                {
                    k = 4096;
                }
                if(k == 0)
                    k = 4096;
                defLog.setInMemorySize(k);
            }
        }
        return defLog;
    }

    protected void openLog()
    {
        super.openLog();
        String as[] = new String[8];
        int i = 1;
        for(int j = 0; j < 8; j++)
        {
            as[j] = PortalProperties.getResource((new StringBuilder()).append("log.flag.").append(i).toString());
            i <<= 1;
        }

        setNames(as);
    }

    public static final int Assertion = 1;
    public static final int Error = 2;
    public static final int Warning = 4;
    public static final int Debug = 8;
    public static final int Errno = 16;
    public static final int Message = 32;
    public static final int Dump = 64;
    public static final int Security = 128;
    public static final int All = -1;
    public static final int Serious = 131;
    private String flagStrs[];
    private static ErrorLog defLog;
}