// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldActionMode extends EnumField
{

    public FldActionMode()
    {
        super(7737, 3);
    }

    public static synchronized FldActionMode getInst()
    {
        if(me == null)
            me = new FldActionMode();
        return me;
    }

    private static FldActionMode me;
    public static final int id = 7737;
}
