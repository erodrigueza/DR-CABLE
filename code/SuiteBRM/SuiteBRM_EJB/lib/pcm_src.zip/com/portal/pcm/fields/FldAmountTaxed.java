// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldAmountTaxed extends DecimalField
{

    public FldAmountTaxed()
    {
        super(538, 14);
    }

    public static synchronized FldAmountTaxed getInst()
    {
        if(me == null)
            me = new FldAmountTaxed();
        return me;
    }

    private static FldAmountTaxed me;
    public static final int id = 538;
}
