// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldCashRecvd extends DecimalField
{

    public FldCashRecvd()
    {
        super(205, 14);
    }

    public static synchronized FldCashRecvd getInst()
    {
        if(me == null)
            me = new FldCashRecvd();
        return me;
    }

    private static FldCashRecvd me;
    public static final int id = 205;
}
