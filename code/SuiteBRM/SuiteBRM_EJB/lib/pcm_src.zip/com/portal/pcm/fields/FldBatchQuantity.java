// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldBatchQuantity extends DecimalField
{

    public FldBatchQuantity()
    {
        super(7604, 14);
    }

    public static synchronized FldBatchQuantity getInst()
    {
        if(me == null)
            me = new FldBatchQuantity();
        return me;
    }

    private static FldBatchQuantity me;
    public static final int id = 7604;
}
