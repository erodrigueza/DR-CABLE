// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCallingVerticalCoordination extends IntField
{

    public FldCallingVerticalCoordination()
    {
        super(2512, 1);
    }

    public static synchronized FldCallingVerticalCoordination getInst()
    {
        if(me == null)
            me = new FldCallingVerticalCoordination();
        return me;
    }

    private static FldCallingVerticalCoordination me;
    public static final int id = 2512;
}
