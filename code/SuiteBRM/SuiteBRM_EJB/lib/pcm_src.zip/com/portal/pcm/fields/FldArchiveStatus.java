// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldArchiveStatus extends EnumField
{

    public FldArchiveStatus()
    {
        super(1755, 3);
    }

    public static synchronized FldArchiveStatus getInst()
    {
        if(me == null)
            me = new FldArchiveStatus();
        return me;
    }

    private static FldArchiveStatus me;
    public static final int id = 1755;
}
