// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldAddonCharge extends DecimalField
{

    public FldAddonCharge()
    {
        super(9678, 14);
    }

    public static synchronized FldAddonCharge getInst()
    {
        if(me == null)
            me = new FldAddonCharge();
        return me;
    }

    private static FldAddonCharge me;
    public static final int id = 9678;
}
