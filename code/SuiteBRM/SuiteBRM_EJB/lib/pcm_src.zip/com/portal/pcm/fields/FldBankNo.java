// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBankNo extends StrField
{

    public FldBankNo()
    {
        super(1054, 5);
    }

    public static synchronized FldBankNo getInst()
    {
        if(me == null)
            me = new FldBankNo();
        return me;
    }

    private static FldBankNo me;
    public static final int id = 1054;
}
