// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldChoices extends ArrayField
{

    public FldChoices()
    {
        super(85, 9);
    }

    public static synchronized FldChoices getInst()
    {
        if(me == null)
            me = new FldChoices();
        return me;
    }

    private static FldChoices me;
    public static final int id = 85;
}
