// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldActionDescr extends StrField
{

    public FldActionDescr()
    {
        super(7736, 5);
    }

    public static synchronized FldActionDescr getInst()
    {
        if(me == null)
            me = new FldActionDescr();
        return me;
    }

    private static FldActionDescr me;
    public static final int id = 7736;
}
