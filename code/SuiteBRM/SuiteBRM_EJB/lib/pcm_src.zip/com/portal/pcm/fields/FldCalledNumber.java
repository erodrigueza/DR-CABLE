// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldCalledNumber extends StrField
{

    public FldCalledNumber()
    {
        super(6401, 5);
    }

    public static synchronized FldCalledNumber getInst()
    {
        if(me == null)
            me = new FldCalledNumber();
        return me;
    }

    private static FldCalledNumber me;
    public static final int id = 6401;
}
