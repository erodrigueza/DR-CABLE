// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:10 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm;

import java.util.ArrayList;

public class Crypt
{

    public Crypt()
    {
    }

    private static native String encrypt_pw(String s);

    private static native String decrypt_pw(String s);

    private static native String decrypt_data(String s);

    private static native int crypt_init(String as[], int i, String s);

    public static void cryptInit(String s, String s1)
    {
        boolean flag = false;
        String s2 = "";
        ArrayList arraylist = new ArrayList();
        if(s != null && s.length() > 0)
        {
            int j = 0;
            int i;
            while((i = s.indexOf(' ')) != -1) 
            {
                String s3 = s.substring(0, i);
                arraylist.add(s3);
                s3 = s.substring(i + 1, s.length());
                s = s3;
            }
            if(i == -1 && s.length() > 5)
                arraylist.add(s);
            j = arraylist.size();
            if(j > 0)
            {
                String as[] = new String[j];
                String s4 = "pin_crypt \"&aes|0D5E11BFDD97D2769D9B0DBFBD1BBF7EF0995627DEADF4F99BAF16A62B3E9658BBB26F3A94BB25E7FC6D7C27B4298310\"";
                for(int k = 0; k < j; k++)
                    as[k] = (String)arraylist.get(k);

                aesCryptInitialized = crypt_init(as, j, s4);
            }
        }
        if(s1 != null)
            md5CryptInitialized = crypt_init(null, -1, s1);
    }

    public static String decryptData(String s)
    {
        String s1 = null;
        if(s != null)
        {
            if(s.length() < 5)
                return null;
            if("&aes|".compareTo(s.substring(0, 5)) == 0)
            {
                if(aesCryptInitialized == 1)
                    s1 = decrypt_data(s);
                else
                    return null;
            } else
            if("&md5|".compareTo(s.substring(0, 5)) == 0)
                if(md5CryptInitialized == 1)
                    s1 = decrypt_data(s);
                else
                    return null;
            return s1;
        } else
        {
            return null;
        }
    }

    public static String encryptPassword(String s)
    {
        Object obj = null;
        if(s != null)
        {
            String s1 = encrypt_pw(s);
            return s1;
        } else
        {
            return null;
        }
    }

    public static String decryptPassword(String s)
    {
        Object obj = null;
        if(s != null)
        {
            String s1 = decrypt_pw(s);
            return s1;
        } else
        {
            return null;
        }
    }

    private static int aesCryptInitialized = 0;
    private static int md5CryptInitialized = 0;

    static 
    {
        System.loadLibrary("portal");
    }
}