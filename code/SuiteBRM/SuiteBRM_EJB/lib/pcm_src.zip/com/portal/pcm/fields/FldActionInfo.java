// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldActionInfo extends ArrayField
{

    public FldActionInfo()
    {
        super(1826, 9);
    }

    public static synchronized FldActionInfo getInst()
    {
        if(me == null)
            me = new FldActionInfo();
        return me;
    }

    private static FldActionInfo me;
    public static final int id = 1826;
}
