// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBillSuppression extends ArrayField
{

    public FldBillSuppression()
    {
        super(8230, 9);
    }

    public static synchronized FldBillSuppression getInst()
    {
        if(me == null)
            me = new FldBillSuppression();
        return me;
    }

    private static FldBillSuppression me;
    public static final int id = 8230;
}
