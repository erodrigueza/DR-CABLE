// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:15 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAacVendor extends StrField
{

    public FldAacVendor()
    {
        super(100, 5);
    }

    public static synchronized FldAacVendor getInst()
    {
        if(me == null)
            me = new FldAacVendor();
        return me;
    }

    private static FldAacVendor me;
    public static final int id = 100;
}