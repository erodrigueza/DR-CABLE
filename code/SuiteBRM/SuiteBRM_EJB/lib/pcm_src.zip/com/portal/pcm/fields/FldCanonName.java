// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldCanonName extends StrField
{

    public FldCanonName()
    {
        super(162, 5);
    }

    public static synchronized FldCanonName getInst()
    {
        if(me == null)
            me = new FldCanonName();
        return me;
    }

    private static FldCanonName me;
    public static final int id = 162;
}
