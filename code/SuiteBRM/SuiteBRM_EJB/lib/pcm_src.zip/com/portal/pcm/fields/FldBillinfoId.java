// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBillinfoId extends StrField
{

    public FldBillinfoId()
    {
        super(7901, 5);
    }

    public static synchronized FldBillinfoId getInst()
    {
        if(me == null)
            me = new FldBillinfoId();
        return me;
    }

    private static FldBillinfoId me;
    public static final int id = 7901;
}
