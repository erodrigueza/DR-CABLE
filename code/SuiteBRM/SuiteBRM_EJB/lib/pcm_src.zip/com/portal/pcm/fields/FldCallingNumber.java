// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldCallingNumber extends StrField
{

    public FldCallingNumber()
    {
        super(6403, 5);
    }

    public static synchronized FldCallingNumber getInst()
    {
        if(me == null)
            me = new FldCallingNumber();
        return me;
    }

    private static FldCallingNumber me;
    public static final int id = 6403;
}
