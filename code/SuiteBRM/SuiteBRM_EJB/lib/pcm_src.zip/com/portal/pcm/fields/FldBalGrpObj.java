// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBalGrpObj extends PoidField
{

    public FldBalGrpObj()
    {
        super(7751, 7);
    }

    public static synchronized FldBalGrpObj getInst()
    {
        if(me == null)
            me = new FldBalGrpObj();
        return me;
    }

    private static FldBalGrpObj me;
    public static final int id = 7751;
}
