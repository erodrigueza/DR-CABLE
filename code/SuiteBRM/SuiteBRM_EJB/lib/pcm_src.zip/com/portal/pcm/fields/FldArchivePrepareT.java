// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.TStampField;

public class FldArchivePrepareT extends TStampField
{

    public FldArchivePrepareT()
    {
        super(1761, 8);
    }

    public static synchronized FldArchivePrepareT getInst()
    {
        if(me == null)
            me = new FldArchivePrepareT();
        return me;
    }

    private static FldArchivePrepareT me;
    public static final int id = 1761;
}
