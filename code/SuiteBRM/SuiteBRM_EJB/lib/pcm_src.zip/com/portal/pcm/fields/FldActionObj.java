// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldActionObj extends PoidField
{

    public FldActionObj()
    {
        super(8156, 7);
    }

    public static synchronized FldActionObj getInst()
    {
        if(me == null)
            me = new FldActionObj();
        return me;
    }

    private static FldActionObj me;
    public static final int id = 8156;
}
