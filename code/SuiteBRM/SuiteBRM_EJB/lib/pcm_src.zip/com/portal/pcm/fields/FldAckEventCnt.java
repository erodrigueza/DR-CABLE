// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldAckEventCnt extends IntField
{

    public FldAckEventCnt()
    {
        super(9153, 1);
    }

    public static synchronized FldAckEventCnt getInst()
    {
        if(me == null)
            me = new FldAckEventCnt();
        return me;
    }

    private static FldAckEventCnt me;
    public static final int id = 9153;
}
