// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBatchReplacesObj extends PoidField
{

    public FldBatchReplacesObj()
    {
        super(2609, 7);
    }

    public static synchronized FldBatchReplacesObj getInst()
    {
        if(me == null)
            me = new FldBatchReplacesObj();
        return me;
    }

    private static FldBatchReplacesObj me;
    public static final int id = 2609;
}
