// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldChargeAmt extends DecimalField
{

    public FldChargeAmt()
    {
        super(9697, 14);
    }

    public static synchronized FldChargeAmt getInst()
    {
        if(me == null)
            me = new FldChargeAmt();
        return me;
    }

    private static FldChargeAmt me;
    public static final int id = 9697;
}
