// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldAuthorizationId extends StrField
{

    public FldAuthorizationId()
    {
        super(7450, 5);
    }

    public static synchronized FldAuthorizationId getInst()
    {
        if(me == null)
            me = new FldAuthorizationId();
        return me;
    }

    private static FldAuthorizationId me;
    public static final int id = 7450;
}
