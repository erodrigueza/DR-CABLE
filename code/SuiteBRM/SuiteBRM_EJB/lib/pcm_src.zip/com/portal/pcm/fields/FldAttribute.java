// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldAttribute extends IntField
{

    public FldAttribute()
    {
        super(513, 1);
    }

    public static synchronized FldAttribute getInst()
    {
        if(me == null)
            me = new FldAttribute();
        return me;
    }

    private static FldAttribute me;
    public static final int id = 513;
}
