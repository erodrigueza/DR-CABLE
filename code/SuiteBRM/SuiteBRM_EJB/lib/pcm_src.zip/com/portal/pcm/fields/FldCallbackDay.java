// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCallbackDay extends IntField
{

    public FldCallbackDay()
    {
        super(6310, 1);
    }

    public static synchronized FldCallbackDay getInst()
    {
        if(me == null)
            me = new FldCallbackDay();
        return me;
    }

    private static FldCallbackDay me;
    public static final int id = 6310;
}
