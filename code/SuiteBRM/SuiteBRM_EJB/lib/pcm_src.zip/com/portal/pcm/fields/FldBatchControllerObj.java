// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.PoidField;

public class FldBatchControllerObj extends PoidField
{

    public FldBatchControllerObj()
    {
        super(2603, 7);
    }

    public static synchronized FldBatchControllerObj getInst()
    {
        if(me == null)
            me = new FldBatchControllerObj();
        return me;
    }

    private static FldBatchControllerObj me;
    public static final int id = 2603;
}
