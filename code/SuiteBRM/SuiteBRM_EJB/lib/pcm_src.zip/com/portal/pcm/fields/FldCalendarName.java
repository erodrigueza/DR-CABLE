// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldCalendarName extends StrField
{

    public FldCalendarName()
    {
        super(9717, 5);
    }

    public static synchronized FldCalendarName getInst()
    {
        if(me == null)
            me = new FldCalendarName();
        return me;
    }

    private static FldCalendarName me;
    public static final int id = 9717;
}
