// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldBatchStat extends SubStructField
{

    public FldBatchStat()
    {
        super(9005, 10);
    }

    public static synchronized FldBatchStat getInst()
    {
        if(me == null)
            me = new FldBatchStat();
        return me;
    }

    private static FldBatchStat me;
    public static final int id = 9005;
}
