// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldChildren extends IntField
{

    public FldChildren()
    {
        super(1374, 1);
    }

    public static synchronized FldChildren getInst()
    {
        if(me == null)
            me = new FldChildren();
        return me;
    }

    private static FldChildren me;
    public static final int id = 1374;
}
