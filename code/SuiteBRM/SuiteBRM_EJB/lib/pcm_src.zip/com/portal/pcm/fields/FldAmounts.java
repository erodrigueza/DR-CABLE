// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldAmounts extends ArrayField
{

    public FldAmounts()
    {
        super(1623, 9);
    }

    public static synchronized FldAmounts getInst()
    {
        if(me == null)
            me = new FldAmounts();
        return me;
    }

    private static FldAmounts me;
    public static final int id = 1623;
}
