// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldClassmark extends StrField
{

    public FldClassmark()
    {
        super(3100, 5);
    }

    public static synchronized FldClassmark getInst()
    {
        if(me == null)
            me = new FldClassmark();
        return me;
    }

    private static FldClassmark me;
    public static final int id = 3100;
}
