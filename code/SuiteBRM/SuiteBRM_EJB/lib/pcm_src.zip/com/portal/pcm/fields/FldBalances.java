// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBalances extends ArrayField
{

    public FldBalances()
    {
        super(198, 9);
    }

    public static synchronized FldBalances getInst()
    {
        if(me == null)
            me = new FldBalances();
        return me;
    }

    private static FldBalances me;
    public static final int id = 198;
}
