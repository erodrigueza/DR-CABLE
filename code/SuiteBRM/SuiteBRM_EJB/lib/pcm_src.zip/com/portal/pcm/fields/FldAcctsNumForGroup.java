// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldAcctsNumForGroup extends IntField
{

    public FldAcctsNumForGroup()
    {
        super(2408, 1);
    }

    public static synchronized FldAcctsNumForGroup getInst()
    {
        if(me == null)
            me = new FldAcctsNumForGroup();
        return me;
    }

    private static FldAcctsNumForGroup me;
    public static final int id = 2408;
}
