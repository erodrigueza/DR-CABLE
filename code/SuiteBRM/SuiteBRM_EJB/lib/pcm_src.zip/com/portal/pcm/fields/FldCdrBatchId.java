// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCdrBatchId extends IntField
{

    public FldCdrBatchId()
    {
        super(8210, 1);
    }

    public static synchronized FldCdrBatchId getInst()
    {
        if(me == null)
            me = new FldCdrBatchId();
        return me;
    }

    private static FldCdrBatchId me;
    public static final int id = 8210;
}
