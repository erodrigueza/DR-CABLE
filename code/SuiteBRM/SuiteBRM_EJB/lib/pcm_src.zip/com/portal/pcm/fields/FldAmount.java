// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldAmount extends DecimalField
{

    public FldAmount()
    {
        super(57, 14);
    }

    public static synchronized FldAmount getInst()
    {
        if(me == null)
            me = new FldAmount();
        return me;
    }

    private static FldAmount me;
    public static final int id = 57;
}
