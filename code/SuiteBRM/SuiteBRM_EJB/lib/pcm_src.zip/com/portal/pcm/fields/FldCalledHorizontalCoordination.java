// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldCalledHorizontalCoordination extends IntField
{

    public FldCalledHorizontalCoordination()
    {
        super(2510, 1);
    }

    public static synchronized FldCalledHorizontalCoordination getInst()
    {
        if(me == null)
            me = new FldCalledHorizontalCoordination();
        return me;
    }

    private static FldCalledHorizontalCoordination me;
    public static final int id = 2510;
}
