// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBoolean extends IntField
{

    public FldBoolean()
    {
        super(48, 1);
    }

    public static synchronized FldBoolean getInst()
    {
        if(me == null)
            me = new FldBoolean();
        return me;
    }

    private static FldBoolean me;
    public static final int id = 48;
}
