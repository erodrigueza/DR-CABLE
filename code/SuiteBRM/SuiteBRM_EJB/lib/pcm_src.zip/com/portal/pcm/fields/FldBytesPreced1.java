// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.DecimalField;

public class FldBytesPreced1 extends DecimalField
{

    public FldBytesPreced1()
    {
        super(1727, 14);
    }

    public static synchronized FldBytesPreced1 getInst()
    {
        if(me == null)
            me = new FldBytesPreced1();
        return me;
    }

    private static FldBytesPreced1 me;
    public static final int id = 1727;
}
