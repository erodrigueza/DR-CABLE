// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.StrField;

public class FldBatchHandlerCmdline extends StrField
{

    public FldBatchHandlerCmdline()
    {
        super(2604, 5);
    }

    public static synchronized FldBatchHandlerCmdline getInst()
    {
        if(me == null)
            me = new FldBatchHandlerCmdline();
        return me;
    }

    private static FldBatchHandlerCmdline me;
    public static final int id = 2604;
}
