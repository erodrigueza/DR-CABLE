// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldBillWhen extends IntField
{

    public FldBillWhen()
    {
        super(131, 1);
    }

    public static synchronized FldBillWhen getInst()
    {
        if(me == null)
            me = new FldBillWhen();
        return me;
    }

    private static FldBillWhen me;
    public static final int id = 131;
}
