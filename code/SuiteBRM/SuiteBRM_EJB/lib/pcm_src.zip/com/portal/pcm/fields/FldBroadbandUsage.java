// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.SubStructField;

public class FldBroadbandUsage extends SubStructField
{

    public FldBroadbandUsage()
    {
        super(5227, 10);
    }

    public static synchronized FldBroadbandUsage getInst()
    {
        if(me == null)
            me = new FldBroadbandUsage();
        return me;
    }

    private static FldBroadbandUsage me;
    public static final int id = 5227;
}
