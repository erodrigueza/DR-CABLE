// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.ArrayField;

public class FldBusinessTypeArray extends ArrayField
{

    public FldBusinessTypeArray()
    {
        super(284, 9);
    }

    public static synchronized FldBusinessTypeArray getInst()
    {
        if(me == null)
            me = new FldBusinessTypeArray();
        return me;
    }

    private static FldBusinessTypeArray me;
    public static final int id = 284;
}
