// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldActgType extends EnumField
{

    public FldActgType()
    {
        super(758, 3);
    }

    public static synchronized FldActgType getInst()
    {
        if(me == null)
            me = new FldActgType();
        return me;
    }

    private static FldActgType me;
    public static final int id = 758;
}
