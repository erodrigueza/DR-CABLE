// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.IntField;

public class FldArchivingId extends IntField
{

    public FldArchivingId()
    {
        super(1758, 1);
    }

    public static synchronized FldArchivingId getInst()
    {
        if(me == null)
            me = new FldArchivingId();
        return me;
    }

    private static FldArchivingId me;
    public static final int id = 1758;
}
