// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.portal.pcm.fields;

import com.portal.pcm.EnumField;

public class FldBatchHandlerStatus extends EnumField
{

    public FldBatchHandlerStatus()
    {
        super(2611, 3);
    }

    public static synchronized FldBatchHandlerStatus getInst()
    {
        if(me == null)
            me = new FldBatchHandlerStatus();
        return me;
    }

    private static FldBatchHandlerStatus me;
    public static final int id = 2611;
}
