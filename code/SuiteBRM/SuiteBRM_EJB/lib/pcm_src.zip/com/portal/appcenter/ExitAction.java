// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ExitAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;

// Referenced classes of package com.portal.appcenter:
//            AppManager

class ExitAction extends PFCAction
{

    ExitAction(String tok, Properties p, ResourceBundle rb)
    {
        super(tok, p, rb);
    }

    public void actionPerformed(ActionEvent ae)
    {
        AppManager.getInstance().closeAll();
    }
}