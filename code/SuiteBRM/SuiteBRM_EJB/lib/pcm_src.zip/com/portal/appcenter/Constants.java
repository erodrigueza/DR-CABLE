// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Constants.java

package com.portal.appcenter;


interface Constants
{

    public static final String APP_CENTER = "Portal AppCenter";
    public static final String CUSTOM = "<CUSTOM>";
    public static final String CASCADE = "<CASCADE";
    public static final String CASCADE_ITEMS = ".cascade.";
    public static final String AC_TOKEN = "appcenter";
    public static final String AC_PERM_TOKEN = "/appcenter/";
    public static final String SEP = "<SEP>";
    public static final String VSEP = "<VSEP>";
    public static final String SPACER = "<SPACER>";
    public static final String MENUS = ".menus";
    public static final String MENU = ".menu.";
    public static final String TOOLBAR = ".toolbar";
    public static final String DOT_PROPS = ".properties";
    public static final String BOUNDS = ".bounds";
    public static final String OFFLINE_ALLOWED = "offline.allowed";
    public static final String MAXIMIZED = "appcenter.frame.maximized";
    public static final String WIDTH = "appcenter.frame.width";
    public static final String HEIGHT = "appcenter.frame.height";
    public static final String BOUNDS_PREF_KEY = "appcenter.frame";
    public static final String SWITCHER_POS_PREF_KEY = "appcenter.switcher.position.separateRow";
    public static final String SWITCHER_WIDTH_PREF_KEY = "appcenter.switcher.width";
    public static final String SWITCHER_SHOWAPPNAMES_PREF_KEY = "appcenter.switcher.showAppNames";
    public static final String PREFS_PAGE_LABEL = "prefs.tab.";
    public static final String DEFAULT_ICON = "/com/portal/appcenter/images/appcenter.gif";
    public static final int ROOT_ADMINCLIENT_ID = 2;
    public static final String LNF_THEME_KEY = "appcenter.lookandfeel.theme";
    public static final String DEFAULT_THEME = "default";
    public static final String GRAY_THEME = "gray";
    public static final String BLUE_WHITE_THEME = "bluewhite";
    public static final String SANDSTONE_THEME = "sandstone";
    public static final String DEFAULT_LNF_THEME = "sandstone";
}