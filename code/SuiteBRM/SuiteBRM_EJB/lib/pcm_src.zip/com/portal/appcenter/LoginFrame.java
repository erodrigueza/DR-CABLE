// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoginFrame.java

package com.portal.appcenter;

import com.portal.pcm.PortalContext;
import com.portal.pfc.ui.PFCImage;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.event.ChangeListener;

// Referenced classes of package com.portal.appcenter:
//            LoginPanel, Constants

class LoginFrame extends JFrame
    implements Constants
{

    LoginFrame(String title, boolean workOfflineAvailable, String appToken)
    {
        super(title);
        setResizable(false);
        java.awt.Image i = PFCImage.getImage(getClass(), "/com/portal/appcenter/images/appcenter.gif");
        setIconImage(i);
        getContentPane().setLayout(new BorderLayout());
        loginPanel = new LoginPanel(workOfflineAvailable, appToken);
        loginPanel.setAppName(title);
        getContentPane().add(loginPanel, "Center");
        getContentPane().add(loginPanel.getCommandButtons(), "South");
        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }

            final LoginFrame this$0;

            
            {
                this$0 = LoginFrame.this;
                super();
            }
        }
);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        pack();
        setSize(295, 267);
        setLocation((d.width - 295) / 2, (d.height - 267) / 2);
    }

    PortalContext getPortalContext()
    {
        return loginPanel.mPortalCxt;
    }

    public void addChangeListener(ChangeListener l)
    {
        loginPanel.addChangeListener(l);
    }

    public void removeChangeListener(ChangeListener l)
    {
        loginPanel.removeChangeListener(l);
    }

    String getLoginURL()
    {
        return loginPanel.mDefaultLoginURL;
    }

    private LoginPanel loginPanel;
    private static final int HEIGHT = 267;
    private static final int WIDTH = 295;
}