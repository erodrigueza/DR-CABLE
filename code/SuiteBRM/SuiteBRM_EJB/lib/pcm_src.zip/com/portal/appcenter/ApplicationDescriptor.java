// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ApplicationDescriptor.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

// Referenced classes of package com.portal.appcenter:
//            PrefsPageDescriptor, Constants, AppManager

public class ApplicationDescriptor
    implements Constants
{

    ApplicationDescriptor(String applicationToken, Properties properties)
    {
        this(applicationToken, properties, null);
    }

    ApplicationDescriptor(String applicationToken, Properties properties, ClassLoader classLoader)
    {
        if(applicationToken == null)
            throw new NullPointerException("applicationToken is null");
        if(properties == null)
            throw new NullPointerException("properties is null");
        mApplicationToken = applicationToken;
        mProperties = properties;
        if(classLoader == null)
            mClassLoader = getClass().getClassLoader();
        else
            mClassLoader = classLoader;
    }

    String getClassName()
    {
        String name = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".class").toString());
        return name;
    }

    java.awt.Image getIcon()
    {
        if(mIcon == null)
        {
            String s = (String)mProperties.get((new StringBuilder()).append(mApplicationToken).append(".icon").toString());
            if(s != null && s.length() > 0)
                mIcon = PFCImage.getImage(mClassLoader, s);
            if(mIcon == null)
                mIcon = PFCImage.getImage(getClass(), "/com/portal/appcenter/images/appcenter.gif");
        }
        return mIcon;
    }

    Properties getProperties()
    {
        return mProperties;
    }

    String[] getPropertiesList()
    {
        String s = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".properties").toString(), null);
        if(s == null || s.length() == 0)
            return new String[0];
        StringTokenizer st = new StringTokenizer(s);
        String props[] = new String[st.countTokens()];
        String tkn = null;
        for(int i = 0; st.hasMoreTokens(); i++)
        {
            tkn = st.nextToken();
            props[i] = tkn;
        }

        return props;
    }

    String[] getResourceList()
    {
        String s = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".resources").toString());
        if(s == null || s.length() == 0)
            return new String[0];
        StringTokenizer st = new StringTokenizer(s);
        String rl[] = new String[st.countTokens()];
        String tkn = null;
        for(int i = 0; st.hasMoreTokens(); i++)
        {
            tkn = st.nextToken();
            rl[i] = tkn;
        }

        return rl;
    }

    public String getName()
    {
        String name = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".name").toString());
        if(!$assertionsDisabled && name == null)
            throw new AssertionError();
        else
            return name;
    }

    String getToken()
    {
        return mApplicationToken;
    }

    String getHelpSet()
    {
        String hs = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".helpset").toString());
        return hs;
    }

    List getPrefsPanelDescriptors()
    {
        if(mPrefPanelList == null)
        {
            mPrefPanelList = new ArrayList();
            StringTokenizer st = new StringTokenizer(mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".preferences.pages").toString(), ""));
            String name = null;
            String clsName = null;
            PrefsPageDescriptor ppd;
            for(; st.hasMoreTokens(); mPrefPanelList.add(ppd))
            {
                name = st.nextToken();
                clsName = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".preferences.").append(name).append(".class").toString());
                ppd = new PrefsPageDescriptor(name, clsName);
            }

        }
        return mPrefPanelList;
    }

    String getConfigurationLoader()
    {
        String s = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".configuration.loader").toString());
        return s != null && s.length() != 0 ? s : null;
    }

    String getVersion()
    {
        String ver = mProperties.getProperty((new StringBuilder()).append(mApplicationToken).append(".version").toString());
        if(ver == null)
            ver = AppManager.getProperties().getProperty("appcenter.version");
        return ver;
    }

    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("AppDescriptor[");
        sb.append(getToken());
        sb.append("]");
        return sb.toString();
    }

    private String mApplicationToken;
    private Properties mProperties;
    private ClassLoader mClassLoader;
    private java.awt.Image mIcon;
    private List mPrefPanelList;
    static final boolean $assertionsDisabled = !com/portal/appcenter/ApplicationDescriptor.desiredAssertionStatus();

}