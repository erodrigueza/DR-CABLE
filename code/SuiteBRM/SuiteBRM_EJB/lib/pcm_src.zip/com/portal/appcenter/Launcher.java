// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Launcher.java

package com.portal.appcenter;

import com.portal.pfc.ui.PDropDown;
import com.portal.pfc.ui.PFCImage;
import com.portal.pfc.ui.PSlidingDrawer;
import com.portal.pfc.ui.PToolBarButton;
import com.portal.pfc.ui.SwingHelper;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;

// Referenced classes of package com.portal.appcenter:
//            ApplicationDescriptor, LaunchAppAction, LaunchAppWithNewConnAction, AppManager, 
//            ActionManager

class Launcher extends PToolBarButton
    implements ActionListener
{
    class PopupDismissListener
        implements ActionListener
    {

        public void actionPerformed(ActionEvent e)
        {
            if(mLaunchPopup.isVisible())
                mLaunchPopup.setVisible(false);
        }

        final Launcher this$0;

        PopupDismissListener()
        {
            this$0 = Launcher.this;
            super();
        }
    }


    Launcher()
    {
        java.awt.Image iconImage = PFCImage.getImage(getClass(), "/com/portal/appcenter/images/launcher.gif");
        java.awt.Image rolloverImage = PFCImage.getImage(getClass(), "/com/portal/appcenter/images/launcher_rollover.gif");
        setIcon(new ImageIcon(iconImage));
        setRolloverIcon(new ImageIcon(rolloverImage));
        setContentAreaFilled(false);
        setBorder(new EmptyBorder(0, 3, 0, 0));
        setToolTipText(AppManager.getResBundle().getString("launcher.button.tooltip"));
        initPopupPanel();
        addActionListener(this);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(mLaunchPopup == null)
        {
            javax.swing.JFrame f = SwingHelper.getFrame((Component)e.getSource());
            String title = AppManager.getResBundle().getString("launcher.title");
            mLaunchPopup = new PSlidingDrawer(mLaunchPanel, f, title);
        }
        if(mLaunchPopup.isVisible())
            mLaunchPopup.setVisible(false);
        else
            mLaunchPopup.setVisible(true);
    }

    private void initPopupPanel()
    {
        mLaunchPanel = new JPanel();
        mLaunchPanel.setLayout(new GridBagLayout());
        PopupDismissListener dismissListener = new PopupDismissListener();
        java.util.List configuredApps = AppManager.getInstance().getConfiguredAppsList();
        Map actionMap = ActionManager.getDefaultActionMap();
        int index = 0;
        for(Iterator i = configuredApps.iterator(); i.hasNext(); index++)
        {
            Object item = i.next();
            if(item instanceof ApplicationDescriptor)
            {
                LaunchAppAction launchAction = (LaunchAppAction)actionMap.get(((ApplicationDescriptor)item).getToken());
                JButton appBtn = new JButton(launchAction);
                appBtn.setHorizontalAlignment(10);
                mLaunchPanel.add(appBtn, new GridBagConstraints(0, index, 1, 1, 0.0D, 0.0D, 18, 2, new Insets(5, 2, 5, 0), 0, 0));
                appBtn.addActionListener(dismissListener);
                JMenuItem menuItems[] = new JMenuItem[2];
                menuItems[0] = new JMenuItem(launchAction);
                menuItems[0].setText(AppManager.getResBundle().getString("launcher.open"));
                menuItems[0].setIcon(null);
                menuItems[0].addActionListener(dismissListener);
                LaunchAppWithNewConnAction newConnAction = new LaunchAppWithNewConnAction((ApplicationDescriptor)item);
                menuItems[1] = new JMenuItem(newConnAction);
                menuItems[1].setText(AppManager.getResBundle().getString("launcher.open.newConn"));
                menuItems[1].addActionListener(dismissListener);
                PDropDown dropDown = new PDropDown(null, menuItems);
                mLaunchPanel.add(dropDown, new GridBagConstraints(1, index, 1, 1, 0.0D, 0.0D, 18, 3, new Insets(5, 0, 5, 2), 0, 0));
                continue;
            }
            if(item.equals("<SEP>"))
                mLaunchPanel.add(new JSeparator(), new GridBagConstraints(0, index, 2, 1, 0.0D, 0.0D, 18, 2, new Insets(5, 0, 5, 2), 0, 0));
        }

    }

    private PSlidingDrawer mLaunchPopup;
    private JPanel mLaunchPanel;

}