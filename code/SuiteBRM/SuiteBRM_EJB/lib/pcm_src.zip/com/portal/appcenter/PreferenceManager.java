// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PreferenceManager.java

package com.portal.appcenter;

import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package com.portal.appcenter:
//            ACProperties, PrefsPageDescriptor, PreferencesPage, ExitListener, 
//            Constants, ConnectionManager, ApplicationDescriptor, AppManager, 
//            ApplicationServices, ExitEvent

class PreferenceManager
    implements ExitListener, Constants
{

    private PreferenceManager()
    {
        mPrefsCache = new HashMap(4);
    }

    public boolean okToExit(ExitEvent evt)
    {
        return savePreferences();
    }

    static synchronized PreferenceManager getPreferenceManager()
    {
        if(sPrefsMgr == null)
            sPrefsMgr = new PreferenceManager();
        return sPrefsMgr;
    }

    ACProperties getPreferences()
    {
        if(sPrefs == null)
            sPrefs = loadPropsFromDisk();
        return sPrefs;
    }

    private boolean savePreferences()
    {
        try
        {
            sPrefs.serialize();
        }
        catch(IOException ex)
        {
            AppManager.getLogger().log(Level.WARNING, "Preferences not saved", ex);
        }
        return true;
    }

    private ACProperties loadPropsFromDisk()
    {
        String filename = (new StringBuilder()).append(System.getProperty("user.home")).append(AppManager.getProperties().getProperty("appcenter.preferences.filename", "/Portal/appcenter.properties")).toString();
        ACProperties p = new ACProperties(filename);
        return p;
    }

    private ACProperties loadPropsFromInfranet()
    {
        ACProperties p = null;
        return p;
    }

    private void savePropsToInfranet()
    {
        ConnectionManager cm = ConnectionManager.getInstance();
        if(!cm.isOnline())
        {
            return;
        } else
        {
            ConnectionManager.getInstance().getDefaultConnection("appcenter");
            return;
        }
    }

    List getApplicationPrefPanels(ApplicationDescriptor desc)
    {
        ClassLoader cl = ApplicationServices.getClassLoaderFor(desc);
        List panelList = desc.getPrefsPanelDescriptors();
        PrefsPageDescriptor ppd = null;
        for(Iterator i = panelList.iterator(); i.hasNext();)
        {
            ppd = (PrefsPageDescriptor)i.next();
            try
            {
                Class cls = Class.forName(ppd.getClassName(), true, cl);
                PreferencesPage prefsPage = (PreferencesPage)cls.newInstance();
                ppd.setObject(prefsPage);
                ApplicationServices svcs = ApplicationServices.getServices(prefsPage);
                ppd.setLabel(svcs.getResources().getString((new StringBuilder()).append("prefs.tab.").append(ppd.getToken()).toString()));
            }
            catch(Exception cnfex)
            {
                AppManager.getInstance();
                AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("didn't instantiate PreferencePage '").append(ppd.getClassName()).append("'").toString(), cnfex);
            }
        }

        return panelList;
    }

    List getAppCenterPrefPanels()
    {
        if(mACPrefList == null)
        {
            mACPrefList = new ArrayList();
            Properties p = AppManager.getProperties();
            StringTokenizer st = new StringTokenizer(p.getProperty("appcenter.preferences.pages", ""));
            String name = null;
            String clsName = null;
            do
            {
                if(!st.hasMoreTokens())
                    break;
                name = st.nextToken();
                clsName = p.getProperty((new StringBuilder()).append("appcenter.preferences.").append(name).append(".class").toString());
                PrefsPageDescriptor ppd = new PrefsPageDescriptor(name, clsName);
                ppd.setLabel(AppManager.getResBundle().getString((new StringBuilder()).append("prefs.tab.").append(name).toString()));
                try
                {
                    Class cls = Class.forName(clsName);
                    ppd.setObject((PreferencesPage)cls.newInstance());
                }
                catch(Exception cnfex)
                {
                    AppManager.getInstance();
                    AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("didn't instantiate PreferencePage '").append(clsName).append("'").toString(), cnfex);
                    continue;
                }
                if(name != null && ppd.getObject() != null)
                    mACPrefList.add(ppd);
                name = null;
                clsName = null;
            } while(true);
        }
        return mACPrefList;
    }

    private static PreferenceManager sPrefsMgr;
    private static ACProperties sPrefs;
    private Map mPrefsCache;
    private List mACPrefList;
}