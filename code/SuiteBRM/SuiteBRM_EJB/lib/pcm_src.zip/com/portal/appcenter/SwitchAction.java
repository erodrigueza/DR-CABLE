// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   SwitchAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import com.portal.pfc.ui.SwingHelper;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

// Referenced classes of package com.portal.appcenter:
//            PrimaryAppCenterFrame, Application, ApplicationServices

class SwitchAction extends PFCAction
{

    SwitchAction(String token, Properties properties, ResourceBundle rb, String switchTo, ImageIcon icon)
    {
        super(token, properties, rb);
        if(switchTo == null)
        {
            throw new NullPointerException("'switchTo' should not be null");
        } else
        {
            mSwitchTo = switchTo;
            putValue("Name", switchTo);
            putValue("SmallIcon", icon);
            return;
        }
    }

    public void actionPerformed(ActionEvent ae)
    {
        JFrame f = SwingHelper.getFrame((Component)ae.getSource());
        if(f instanceof PrimaryAppCenterFrame)
        {
            PrimaryAppCenterFrame pf = (PrimaryAppCenterFrame)f;
            String currApp = pf.getCurrentApp().getApplicationServices().getDisplayName();
            if(!mSwitchTo.equals(currApp))
                pf.switchTo(mSwitchTo, false);
        }
    }

    private String mSwitchTo;
}