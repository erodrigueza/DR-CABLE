// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ApplicationHelpAction.java

package com.portal.appcenter;

import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import oracle.help.CSHManager;

// Referenced classes of package com.portal.appcenter:
//            ACAction, Application, ApplicationServices, AppManager

public class ApplicationHelpAction extends ACAction
{

    public ApplicationHelpAction(String actionToken, Application app)
    {
        super(actionToken, app);
        mSvcs = app.getApplicationServices();
    }

    public void actionPerformed(ActionEvent ae)
    {
        mSvcs.getFrame().setCursor(3);
        CSHManager helpManager = mSvcs.getCSHManager();
        if(helpManager != null)
            helpManager.showNavigatorWindow();
        else
            AppManager.getLogger().log(Level.WARNING, "Couldn't display help");
        mSvcs.getFrame().setCursor(0);
    }

    private ApplicationServices mSvcs;
}