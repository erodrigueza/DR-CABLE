// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AboutAction.java

package com.portal.appcenter;

import java.util.*;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.table.AbstractTableModel;

// Referenced classes of package com.portal.appcenter:
//            ApplicationDescriptor, AppManager

class ApplicationDescriptorTableModel extends AbstractTableModel
{

    ApplicationDescriptorTableModel(Collection c)
    {
        mApps = new ArrayList(c);
    }

    public boolean isCellEditable(int rowIndex, int columnIndex)
    {
        return false;
    }

    public int getColumnCount()
    {
        return 2;
    }

    public String getColumnName(int column)
    {
        String n = "";
        switch(column)
        {
        case 0: // '\0'
            n = AppManager.getResBundle().getString("appcenter.action.about.application");
            break;

        case 1: // '\001'
            n = AppManager.getResBundle().getString("appcenter.action.about.version");
            break;
        }
        return n;
    }

    public Object getValueAt(int row, int col)
    {
        if(row > getRowCount())
            return null;
        ApplicationDescriptor ad = (ApplicationDescriptor)mApps.get(row);
        if(col == 0)
        {
            JLabel lbl = new JLabel();
            java.awt.Image img = ad.getIcon();
            ImageIcon i = new ImageIcon(img);
            lbl.setIcon(i);
            lbl.setText(ad.getName());
            return lbl;
        } else
        {
            return ad.getVersion();
        }
    }

    public int getRowCount()
    {
        return mApps.size();
    }

    private List mApps;
}