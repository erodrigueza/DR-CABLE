// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrimaryAppCenterFrame.java

package com.portal.appcenter;

import com.portal.pfc.ui.PToolBarToggleButton;
import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeSupport;
import java.util.*;
import java.util.logging.Logger;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            AppCenterFrame, Switcher, AppPanel, ACMenuBar, 
//            SwitchAction, AppManager, PreferenceManager, ACProperties, 
//            Application, ApplicationServices, ApplicationDescriptor

public class PrimaryAppCenterFrame extends AppCenterFrame
    implements MouseListener, ActionListener
{

    PrimaryAppCenterFrame()
    {
        mLayout = new CardLayout();
        mSwitchActionMap = new HashMap(5);
        mNameToAppPanelMap = new HashMap(5);
        mAppStack = new Stack();
        mShowingHomeapp = false;
        mSwitcher = new Switcher();
        mbShowSwitcherAsSepRow = false;
        mbShowAppNames = false;
        getContentPane().setLayout(mLayout);
        if(mSwitcher.isHomePageIconDisplayed())
        {
            SwitchAction sa = createHomeAppSwitchAction();
            mSwitcher.setHomePageSwitchAction(sa);
        }
        setBounds();
        setIconImage(AppManager.getInstance().getSuiteIcon());
        String val = PreferenceManager.getPreferenceManager().getPreferences().getProperty("appcenter.switcher.position.separateRow");
        mbShowSwitcherAsSepRow = val == null ? false : Boolean.valueOf(val).booleanValue();
        if(!mbShowSwitcherAsSepRow)
        {
            String widthVal = PreferenceManager.getPreferenceManager().getPreferences().getProperty("appcenter.switcher.width");
            if(widthVal == null)
                widthVal = "124";
            Switcher _tmp = mSwitcher;
            Dimension d = new Dimension(Integer.valueOf(widthVal).intValue(), mSwitcher.getPreferredSize().height + 2 * 2);
            mSwitcher.setPreferredSize(d);
        }
        String pref = PreferenceManager.getPreferenceManager().getPreferences().getProperty("appcenter.switcher.showAppNames");
        mbShowAppNames = pref == null ? false : Boolean.valueOf(pref).booleanValue();
        initSwitcherPopup();
    }

    public void mouseReleased(MouseEvent e)
    {
        if(e.getSource() == mSwitcher && e.isPopupTrigger())
            mActionPopup.show(e.getComponent(), e.getX(), e.getY());
    }

    public void mousePressed(MouseEvent mouseevent)
    {
    }

    public void mouseEntered(MouseEvent mouseevent)
    {
    }

    public void mouseExited(MouseEvent mouseevent)
    {
    }

    public void mouseClicked(MouseEvent mouseevent)
    {
    }

    public void actionPerformed(ActionEvent event)
    {
        Object object = event.getSource();
        if(object == mActionItems[0])
        {
            if(mActionItems[0].isSelected())
            {
                if(!mbShowSwitcherAsSepRow)
                {
                    mbShowSwitcherAsSepRow = true;
                    AppPanel ap;
                    for(Iterator i = getAppPanels(); i.hasNext(); layoutSwitcherInSepRow(ap))
                        ap = (AppPanel)i.next();

                    validate();
                }
            } else
            if(mbShowSwitcherAsSepRow)
            {
                mbShowSwitcherAsSepRow = false;
                AppPanel ap;
                for(Iterator i = getAppPanels(); i.hasNext(); layoutSwitcherWithToolbar(ap))
                    ap = (AppPanel)i.next();

                validate();
            }
        } else
        if(object == mActionItems[1])
        {
            if(mActionItems[1].isSelected())
            {
                mSwitcher.showApplicationNames(true);
                mbShowAppNames = true;
            } else
            {
                mSwitcher.showApplicationNames(false);
                mbShowAppNames = false;
            }
            if(mSwitcher.getParent() instanceof JSplitPane)
                ((JSplitPane)mSwitcher.getParent()).resetToPreferredSizes();
        }
    }

    void setHomeApp(AppPanel homeApp)
    {
        if(mHomeApp != null)
        {
            AppManager.getLogger().warning("mHomeApp already set, can only be set once");
            throw new IllegalStateException("mHomeApp already set, can only be set once");
        } else
        {
            mHomeApp = homeApp;
            addApp(homeApp, "homeapp", false);
            ACMenuBar menu = (ACMenuBar)homeApp.getMenuBar();
            menu.removeCloseAction();
            menu.removeUndockAction();
            return;
        }
    }

    void addApp(AppPanel appPanel, String name)
    {
        addApp(appPanel, name, false);
    }

    void addApp(AppPanel appPanel, String name, boolean redock)
    {
        if(name == null || name.equals(""))
            name = appPanel.toString();
        mNameToAppPanelMap.put(name, appPanel);
        JPanel p = new JPanel();
        addApp(p, appPanel);
        getContentPane().add(p, name);
        addSwitchAction(appPanel);
        switchTo(name, redock);
        if(redock)
        {
            ACMenuBar menu = (ACMenuBar)appPanel.getMenuBar();
            menu.replaceLaunchMenuAction();
            menu.removeDockAction();
            menu.addUndockAction();
            menu.replaceExitAction();
            reparentWindowListeners(appPanel.getApplication(), null, this);
            appPanel.getApplication().getApplicationServices().getUndockPropertyChangeSupport().firePropertyChange("DOCK", null, null);
        }
    }

    void addApp(JPanel p, AppPanel appPanel)
    {
        JPanel tb = appPanel.getToolBarPanel();
        JComponent tbPanel;
        if(!mbShowSwitcherAsSepRow)
        {
            tbPanel = appPanel.getToolBarWithSwitcher();
            ((JSplitPane)tbPanel).setRightComponent(tb);
        } else
        {
            tbPanel = new JPanel(new BorderLayout());
            tbPanel.add(tb, "North");
        }
        addApp(p, appPanel, tbPanel);
    }

    void close()
    {
        removeApp((String)mAppStack.peek());
    }

    AppPanel removeApp(String name)
    {
        AppPanel ap = (AppPanel)mNameToAppPanelMap.remove(name);
        if(ap == null)
            return ap;
        getContentPane().remove(ap.getParent());
        if(mAppStack.contains(name))
            mAppStack.remove(name);
        if(mAppStack.size() > 0)
            switchTo((String)mAppStack.peek(), false);
        else
        if(mHomeApp != null)
            switchTo("homeapp", false);
        invalidate();
        validate();
        removeSwitchAction(ap);
        return ap;
    }

    void saveBounds()
    {
        java.awt.Rectangle bounds = getBounds();
        ACProperties prefs = PreferenceManager.getPreferenceManager().getPreferences();
        prefs.setBoundsPreference("appcenter.frame", bounds);
        prefs.setProperty("appcenter.switcher.position.separateRow", mbShowSwitcherAsSepRow);
        prefs.setProperty("appcenter.switcher.width", String.valueOf(mSwitcher.getWidth()));
        prefs.setProperty("appcenter.switcher.showAppNames", mbShowAppNames);
    }

    private void showingHomeApp(boolean b)
    {
        mShowingHomeapp = b;
    }

    private void removeSwitchAction(AppPanel appPanel)
    {
        String appName = appPanel.getApplication().getApplicationServices().getDisplayName();
        SwitchAction sa = (SwitchAction)mSwitchActionMap.remove(appName);
        ((ACMenuBar)appPanel.getMenuBar()).removeAllSwitchActions();
        AppPanel ap;
        for(Iterator i = getAppPanels(); i.hasNext(); ((ACMenuBar)ap.getMenuBar()).removeWindowAction(sa))
            ap = (AppPanel)i.next();

        mSwitcher.removeItem(sa);
    }

    private void addSwitchAction(AppPanel appPanel)
    {
        if(AppManager.getInstance().isHomeApp(appPanel.getApplication()))
            return;
        ACMenuBar menuBar = (ACMenuBar)appPanel.getMenuBar();
        SwitchAction sa;
        for(Iterator i = mSwitchActionMap.values().iterator(); i.hasNext(); menuBar.addWindowAction(sa, -1))
            sa = (SwitchAction)i.next();

        String appName = appPanel.getApplication().getApplicationServices().getDisplayName();
        Image iconImage = appPanel.getApplication().getApplicationServices().getDescriptor().getIcon();
        SwitchAction newsa = new SwitchAction("appcenter.action.switch", AppManager.getProperties(), AppManager.getResBundle(), appName, new ImageIcon(iconImage));
        newsa.putValue("ShortDescription", (new StringBuilder()).append(AppManager.getResBundle().getString("switcher.switchto.app")).append(appName).toString());
        mSwitchActionMap.put(appName, newsa);
        AppPanel ap;
        for(Iterator i = getAppPanels(); i.hasNext(); ((ACMenuBar)ap.getMenuBar()).addWindowAction(newsa, -1))
            ap = (AppPanel)i.next();

        mSwitcher.addItem(newsa);
    }

    private Iterator getAppPanels()
    {
        return mNameToAppPanelMap.values().iterator();
    }

    AppPanel getAppPanel()
    {
        if(mAppStack.empty() && mHomeApp != null)
            return mHomeApp;
        try
        {
            String appname = null;
            if(mShowingHomeapp)
                appname = "homeapp";
            else
                appname = (String)mAppStack.peek();
            if(!$assertionsDisabled && appname == null)
                throw new AssertionError();
            else
                return (AppPanel)mNameToAppPanelMap.get(appname);
        }
        catch(Exception ex)
        {
            throw new InternalError("no apps in mAppStack and mHomeApp is null");
        }
    }

    Application getCurrentApp()
    {
        AppPanel currAP = getAppPanel();
        if(currAP != null)
            return currAP.getApplication();
        else
            return null;
    }

    void switchTo(String switchTo, boolean dock)
    {
        PropertyChangeSupport pcs = null;
        if(!mAppStack.empty() && !switchTo.equals(mAppStack.peek()))
        {
            pcs = getCurrentApp().getApplicationServices().getActivatedPropertyChangeSupport();
            pcs.firePropertyChange("INACTIVE", null, null);
            pcs = null;
        }
        if(mAppStack.contains(switchTo))
            mAppStack.remove(switchTo);
        if(!switchTo.equals("homeapp"))
            mAppStack.push(switchTo);
        AppPanel activePanel = getAppPanel();
        AppPanel toBeActivePanel = (AppPanel)mNameToAppPanelMap.get(switchTo);
        if(activePanel != null)
            if(!mbShowSwitcherAsSepRow)
            {
                int width = mSwitcher.getWidth();
                activePanel.getToolBarWithSwitcher().remove(mSwitcher);
                toBeActivePanel.getToolBarWithSwitcher().setLeftComponent(mSwitcher);
                if(width != 0)
                    toBeActivePanel.getToolBarWithSwitcher().setDividerLocation(width);
            } else
            {
                JPanel tbAndSwitcherPanel = (JPanel)activePanel.getToolBarPanel().getParent();
                tbAndSwitcherPanel.remove(mSwitcher);
                tbAndSwitcherPanel = (JPanel)toBeActivePanel.getToolBarPanel().getParent();
                tbAndSwitcherPanel.add(mSwitcher, "South");
            }
        SwitchAction sa = (SwitchAction)mSwitchActionMap.get(switchTo);
        if(sa != null)
            mSwitcher.setSelectedItem(sa);
        else
        if(switchTo.equals("homeapp"))
            mSwitcher.mHomePageBtn.setSelected(true);
        mLayout.show(getContentPane(), switchTo);
        if(switchTo.equals("homeapp"))
            showingHomeApp(true);
        else
            showingHomeApp(false);
        String dispName = getCurrentApp().getApplicationServices().getDisplayName();
        if(dispName != null && dispName.length() > 0)
        {
            StringBuffer sb = new StringBuffer();
            sb.append(dispName);
            sb.append(" - ");
            sb.append(AppManager.getProperties().getProperty("suite.name"));
            setTitle(sb.toString());
        } else
        {
            setTitle(AppManager.getProperties().getProperty("suite.name"));
        }
        if(!dock)
        {
            pcs = getCurrentApp().getApplicationServices().getActivatedPropertyChangeSupport();
            pcs.firePropertyChange("ACTIVE", null, null);
        }
    }

    AppCenterFrame undock()
    {
        if(mAppStack.size() == 1)
        {
            return null;
        } else
        {
            PropertyChangeSupport pcs = getCurrentApp().getApplicationServices().getUndockPropertyChangeSupport();
            pcs.firePropertyChange("UNDOCK", null, null);
            AppPanel ap = removeApp((String)mAppStack.peek());
            AppCenterFrame acf = new AppCenterFrame();
            acf.setInitialApp(ap, true);
            reparentWindowListeners(ap.getApplication(), this, acf);
            acf.setVisible(true);
            return acf;
        }
    }

    protected void reparentWindowListeners(Application app, JFrame from, JFrame to)
    {
        Set s = new HashSet(app.getApplicationServices().getWindowListenersSet());
        WindowListener l;
        for(Iterator iter = s.iterator(); iter.hasNext(); to.addWindowListener(l))
        {
            l = (WindowListener)iter.next();
            if(from != null)
                from.removeWindowListener(l);
        }

    }

    private void initSwitcherPopup()
    {
        mSwitcher.addMouseListener(this);
        mActionPopup = new JPopupMenu();
        mActionItems = new JCheckBoxMenuItem[2];
        mActionItems[0] = new JCheckBoxMenuItem(AppManager.getResBundle().getString("switcher.showAsSepRow"));
        mActionItems[0].setSelected(mbShowSwitcherAsSepRow);
        mActionItems[0].addActionListener(this);
        mActionItems[1] = new JCheckBoxMenuItem(AppManager.getResBundle().getString("switcher.showAppNames"));
        mActionItems[1].setSelected(mbShowAppNames);
        mSwitcher.showApplicationNames(mbShowAppNames);
        mActionItems[1].addActionListener(this);
        mActionPopup.add(mActionItems[0]);
        mActionPopup.add(mActionItems[1]);
    }

    private void layoutSwitcherInSepRow(AppPanel appPanel)
    {
        JSplitPane toolBarWithSwitcherPanel = appPanel.getToolBarWithSwitcher();
        JPanel toolBarPanel = appPanel.getToolBarPanel();
        JPanel controlP = (JPanel)toolBarWithSwitcherPanel.getParent();
        controlP.remove(toolBarWithSwitcherPanel);
        JPanel tbAndSwitcherPanel = new JPanel(new BorderLayout());
        tbAndSwitcherPanel.add(toolBarPanel, "North");
        if(appPanel == getAppPanel())
            tbAndSwitcherPanel.add(mSwitcher, "South");
        controlP.add(tbAndSwitcherPanel, "South");
    }

    private void layoutSwitcherWithToolbar(AppPanel appPanel)
    {
        JSplitPane toolBarWithSwitcherPanel = appPanel.getToolBarWithSwitcher();
        JPanel toolBarPanel = appPanel.getToolBarPanel();
        JPanel controlP = (JPanel)toolBarPanel.getParent();
        controlP.remove(toolBarPanel);
        toolBarWithSwitcherPanel.setRightComponent(toolBarPanel);
        if(appPanel == getAppPanel())
            toolBarWithSwitcherPanel.setLeftComponent(mSwitcher);
        controlP.add(toolBarWithSwitcherPanel, "South");
    }

    private SwitchAction createHomeAppSwitchAction()
    {
        SwitchAction newsa = new SwitchAction("appcenter.action.switch", AppManager.getProperties(), AppManager.getResBundle(), "homeapp", null);
        newsa.putValue("ShortDescription", AppManager.getResBundle().getString("switcher.switchto.home"));
        return newsa;
    }

    private static final int DEFAULT_SIZE = 5;
    private CardLayout mLayout;
    private Map mSwitchActionMap;
    private Map mNameToAppPanelMap;
    private Stack mAppStack;
    private AppPanel mHomeApp;
    private static final String HOMEAPP = "homeapp";
    private boolean mShowingHomeapp;
    private Switcher mSwitcher;
    private JPopupMenu mActionPopup;
    private JCheckBoxMenuItem mActionItems[];
    private static final int SWITCHER_AS_SEP_ROW = 0;
    private static final int SWITCHER_APP_NAMES = 1;
    private static final String SWITCHER_DEF_WIDTH = "124";
    private boolean mbShowSwitcherAsSepRow;
    private boolean mbShowAppNames;
    static final boolean $assertionsDisabled = !com/portal/appcenter/PrimaryAppCenterFrame.desiredAssertionStatus();

}