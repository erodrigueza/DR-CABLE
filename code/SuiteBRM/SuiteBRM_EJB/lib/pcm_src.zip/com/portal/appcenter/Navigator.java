// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Navigator.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCImage;
import com.portal.pfc.ui.PToolBarButton;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            AppManager

public class Navigator extends JPanel
    implements ActionListener
{

    protected Navigator()
    {
        this(null, null);
    }

    public Navigator(JPanel navPanel)
    {
        this(navPanel, null);
    }

    public Navigator(JPanel navPanel, JPanel headerPanel)
    {
        isExpanded = true;
        mNavigationPanel = navPanel;
        mHeaderPanel = headerPanel;
        mEmptyHeaderPanel = new JPanel();
        try
        {
            jbInit();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        collapseI = new ImageIcon(PFCImage.getImage(getClass(), "/com/portal/appcenter/images/nav_collapse.gif"));
        expandI = new ImageIcon(PFCImage.getImage(getClass(), "/com/portal/appcenter/images/nav_expand.gif"));
        mCollapser.setIcon(collapseI);
        mCollapser.addActionListener(this);
        Color bg = UIManager.getColor("Navigator.background");
        setBackground(bg);
        mNavigationPanel.setBackground(bg);
        mCollapsedNavPanel.setBackground(bg);
    }

    public JPanel getHeaderPanel()
    {
        return mHeaderPanel;
    }

    public void setHeaderPanel(JPanel header)
    {
        if(mHeaderPanel != null)
            mActionPanel.remove(mHeaderPanel);
        mHeaderPanel = header;
        addHeaderPanel();
        validate();
    }

    public JPanel getNavigationPanel()
    {
        return mNavigationPanel;
    }

    public void setNavigationPanel(JPanel mainPanel)
    {
        if(mNavigationPanel != null)
            remove(mNavigationPanel);
        mNavigationPanel = mainPanel;
        add(mNavigationPanel, "Center");
        validate();
    }

    public void setCollapsedColor(Color bkColor)
    {
        mCollapsedNavPanel.setBackground(bkColor);
    }

    public Dimension getPreferredSize()
    {
        if(!isExpanded)
        {
            Dimension d = mCollapser.getPreferredSize();
            d.width = d.width += 5;
            return d;
        } else
        {
            Dimension d = super.getPreferredSize();
            return d;
        }
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource() == mCollapser)
            setExpanded(!isExpanded());
    }

    public boolean isExpanded()
    {
        return isExpanded;
    }

    public void setExpanded(boolean expandIt)
    {
        if(expandIt == isExpanded)
            return;
        isExpanded = expandIt;
        mActionPanel.removeAll();
        if(!expandIt)
        {
            remove(mNavigationPanel);
            add(mCollapsedNavPanel, "Center");
            mCollapser.setIcon(expandI);
            addCollapser();
        } else
        {
            mCollapser.setIcon(collapseI);
            remove(mCollapsedNavPanel);
            add(mNavigationPanel, "Center");
            addHeaderPanel();
            addCollapser();
        }
        Component parent = getParent();
        if(parent != null)
        {
            doLayout();
            revalidate();
            if(parent instanceof JSplitPane)
            {
                ((JSplitPane)parent).resetToPreferredSizes();
                parent.setEnabled(isExpanded);
            }
        }
    }

    private void jbInit()
        throws Exception
    {
        mCollapser = new PToolBarButton();
        mCollapser.setToolTipText(AppManager.getResBundle().getString("navigator.collapse.expand.tooltip"));
        mCollapsedNavPanel = new JPanel();
        if(mNavigationPanel == null)
            mNavigationPanel = new JPanel();
        mActionPanel = new JPanel();
        mActionPanel.setLayout(new GridBagLayout());
        addHeaderPanel();
        addCollapser();
        setLayout(new BorderLayout());
        add(mActionPanel, "North");
        add(mNavigationPanel, "Center");
    }

    private void addHeaderPanel()
    {
        if(mHeaderPanel != null)
        {
            mActionPanel.add(mHeaderPanel, new GridBagConstraints(0, 0, 1, 1, 1.0D, 1.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
        } else
        {
            mActionPanel.add(mEmptyHeaderPanel, new GridBagConstraints(0, 0, 1, 1, 1.0D, 1.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
            mHeaderPanel = mEmptyHeaderPanel;
        }
    }

    private void addCollapser()
    {
        mActionPanel.add(mCollapser, new GridBagConstraints(1, 0, 1, 1, 0.0D, 1.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
    }

    private JPanel mNavigationPanel;
    private JPanel mCollapsedNavPanel;
    private PToolBarButton mCollapser;
    private JPanel mActionPanel;
    private JPanel mHeaderPanel;
    private JPanel mEmptyHeaderPanel;
    private ImageIcon expandI;
    private ImageIcon collapseI;
    private boolean isExpanded;
}