// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BMFCompatibilityApplication.java

package com.portal.appcenter;

import com.portal.pcm.Poid;
import com.portal.permission.ScopeEntryPoint;
import com.portal.pfc.util.BrandUtility;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;

// Referenced classes of package com.portal.appcenter:
//            AbstractApplication, AuthorizationException, ApplicationServices, ACAction, 
//            ExitListener, AppManager, ExitEvent

public abstract class BMFCompatibilityApplication extends AbstractApplication
    implements PropertyChangeListener
{
    class BMFCompatibilityExitListener
        implements ExitListener
    {

        public boolean okToExit(ExitEvent evt)
        {
            if(canExit())
            {
                if(isDirty())
                {
                    int response = JOptionPane.showConfirmDialog(null, AppManager.getResBundle().getString("error.window.close.appcenter.msg"), AppManager.getResBundle().getString("error.window.close.appcenter.title"), 0);
                    if(response == 0)
                    {
                        boolean commitSuccess = commit();
                        if(!commitSuccess)
                            return false;
                    } else
                    if(response == 1)
                        clear();
                    return true;
                } else
                {
                    return true;
                }
            } else
            {
                return false;
            }
        }

        final BMFCompatibilityApplication this$0;

        BMFCompatibilityExitListener()
        {
            this$0 = BMFCompatibilityApplication.this;
            super();
        }
    }


    public BMFCompatibilityApplication()
    {
    }

    public void setApplicationServices(ApplicationServices appServices)
    {
        super.setApplicationServices(appServices);
        mAppServices.addExitListener(new BMFCompatibilityExitListener());
    }

    public Poid getActiveBrandAccount()
    {
        if(mActiveBrand == null)
            try
            {
                BrandUtility util = new BrandUtility(getApplicationServices().getConnection());
                mActiveBrand = util.getActiveBrand();
            }
            catch(AuthorizationException e)
            {
                return null;
            }
        return mActiveBrand.getBillingGroupParent();
    }

    public void propertyChange(PropertyChangeEvent e)
    {
        if(e.getPropertyName() == "brand")
            mActiveBrand = (ScopeEntryPoint)e.getNewValue();
        handleBrandChange();
    }

    protected void handleBrandChange()
    {
    }

    public abstract Component getWorkarea();

    public void start()
    {
    }

    public void addApplicationAction(ACAction action)
    {
        if(mAppServices == null)
        {
            throw new IllegalStateException("ApplicationServices have not yet been set on the application.");
        } else
        {
            mAppServices.addApplicationAction(action);
            return;
        }
    }

    public void close()
    {
        stop();
        exit();
    }

    protected boolean canExit()
    {
        return true;
    }

    protected boolean isDirty()
    {
        return false;
    }

    protected boolean commit()
    {
        return true;
    }

    protected void clear()
    {
    }

    protected void stop()
    {
    }

    protected void exit()
    {
    }

    private ScopeEntryPoint mActiveBrand;
}