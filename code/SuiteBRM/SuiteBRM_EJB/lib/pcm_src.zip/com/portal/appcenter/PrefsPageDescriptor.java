// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrefsPageDescriptor.java

package com.portal.appcenter;


// Referenced classes of package com.portal.appcenter:
//            PreferencesPage

class PrefsPageDescriptor
{

    PrefsPageDescriptor(String token, String className)
    {
        mToken = token;
        mClassName = className;
    }

    String getToken()
    {
        return mToken;
    }

    String getClassName()
    {
        return mClassName;
    }

    void setObject(PreferencesPage obj)
    {
        mPrefsPage = obj;
    }

    PreferencesPage getObject()
    {
        return mPrefsPage;
    }

    void setLabel(String label)
    {
        mLabel = label;
    }

    String getLabel()
    {
        return mLabel;
    }

    private String mToken;
    private String mClassName;
    private PreferencesPage mPrefsPage;
    private String mLabel;
}