// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ConfirmPasswordDialog.java

package com.portal.appcenter;

import com.portal.pcm.DefaultLog;
import java.awt.*;
import java.awt.event.*;
import java.util.ResourceBundle;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            AppManager

public class ConfirmPasswordDialog extends JDialog
    implements ActionListener
{

    public ConfirmPasswordDialog(Frame frame, String userName)
    {
        super(frame, "", true);
        bundle = AppManager.getResBundle();
        this.userName = userName;
        this.frame = frame;
        try
        {
            initialize();
        }
        catch(Exception ex)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, ex);
        }
    }

    private void initialize()
        throws Exception
    {
        GridBagLayout gbLayout = new GridBagLayout();
        getContentPane().setLayout(gbLayout);
        setDefaultCloseOperation(0);
        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent event)
            {
                closeDialog();
            }

            final ConfirmPasswordDialog this$0;

            
            {
                this$0 = ConfirmPasswordDialog.this;
                super();
            }
        }
);
        setTitle(bundle.getString("login.passwordconfirm.title"));
        JLabel messageL = new JLabel(bundle.getString("login.passwordconfirm.sessionexpired"));
        JLabel userIDL = new JLabel(bundle.getString("login.username"));
        JTextField userIDF = new JTextField(15);
        userIDF.setEditable(false);
        userIDF.setText(userName);
        JLabel passwordL = new JLabel(bundle.getString("login.password"));
        password = new JPasswordField();
        password.setColumns(15);
        password.addActionListener(this);
        getContentPane().add(messageL, new GridBagConstraints(0, 0, 2, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 0, 5), 0, 0));
        getContentPane().add(userIDL, new GridBagConstraints(0, 1, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 0, 5), 0, 0));
        passwordL.setHorizontalAlignment(4);
        getContentPane().add(userIDF, new GridBagConstraints(1, 1, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 5, 5), 0, 0));
        getContentPane().add(passwordL, new GridBagConstraints(0, 2, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 5, 5), 0, 0));
        passwordL.setHorizontalAlignment(4);
        getContentPane().add(password, new GridBagConstraints(1, 2, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 0, 5), 0, 0));
        JPanel buttonPanel = new JPanel();
        getContentPane().add(buttonPanel, new GridBagConstraints(0, 5, 3, 1, 1.0D, 0.0D, 10, 2, new Insets(20, 5, 5, 5), 0, 0));
        buttonPanel.setLayout(new GridBagLayout());
        loginButton = new JButton(bundle.getString("appcenter.ok"));
        loginButton.setMnemonic(bundle.getString("appcenter.ok.mnemonic").charAt(0));
        cancelButton = new JButton(bundle.getString("appcenter.cancel"));
        cancelButton.setMnemonic(bundle.getString("appcenter.cancel.mnemonic").charAt(0));
        loginButton.addActionListener(this);
        cancelButton.addActionListener(this);
        buttonPanel.add(loginButton, new GridBagConstraints(1, 0, 1, 1, 0.5D, 0.0D, 13, 0, new Insets(0, 0, 0, 3), 0, 0));
        buttonPanel.add(cancelButton, new GridBagConstraints(2, 0, 1, 1, 0.0D, 0.0D, 13, 0, new Insets(0, 0, 0, 10), 0, 0));
        setResizable(false);
        pack();
        password.requestFocus();
        setLocationRelativeTo(frame);
        setVisible(true);
    }

    private String getPassword(JPasswordField pwd)
    {
        char pass[] = pwd.getPassword();
        return new String(pass);
    }

    public String getPasswordOnPrompt()
    {
        return getPassword(password);
    }

    public void actionPerformed(ActionEvent event)
    {
        Object src = event.getSource();
        if(src == loginButton || src == password)
        {
            String pass = getPasswordOnPrompt();
            if(pass != null && pass.length() != 0)
            {
                setVisible(false);
            } else
            {
                JOptionPane.showMessageDialog(this, bundle.getString("login.passwordconfirm.error"), bundle.getString("error.dialog.title"), 0);
                password.requestFocus();
            }
        } else
        if(src == cancelButton)
            closeDialog();
    }

    private void closeDialog()
    {
        JLabel label = new JLabel(bundle.getString("login.passwordconfirm.close.msg"));
        int option = JOptionPane.showConfirmDialog(this, label, bundle.getString("login.passwordconfirm.close.title"), 0);
        if(option == 0)
            System.exit(0);
    }

    private ResourceBundle bundle;
    private JButton loginButton;
    private JButton cancelButton;
    private JPasswordField password;
    private String userName;
    private Frame frame;

}