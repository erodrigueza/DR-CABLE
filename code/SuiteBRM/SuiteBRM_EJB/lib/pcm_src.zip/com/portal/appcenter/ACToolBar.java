// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ACToolBar.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import com.portal.pfc.ui.PToolBarButton;
import java.awt.Component;
import java.util.*;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            Constants, ApplicationServices, ApplicationDescriptor, AppManager

class ACToolBar extends JToolBar
    implements Constants
{

    public ACToolBar(ApplicationServices appSvcs, Map appCtrActionMap, Map appActionMap)
    {
        mAppSvcs = appSvcs;
        mAppActionMap = appActionMap;
        mAppProps = mAppSvcs.getDescriptor().getProperties();
        mAppToken = mAppSvcs.getDescriptor().getToken();
        mACActionMap = appCtrActionMap;
        mACProps = AppManager.getProperties();
        mACRes = AppManager.getResBundle();
        setFloatable(false);
        setRollover(true);
        buildToolBar();
    }

    private void buildToolBar()
    {
        String acTBActions = mACProps.getProperty("appcenter.toolbar");
        String appTBActions = mAppProps.getProperty((new StringBuilder()).append(mAppToken).append(".toolbar").toString());
        if(acTBActions != null)
        {
            StringTokenizer tbactions = new StringTokenizer(acTBActions);
            String tbbutton = null;
            do
            {
                if(!tbactions.hasMoreElements())
                    break;
                tbbutton = tbactions.nextToken();
                if(tbbutton.equals("<CUSTOM>"))
                {
                    if(appTBActions != null)
                    {
                        StringTokenizer appTB = new StringTokenizer(appTBActions);
                        while(appTB.hasMoreElements()) 
                            createAndAddAction(appTB.nextToken(), true);
                    }
                } else
                {
                    createAndAddAction(tbbutton, false);
                }
            } while(true);
        }
    }

    private void createAndAddAction(String tbAction, boolean custom)
    {
        if(tbAction.equals("<SEP>"))
        {
            addSeparator();
            return;
        }
        if(tbAction.equals("<VSEP>"))
        {
            JSeparator vsep = new JSeparator(1);
            add(vsep);
            return;
        }
        PFCAction a = null;
        if(custom)
            a = (PFCAction)mAppActionMap.get(tbAction);
        else
            a = (PFCAction)mACActionMap.get(tbAction);
        if(a == null || !a.isConfigured())
            return;
        Component c = a.getCustomToolbarComponent();
        if(c != null)
        {
            add(c);
            return;
        }
        PToolBarButton btn = new PToolBarButton();
        btn.setAction(a);
        btn.setEnabled(a.isEnabled());
        if(a instanceof PFCAction)
        {
            String text = (String)a.getValue("toolbar_label");
            btn.setText(text);
        }
        btn.setHorizontalTextPosition(4);
        btn.setVerticalTextPosition(0);
        Icon icon = (Icon)a.getValue("SmallIcon");
        btn.setIcon(icon);
        icon = (Icon)a.getValue("disabledIcon");
        btn.setDisabledIcon(icon);
        icon = (Icon)a.getValue("pressedIcon");
        btn.setPressedIcon(icon);
        String tt = (String)a.getValue("ShortDescription");
        if(tt != null && tt.length() != 0)
            btn.setToolTipText(tt);
        add(btn);
    }

    private ApplicationServices mAppSvcs;
    private Properties mAppProps;
    private String mAppToken;
    private Map mAppActionMap;
    private Properties mACProps;
    private ResourceBundle mACRes;
    private Map mACActionMap;
}