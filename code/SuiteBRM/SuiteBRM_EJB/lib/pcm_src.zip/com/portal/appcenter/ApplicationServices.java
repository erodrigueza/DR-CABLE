// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ApplicationServices.java

package com.portal.appcenter;

import com.portal.pcm.EBufException;
import com.portal.pcm.PortalContext;
import com.portal.pfc.infranetui.InfranetStatusBar;
import com.portal.pfc.ui.PFCAction;
import com.portal.pfc.ui.StatusBar;
import com.portal.pfc.util.nestedjars.NestedJarClassLoader;
import java.beans.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import oracle.help.CSHManager;
import oracle.help.Help;
import oracle.help.htmlBrowser.ICEBrowser;
import oracle.help.library.helpset.HelpSet;

// Referenced classes of package com.portal.appcenter:
//            ACMenuBar, ACAction, AuthorizationException, ConnectionManager, 
//            Navigator, ApplicationDescriptor, AppManager, PreferenceManager, 
//            AppPanel, Application, ACProperties, ApplicationContext, 
//            ExitListener

public class ApplicationServices
{

    ApplicationServices(ApplicationDescriptor appDesc, ClassLoader classLoader, Map actionMap)
    {
        mConnections = new HashSet();
        mExitListeners = new ArrayList();
        mActive = true;
        mWindowListenersSet = new HashSet();
        mNewDefaultConnSet = false;
        mAppDesc = appDesc;
        sClassLoaderToAppSvcs.put(classLoader, this);
        mClassLoader = classLoader;
        mActionMap = actionMap;
    }

    public static ApplicationServices getServices(Object appClass)
    {
        ClassLoader cl = appClass.getClass().getClassLoader();
        ApplicationServices as = (ApplicationServices)sClassLoaderToAppSvcs.get(cl);
        return as;
    }

    public PortalContext getConnection()
        throws AuthorizationException
    {
        if(mDefaultConnection == null)
            createClonedConnection();
        return mDefaultConnection;
    }

    public String getDefaultLoginString()
    {
        ConnectionManager cm = ConnectionManager.getInstance();
        return cm.getDefaultLoginURL();
    }

    public void setConnection(PortalContext ctx)
    {
        mNewDefaultConnSet = true;
        setAsDefaultConnection(ctx);
    }

    public PortalContext createClonedConnection()
        throws AuthorizationException
    {
        ConnectionManager cm = ConnectionManager.getInstance();
        PortalContext ctx;
        if(!mNewDefaultConnSet)
        {
            ConnectionManager _tmp = cm;
            ctx = ConnectionManager.cloneConnection(cm.getDefaultConnection(mAppDesc.getToken()));
            if(mDefaultConnection == null)
                setAsDefaultConnection(ctx);
        } else
        {
            ConnectionManager _tmp1 = cm;
            ctx = ConnectionManager.cloneConnection(mDefaultConnection);
        }
        if(ctx != null)
        {
            AppManager.checkAuthorization(ctx, mAppDesc);
            mConnections.add(ctx);
        }
        return ctx;
    }

    public PortalContext createNewConnection()
        throws AuthorizationException
    {
        ConnectionManager.getInstance();
        PortalContext ctx = ConnectionManager.getNewConnection(getFrame(), false, mAppDesc.getToken());
        if(mDefaultConnection == null)
            setAsDefaultConnection(ctx);
        if(ctx != null)
        {
            AppManager.checkAuthorization(ctx, mAppDesc);
            mConnections.add(ctx);
        }
        return ctx;
    }

    public boolean isDefaultConnectionEstablished()
    {
        return ConnectionManager.getInstance().isOnline();
    }

    public boolean isOnline()
    {
        return mDefaultConnection != null;
    }

    public void closeConnections()
    {
        closeAllConnections();
    }

    public boolean isActive()
    {
        return mActive;
    }

    public ResourceBundle getResources()
    {
        return mResBundle;
    }

    public ACProperties getPreferences()
    {
        return PreferenceManager.getPreferenceManager().getPreferences();
    }

    public Properties getProperties()
    {
        return mProps;
    }

    public StatusBar getStatusBar()
    {
        return mStatusBar;
    }

    public CSHManager getCSHManager()
    {
        if(mCSHManager == null)
        {
            String helpsetName = getDescriptor().getHelpSet();
            if(helpsetName != null)
            {
                if(!helpsetName.endsWith(".hs"))
                    helpsetName = (new StringBuilder()).append(helpsetName).append(".hs").toString();
                try
                {
                    ICEBrowser icBrowser = new ICEBrowser();
                    Help mHelp = new Help(icBrowser.getClass(), false, true, false, true);
                    ClassLoader cl = getClass().getClassLoader();
                    java.net.URL url = cl.getResource(helpsetName);
                    HelpSet mHelpSet = new HelpSet(url);
                    mHelp.addBook(mHelpSet);
                    mHelp.setDefaultBook(mHelpSet);
                    mCSHManager = new CSHManager(mHelp);
                }
                catch(Exception e)
                {
                    AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("Error while loading HelpSet '").append(helpsetName).append("'").toString(), e);
                }
            }
        }
        return mCSHManager;
    }

    public static boolean isRunningUnderWebStart()
    {
        return NestedJarClassLoader.isRunningUnderWebStart();
    }

    public void setNavigatorExpanded(boolean expanded)
    {
        Navigator nav = mAppPanel.getNavigator();
        if(nav != null)
            nav.setExpanded(expanded);
    }

    public boolean isNavigatorExpanded()
    {
        Navigator nav = mAppPanel.getNavigator();
        if(nav != null)
            return nav.isExpanded();
        else
            return false;
    }

    public Logger getLogger()
    {
        if(mLogger == null)
        {
            mLogger = Logger.getLogger(getDisplayName());
            AppManager.setLoggerLevel(mLogger);
        }
        return mLogger;
    }

    public void addWindowAction(PFCAction action)
    {
        ACMenuBar mb = (ACMenuBar)mAppPanel.getMenuBar();
        mb.addWindowAction(action, -1);
    }

    public void removeWindowAction(PFCAction action)
    {
        ACMenuBar mb = (ACMenuBar)mAppPanel.getMenuBar();
        mb.removeWindowAction(action);
    }

    public synchronized void addDockUndockListener(PropertyChangeListener pcl)
    {
        getUndockPropertyChangeSupport().addPropertyChangeListener(pcl);
    }

    public synchronized void removeDockUndockListener(PropertyChangeListener pcl)
    {
        getUndockPropertyChangeSupport().removePropertyChangeListener(pcl);
    }

    public synchronized void addActiveInactiveListener(PropertyChangeListener pcl)
    {
        getActivatedPropertyChangeSupport().addPropertyChangeListener(pcl);
    }

    public synchronized void removeActiveInactiveListener(PropertyChangeListener pcl)
    {
        getActivatedPropertyChangeSupport().removePropertyChangeListener(pcl);
    }

    public void setCurrentDocumentActive(String s)
    {
    }

    public void switchToApplication(ApplicationContext applicationcontext)
    {
    }

    public void makeVisible()
    {
    }

    public JFrame getFrame()
    {
        return AppManager.getInstance().getFrameByApp(getApplication());
    }

    public ApplicationDescriptor getDescriptor()
    {
        return mAppDesc;
    }

    public void addExitListener(ExitListener listener)
    {
        mExitListeners.add(listener);
    }

    public void removeExitListener(ExitListener listener)
    {
        mExitListeners.remove(listener);
    }

    public String getDisplayName()
    {
        if(mDisplayName == null)
            mDisplayName = mAppDesc.getName();
        return mDisplayName;
    }

    public boolean exitApplication()
    {
        return AppManager.getInstance().close(mApp);
    }

    public ACAction getApplicationAction(String actionToken)
    {
        return (ACAction)mActionMap.get(actionToken);
    }

    public Collection getApplicationActions()
    {
        return mActionMap.values();
    }

    void releaseResources()
    {
        closeAllConnections();
    }

    Application getApplication()
    {
        return mApp;
    }

    void setApplication(Application app)
    {
        if(mApp == null)
            mApp = app;
    }

    void setResourceBundle(ResourceBundle res)
    {
        mResBundle = res;
    }

    void setProperties(Properties props)
    {
        mProps = props;
    }

    void setAppPanel(AppPanel appPanel)
    {
        mAppPanel = appPanel;
    }

    void setDisplayName(String displayName)
    {
        mDisplayName = displayName;
    }

    List getExitListeners()
    {
        return mExitListeners;
    }

    void setStatusBar(StatusBar sb)
    {
        mStatusBar = sb;
    }

    void addApplicationAction(ACAction action)
    {
        if(action == null)
        {
            throw new NullPointerException((new StringBuilder()).append("Action '").append(action).append("' is null").toString());
        } else
        {
            String token = action.getToken();
            int pos = token.lastIndexOf('.');
            String newToken = token.substring(pos + 1, token.length());
            mActionMap.put(newToken, action);
            return;
        }
    }

    PropertyChangeSupport getUndockPropertyChangeSupport()
    {
        if(mUndockPropChangeSupport == null)
            mUndockPropChangeSupport = new PropertyChangeSupport(this);
        return mUndockPropChangeSupport;
    }

    PropertyChangeSupport getActivatedPropertyChangeSupport()
    {
        if(mActivatePropChangeSupport == null)
            mActivatePropChangeSupport = new PropertyChangeSupport(this);
        return mActivatePropChangeSupport;
    }

    Set getWindowListenersSet()
    {
        return mWindowListenersSet;
    }

    static ClassLoader getClassLoaderFor(ApplicationDescriptor ad)
    {
        for(Iterator i = sClassLoaderToAppSvcs.keySet().iterator(); i.hasNext();)
        {
            ClassLoader keyCL = (ClassLoader)i.next();
            ApplicationServices valAppSvcs = (ApplicationServices)sClassLoaderToAppSvcs.get(keyCL);
            if(valAppSvcs.getDescriptor() == ad)
                return keyCL;
        }

        return null;
    }

    private void trackActiveState()
    {
        addActiveInactiveListener(new PropertyChangeListener() {

            public void propertyChange(PropertyChangeEvent e)
            {
                if(e.getClass().equals("ACTIVE"))
                    mActive = true;
                else
                if(e.getClass().equals("INACTIVE"))
                    mActive = false;
            }

            final ApplicationServices this$0;

            
            {
                this$0 = ApplicationServices.this;
                super();
            }
        }
);
    }

    private void setAsDefaultConnection(PortalContext conn)
    {
        if(conn == null)
            return;
        mDefaultConnection = conn;
        StatusBar sb = getStatusBar();
        if(sb instanceof InfranetStatusBar)
            ((InfranetStatusBar)sb).setConnectStatus(true, conn);
    }

    private void closeAllConnections()
    {
        PortalContext ctx = null;
        for(Iterator i = mConnections.iterator(); i.hasNext();)
        {
            ctx = (PortalContext)i.next();
            try
            {
                ctx.close(true);
            }
            catch(EBufException ex) { }
        }

        mDefaultConnection = null;
        mNewDefaultConnSet = false;
        StatusBar sb = getStatusBar();
        if(sb instanceof InfranetStatusBar)
            ((InfranetStatusBar)sb).setConnectStatus(false, null);
    }

    private ApplicationDescriptor mAppDesc;
    private ResourceBundle mResBundle;
    private Properties mProps;
    private Application mApp;
    private AppPanel mAppPanel;
    private StatusBar mStatusBar;
    private PortalContext mDefaultConnection;
    private Set mConnections;
    private String mDefaultLogin;
    private String mDefaultHost;
    private String mDefaultPort;
    private String mDisplayName;
    private List mExitListeners;
    private Map mActionMap;
    private PropertyChangeSupport mUndockPropChangeSupport;
    private PropertyChangeSupport mActivatePropChangeSupport;
    private CSHManager mCSHManager;
    private ClassLoader mClassLoader;
    private Logger mLogger;
    private boolean mActive;
    private Set mWindowListenersSet;
    private static Map sClassLoaderToAppSvcs = new HashMap();
    private boolean mNewDefaultConnSet;


}