// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AppCenterFrame.java

package com.portal.appcenter;

import com.portal.pfc.ui.StatusBar;
import com.portal.pfc.ui.SwingHelper;
import java.awt.*;
import java.awt.event.WindowListener;
import java.io.PrintStream;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            ACMenuBar, PrimaryAppCenterFrame, Constants, ApplicationServices, 
//            AppPanel, Application, AppManager, ApplicationDescriptor, 
//            PreferenceManager, ACProperties

public class AppCenterFrame extends JFrame
    implements Constants
{

    public AppCenterFrame()
    {
    }

    public void addWindowListener(WindowListener l, ApplicationServices as)
    {
        if(l == null || as == null)
        {
            return;
        } else
        {
            as.getWindowListenersSet().add(l);
            super.addWindowListener(l);
            return;
        }
    }

    public void removeWindowListener(WindowListener l, ApplicationServices as)
    {
        if(l == null || as == null)
        {
            return;
        } else
        {
            as.getWindowListenersSet().remove(l);
            super.removeWindowListener(l);
            return;
        }
    }

    void setInitialApp(AppPanel appPanel, boolean undocked)
    {
        mAppPanel = appPanel;
        mUndocked = undocked;
        JPanel p = new JPanel(new BorderLayout());
        getContentPane().add(p);
        addApp(p, appPanel);
        if(mUndocked)
            setTitle(appPanel.getApplication().getApplicationServices().getDisplayName());
        else
            setTitle(AppManager.getProperties().getProperty("suite.name"));
        Image i = appPanel.getApplication().getApplicationServices().getDescriptor().getIcon();
        setIconImage(i);
        if(mUndocked)
        {
            ACMenuBar menu = (ACMenuBar)appPanel.getMenuBar();
            menu.removeLaunchMenuAction();
            menu.removeExitAction();
            menu.removeUndockAction();
            menu.addDockAction();
        }
        setBounds();
    }

    Application getCurrentApp()
    {
        if(!$assertionsDisabled && mAppPanel == null)
            throw new AssertionError();
        else
            return mAppPanel.getApplication();
    }

    void addApp(JPanel p, AppPanel appPanel)
    {
        JPanel toolbarPanel = appPanel.getToolBarPanel();
        addApp(p, appPanel, ((JComponent) (toolbarPanel)));
    }

    void addApp(JPanel p, AppPanel appPanel, JComponent tbPanel)
    {
        JMenuBar mb = appPanel.getMenuBar();
        StatusBar sb = appPanel.getStatusBar();
        p.setLayout(new BorderLayout());
        p.setName("container for AppPanel, menubar&toolbar panel, status bar");
        p.add(appPanel, "Center");
        JPanel controlP = new JPanel();
        controlP.setName("menubar & toolbar panel");
        controlP.setLayout(new BorderLayout());
        controlP.add(mb, "North");
        controlP.add(tbPanel, "South");
        controlP.setBorder(BorderFactory.createEtchedBorder());
        p.add(controlP, "North");
        if(sb != null)
            p.add(sb, "South");
    }

    AppPanel getAppPanel()
    {
        return mAppPanel;
    }

    void close()
    {
        Rectangle bounds = getBounds();
        String className = getCurrentApp().getApplicationServices().getDescriptor().getClassName();
        PreferenceManager.getPreferenceManager().getPreferences().setBoundsPreference(className, bounds);
        mAppPanel = null;
        setVisible(false);
        dispose();
    }

    protected void setBounds()
    {
        boolean maximized = true;
        int width = 800;
        int height = 600;
        int xpos = 0;
        int ypos = 0;
        if(!mUndocked)
        {
            Properties acProps = AppManager.getProperties();
            String w = acProps.getProperty("appcenter.frame.width");
            String h = acProps.getProperty("appcenter.frame.height");
            String m = acProps.getProperty("appcenter.frame.maximized");
            try
            {
                width = w == null ? width : Integer.parseInt(w);
                height = h == null ? height : Integer.parseInt(h);
                maximized = m == null ? maximized : Boolean.valueOf(m).booleanValue();
            }
            catch(NumberFormatException nfe)
            {
                AppManager.getLogger().log(Level.WARNING, "Couldn't parse width, height or maximized property ");
            }
            w = h = m = null;
            ResourceBundle acRes = AppManager.getResBundle();
            try
            {
                w = acRes.getString("appcenter.frame.width");
            }
            catch(MissingResourceException mre) { }
            try
            {
                h = acRes.getString("appcenter.frame.height");
            }
            catch(MissingResourceException mre) { }
            try
            {
                m = acRes.getString("appcenter.frame.maximized");
            }
            catch(MissingResourceException mre) { }
            try
            {
                width = w == null ? width : Integer.parseInt(w);
                height = h == null ? height : Integer.parseInt(h);
                maximized = m == null ? maximized : Boolean.valueOf(m).booleanValue();
            }
            catch(NumberFormatException nfe)
            {
                System.out.println("Couldn't parse width, height or maximized resource ");
            }
            w = h = m = null;
            Rectangle bounds;
            if(this instanceof PrimaryAppCenterFrame)
            {
                bounds = PreferenceManager.getPreferenceManager().getPreferences().getBoundsPreference("appcenter.frame");
            } else
            {
                String appClassName = getCurrentApp().getApplicationServices().getDescriptor().getClassName();
                bounds = PreferenceManager.getPreferenceManager().getPreferences().getBoundsPreference(appClassName);
            }
            if(bounds != null)
            {
                width = bounds.width;
                height = bounds.height;
                xpos = bounds.x;
                ypos = bounds.y;
            }
            pack();
            setSize(width, height);
            if(bounds == null && maximized && Toolkit.getDefaultToolkit().isFrameStateSupported(6))
                setExtendedState(6);
            else
            if(bounds == null)
                SwingHelper.centerFrame(this);
            else
                setLocation(xpos, ypos);
        } else
        {
            String appClassName = getCurrentApp().getApplicationServices().getDescriptor().getClassName();
            Rectangle bounds = PreferenceManager.getPreferenceManager().getPreferences().getBoundsPreference(appClassName);
            if(bounds != null)
            {
                width = bounds.width;
                height = bounds.height;
                xpos = bounds.x;
                ypos = bounds.y;
            }
            pack();
            setSize(width, height);
            if(bounds == null)
            {
                Point pt = getLocation();
                int randOffset = sRandom.nextInt(75);
                pt.translate(30 + randOffset, 30 + randOffset);
                setLocation(pt);
            } else
            {
                setLocation(xpos, ypos);
            }
        }
    }

    private AppPanel mAppPanel;
    private boolean mUndocked;
    private static final int DEFAULT_WIDTH = 800;
    private static final int DEFAULT_HEIGHT = 600;
    private static final int HORIZ_OFFSET = 30;
    private static final int VERT_OFFSET = 30;
    private static Random sRandom = new Random();
    private static final int UPPER_BOUND = 75;
    private static final boolean DEFAULT_MAXIMIZED = true;
    static final boolean $assertionsDisabled = !com/portal/appcenter/AppCenterFrame.desiredAssertionStatus();

}