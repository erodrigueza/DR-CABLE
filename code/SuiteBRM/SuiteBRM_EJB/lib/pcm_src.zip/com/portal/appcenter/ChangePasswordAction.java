// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ChangePasswordAction.java

package com.portal.appcenter;

import com.portal.pcm.PortalContext;
import com.portal.pfc.ui.PFCAction;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

// Referenced classes of package com.portal.appcenter:
//            PasswordChangeDialog, AuthorizationException, AppManager, Application, 
//            ApplicationServices

class ChangePasswordAction extends PFCAction
{

    ChangePasswordAction(String token, Properties properties, ResourceBundle rb)
    {
        super(token, properties, rb);
    }

    public void actionPerformed(ActionEvent ae)
    {
        JFrame frame = AppManager.getInstance().getMainFrame();
        Properties suiteProps = AppManager.getInstance().getSuiteProperties();
        String appName = suiteProps.getProperty("name");
        if(appName == null)
            appName = AppManager.getResBundle().getString("login.title");
        PortalContext ctx = null;
        try
        {
            ctx = AppManager.getInstance().getAppByFrame(frame).getApplicationServices().getConnection();
            PasswordChangeDialog dlg = new PasswordChangeDialog(frame, ctx, ctx.getReasonCode(), ctx.getUserName(), appName);
        }
        catch(AuthorizationException e)
        {
            AppManager.getLogger().log(Level.SEVERE, "Error while getting appcenter context", e);
        }
    }
}