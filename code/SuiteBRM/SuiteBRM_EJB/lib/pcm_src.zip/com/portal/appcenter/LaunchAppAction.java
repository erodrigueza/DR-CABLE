// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LaunchAppAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;

// Referenced classes of package com.portal.appcenter:
//            ApplicationDescriptor, AppManager

class LaunchAppAction extends PFCAction
{

    LaunchAppAction(String token, Properties properties, ResourceBundle rb, ApplicationDescriptor appDesc)
    {
        super(token, properties, rb);
        mAppDesc = appDesc;
        putValue("Name", appDesc.getName());
        putValue("SmallIcon", new ImageIcon(appDesc.getIcon()));
    }

    public void actionPerformed(ActionEvent ae)
    {
        AppManager.getInstance().launch(mAppDesc);
    }

    private ApplicationDescriptor mAppDesc;
}