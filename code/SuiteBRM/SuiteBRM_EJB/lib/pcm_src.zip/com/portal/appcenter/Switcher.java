// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Switcher.java

package com.portal.appcenter;

import com.portal.pfc.ui.*;
import java.awt.*;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.*;
import javax.swing.*;
import javax.swing.border.Border;

// Referenced classes of package com.portal.appcenter:
//            Launcher, AppManager, SwitchAction

class Switcher extends JPanel
    implements ComponentListener
{
    class TopBorder
        implements Border
    {

        public boolean isBorderOpaque()
        {
            return true;
        }

        public Insets getBorderInsets(Component c)
        {
            return new Insets(0, 0, 0, 0);
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
        {
            w--;
            h--;
            g.setColor(m_borderColor);
            g.drawLine(x, y, x + w, y);
        }

        protected int m_w;
        protected int m_h;
        protected Color m_borderColor;
        final Switcher this$0;

        TopBorder()
        {
            this$0 = Switcher.this;
            super();
            m_w = 6;
            m_h = 6;
            m_borderColor = new Color(113, 111, 100);
        }
    }

    class OvalBorder
        implements Border
    {

        public Insets getBorderInsets(Component c)
        {
            return new Insets(1, 1, 1, 1);
        }

        public boolean isBorderOpaque()
        {
            return true;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
        {
            g.setColor(m_borderColor);
            g.drawLine(x, (y + h) - m_h, x, y + m_h);
            g.drawLine(x + m_w, y, x + w, y);
            g.setColor(m_roundedBorderColor);
            g.drawArc(x, y, 2 * m_w, 2 * m_h, 180, -90);
            g.drawArc(x, (y + h) - 2 * m_h, 2 * m_w, 2 * m_h, -90, -90);
            g.setColor(m_fillColor);
            g.fillRect(x + 1, y + m_h, w, h - 2 * m_h);
            g.fillArc(x + 1, y, 2 * m_w, 2 * m_h, 180, -90);
            g.fillArc(x, (y + h) - 2 * m_h, 2 * m_w, 2 * m_h, -90, -90);
            g.fillRect(x + m_w, y + 1, w - m_w, m_h);
            g.fillRect(x + m_w, (y + h) - m_h, w - m_w, m_h);
        }

        protected int m_w;
        protected int m_h;
        Color bg;
        protected Color m_borderColor;
        protected Color m_roundedBorderColor;
        protected Color m_fillColor;
        final Switcher this$0;

        OvalBorder()
        {
            this$0 = Switcher.this;
            super();
            m_w = 6;
            m_h = 6;
            bg = UIManager.getColor("Panel.background");
            m_borderColor = bg.darker();
            m_roundedBorderColor = bg;
            m_fillColor = bg.darker();
            m_w = 6;
            m_h = 6;
        }

        OvalBorder(int w, int h)
        {
            this$0 = Switcher.this;
            super();
            m_w = 6;
            m_h = 6;
            bg = UIManager.getColor("Panel.background");
            m_borderColor = bg.darker();
            m_roundedBorderColor = bg;
            m_fillColor = bg.darker();
            m_w = w;
            m_h = h;
        }
    }


    Switcher()
    {
        mToolbarBtnList = new Vector();
        mDropDownBtnList = new Stack();
        mbShowAppNames = false;
        mDisplayHomePageIcon = true;
        try
        {
            jbInit();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        addComponentListener(this);
    }

    private void jbInit()
        throws Exception
    {
        mLauncher = new Launcher();
        mGrouper = new ButtonGroup();
        mDropDown = new PDropDown(null);
        mBtnBox = new JPanel(new FlowLayout(0, 5, 2));
        mBtnBox.setBorder(new OvalBorder(3, 3));
        setLayout(new GridBagLayout());
        add(mLauncher, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
        add(mBtnBox, new GridBagConstraints(1, 0, 1, 1, 1.0D, 1.0D, 10, 1, new Insets(0, 0, 0, 0), 0, 0));
        add(mDropDown, new GridBagConstraints(2, 0, 1, 1, 0.0D, 0.0D, 10, 3, new Insets(0, 0, 0, 0), 0, 0));
        mDropDown.setVisible(false);
        mDropDown.setRolloverEnabled(false);
        mDropDown.setBackground(UIManager.getColor("Panel.background"));
        mDropDown.setBorder(new TopBorder());
        String dispProp = AppManager.getInstance().getSuiteProperties().getProperty("display.homepage");
        if(dispProp != null && dispProp.equals("false"))
            mDisplayHomePageIcon = false;
        if(mDisplayHomePageIcon)
        {
            java.awt.Image iconImage = PFCImage.getImage(getClass(), "/com/portal/appcenter/images/home_default.gif");
            mHomePageBtn = new PToolBarToggleButton(new ImageIcon(iconImage));
            add(mHomePageBtn, new GridBagConstraints(3, 0, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(0, 0, 0, 0), 0, 0));
            mGrouper.add(mHomePageBtn);
        }
    }

    boolean isHomePageIconDisplayed()
    {
        return mDisplayHomePageIcon;
    }

    void setHomePageSwitchAction(SwitchAction sa)
    {
        if(mDisplayHomePageIcon)
        {
            if(!$assertionsDisabled && mHomePageBtn == null)
                throw new AssertionError();
            javax.swing.Icon i = mHomePageBtn.getIcon();
            mHomePageBtn.setAction(sa);
            mHomePageBtn.setIcon(i);
            mHomePageBtn.setText(null);
        }
    }

    void addItem(Action action)
    {
        PToolBarToggleButton btnToAdd = new PToolBarToggleButton(action);
        btnToAdd.setOpaque(false);
        if(!mbShowAppNames)
            btnToAdd.setText("");
        int btnWidth = btnToAdd.getPreferredSize().width + 5;
        if(!mToolbarBtnList.isEmpty())
        {
            Insets insets = mBtnBox.getInsets();
            int availableWidth = mBtnBox.getWidth() - (insets.left + insets.right);
            int widthInUse = 0;
            Component comps[] = mBtnBox.getComponents();
            for(int i = 0; i < comps.length; i++)
                widthInUse += comps[i].getPreferredSize().width + 5;

            JToggleButton lastVisibleBtn;
            for(widthInUse += 5; widthInUse + btnWidth > availableWidth && mToolbarBtnList.size() > 0; addToDropdown(lastVisibleBtn))
            {
                lastVisibleBtn = (JToggleButton)mToolbarBtnList.remove(mToolbarBtnList.size() - 1);
                widthInUse -= lastVisibleBtn.getPreferredSize().width + 5;
                mBtnBox.remove(lastVisibleBtn);
            }

        }
        addToToolbar(btnToAdd);
        int firstBtnWidth = ((JToggleButton)mToolbarBtnList.elementAt(0)).getPreferredSize().width;
        Insets insets = mBtnBox.getInsets();
        mBtnBox.setMinimumSize(new Dimension(firstBtnWidth + 10 + insets.left + insets.right, getHeight()));
    }

    void removeItem(Action action)
    {
        for(int i = 0; i < mToolbarBtnList.size(); i++)
            if(((JToggleButton)mToolbarBtnList.get(i)).getAction().equals(action))
            {
                mToolbarBtnList.remove(i);
                mBtnBox.remove(i);
                return;
            }

        for(int index = 0; index < mDropDownBtnList.size(); index++)
            if(((JToggleButton)mDropDownBtnList.get(index)).getAction().equals(action))
            {
                mDropDownBtnList.remove(index);
                updatePopup();
                return;
            }

    }

    void setSelectedItem(Action a)
    {
        for(int i = 0; i < mToolbarBtnList.size(); i++)
            if(((JToggleButton)mToolbarBtnList.get(i)).getAction().equals(a))
            {
                ((JToggleButton)mToolbarBtnList.get(i)).setSelected(true);
                ((JToggleButton)mToolbarBtnList.get(i)).requestFocusInWindow();
                return;
            }

        JToggleButton btnToMakeVisible = null;
        int index = 0;
        do
        {
            if(index >= mDropDownBtnList.size())
                break;
            if(((JToggleButton)mDropDownBtnList.get(index)).getAction().equals(a))
            {
                btnToMakeVisible = (JToggleButton)mDropDownBtnList.get(index);
                break;
            }
            index++;
        } while(true);
        if(btnToMakeVisible != null)
        {
            makeBtnVisible(btnToMakeVisible);
            btnToMakeVisible.setSelected(true);
            btnToMakeVisible.requestFocusInWindow();
        }
    }

    void showApplicationNames(boolean showAppNames)
    {
        Component comps[] = mBtnBox.getComponents();
        mbShowAppNames = showAppNames;
        if(comps.length == 0)
            return;
        for(int i = 0; i < comps.length; i++)
        {
            PToolBarToggleButton btn = (PToolBarToggleButton)comps[i];
            if(showAppNames)
                btn.setText((String)btn.getAction().getValue("Name"));
            else
                btn.setText("");
        }

        int firstBtnWidth = ((JToggleButton)mToolbarBtnList.elementAt(0)).getPreferredSize().width;
        Insets insets = mBtnBox.getInsets();
        mBtnBox.setMinimumSize(new Dimension(firstBtnWidth + 10 + insets.left + insets.right, getHeight()));
    }

    public void componentResized(ComponentEvent e)
    {
label0:
        {
            Insets insets = mBtnBox.getInsets();
            int maxwidth = mBtnBox.getWidth() - (insets.left + insets.right + 10);
            int x = 0;
            boolean bRemoveRest = false;
            JToggleButton selectedBtn = null;
            for(Iterator iter = mToolbarBtnList.iterator(); iter.hasNext();)
            {
                JToggleButton item = (JToggleButton)iter.next();
                Dimension d = item.getPreferredSize();
                if(bRemoveRest)
                {
                    if(item.isSelected())
                        selectedBtn = item;
                    mBtnBox.remove(item);
                    mGrouper.remove(item);
                    iter.remove();
                    addToDropdown(item);
                } else
                if(x == 0 || x + d.width <= maxwidth)
                {
                    if(x > 0)
                        x += 5;
                    x += d.width;
                } else
                {
                    if(item.isSelected())
                        selectedBtn = item;
                    mBtnBox.remove(item);
                    mGrouper.remove(item);
                    iter.remove();
                    addToDropdown(item);
                }
            }

            if(selectedBtn != null)
            {
                makeBtnVisible(selectedBtn);
                selectedBtn.setSelected(true);
                selectedBtn.requestFocusInWindow();
            }
            if(x >= maxwidth || bRemoveRest)
                break label0;
            JToggleButton item;
            do
            {
                if(mDropDownBtnList.empty())
                    break label0;
                item = (JToggleButton)mDropDownBtnList.pop();
                Dimension d = item.getPreferredSize();
                if(x + d.width > maxwidth)
                    break;
                x += d.width + 5;
                addToToolbar(item);
                updatePopup();
            } while(true);
            mDropDownBtnList.push(item);
        }
    }

    public void componentMoved(ComponentEvent componentevent)
    {
    }

    public void componentShown(ComponentEvent componentevent)
    {
    }

    public void componentHidden(ComponentEvent componentevent)
    {
    }

    private void makeBtnVisible(JToggleButton btnToMakeVisible)
    {
        JToggleButton lastVisibleBtn = (JToggleButton)mToolbarBtnList.remove(mToolbarBtnList.size() - 1);
        mBtnBox.remove(lastVisibleBtn);
        mDropDownBtnList.remove(btnToMakeVisible);
        updatePopup();
        addToDropdown(lastVisibleBtn);
        addToToolbar(btnToMakeVisible);
    }

    private void addToToolbar(JToggleButton btnToAdd)
    {
        mToolbarBtnList.add(btnToAdd);
        if(mBtnBox.getComponentCount() == 0)
        {
            Insets insets = mBtnBox.getInsets();
            int btnWidth = btnToAdd.getPreferredSize().width;
            mBtnBox.setMinimumSize(new Dimension(btnWidth + 10 + insets.left + insets.right, getHeight()));
            if(getParent() instanceof JSplitPane)
                ((JSplitPane)getParent()).resetToPreferredSizes();
        }
        mBtnBox.add(btnToAdd);
        mGrouper.add(btnToAdd);
        showApplicationNames(mbShowAppNames);
    }

    private void addToDropdown(JToggleButton btn)
    {
        JMenuItem item = new JMenuItem(btn.getAction());
        mDropDownBtnList.push(btn);
        updatePopup();
    }

    private void updatePopup()
    {
        int count = mDropDownBtnList.size();
        if(mDropDownBtnList.isEmpty())
            mDropDown.setVisible(false);
        else
            mDropDown.setVisible(true);
        JMenuItem newMenuList[] = new JMenuItem[count];
        for(int i = 0; i < count; i++)
            newMenuList[i] = new JMenuItem(((JToggleButton)mDropDownBtnList.get(i)).getAction());

        mDropDown.setData(newMenuList);
    }

    private Vector mToolbarBtnList;
    private Stack mDropDownBtnList;
    private Launcher mLauncher;
    PToolBarToggleButton mHomePageBtn;
    private PDropDown mDropDown;
    private JPanel mBtnBox;
    private ButtonGroup mGrouper;
    private boolean mbShowAppNames;
    private static final int HGAP = 5;
    static final int VGAP = 2;
    private boolean mDisplayHomePageIcon;
    static final boolean $assertionsDisabled = !com/portal/appcenter/Switcher.desiredAssertionStatus();

}