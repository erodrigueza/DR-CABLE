// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ConnectionManager.java

package com.portal.appcenter;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import com.portal.pfc.infranet.restriction.Restriction;
import com.portal.pfc.infranet.restriction.RestrictionManager;
import java.awt.Frame;
import java.net.URLDecoder;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

// Referenced classes of package com.portal.appcenter:
//            LoginFrame, LoginDialog, BRMClientContext, Constants, 
//            AppManager

class ConnectionManager
    implements ChangeListener, Constants
{

    private ConnectionManager()
    {
        mOnline = false;
        mTriedToLogin = false;
        Properties suiteProps = AppManager.getInstance().getSuiteProperties();
        loginTitle = suiteProps.getProperty("name");
        if(loginTitle == null)
            loginTitle = AppManager.getResBundle().getString("login.title");
        mainLoginDlg = new LoginFrame(loginTitle, offlineAllowed(), "appcenter");
        mainLoginDlg.addChangeListener(this);
        mainLoginDlg.setVisible(true);
    }

    boolean offlineAllowed()
    {
        String val = AppManager.getInstance().getSuiteProperties().getProperty("offline.allowed");
        return val != null && val.trim().equals("true");
    }

    static ConnectionManager getInstance()
    {
        if(mConnMgr == null)
            mConnMgr = new ConnectionManager();
        return mConnMgr;
    }

    void addLoginListener(ChangeListener l)
    {
        mainLoginDlg.addChangeListener(l);
    }

    public void stateChanged(ChangeEvent e)
    {
        mTriedToLogin = true;
        mainLoginDlg.removeChangeListener(this);
        mainLoginDlg.setVisible(false);
        mDefaultConnection = mainLoginDlg.getPortalContext();
        mDefaultConnectionString = mainLoginDlg.getLoginURL();
        if(mDefaultConnection != null && mDefaultConnection.getUserID().getId() != 2L)
        {
            Map appDescMap = AppManager.getInstance().getConfiguredApps();
            Set appTokenSet = appDescMap.keySet();
            RestrictionManager mgr = RestrictionManager.getInstance(mDefaultConnection);
            Iterator iter = appTokenSet.iterator();
            boolean toLoad = false;
            do
            {
                if(!iter.hasNext())
                    break;
                String appToken = (String)iter.next();
                String permString = (new StringBuilder()).append("/appcenter/").append(appToken).toString();
                Restriction perm = mgr.getRestriction(permString, null);
                if(perm.getViewRestriction() == 0)
                    continue;
                toLoad = true;
                break;
            } while(true);
            if(!toLoad)
            {
                String errMsgStr = AppManager.getResBundle().getString("error.suite.permission.denied");
                Object arg[] = {
                    mDefaultConnection.getUserName(), mDefaultConnection.getHost(), mDefaultConnection.getPort()
                };
                String errMsg = MessageFormat.format(errMsgStr, arg);
                JOptionPane.showMessageDialog(null, errMsg, AppManager.getResBundle().getString("error.dialog.title"), 0);
                System.exit(1);
            }
        }
        if(mDefaultConnection == null)
            mOnline = false;
        else
            mOnline = true;
        mainLoginDlg = null;
    }

    PortalContext getDefaultConnection(String appToken)
    {
        if(mDefaultConnection == null)
        {
            Frame parent = AppManager.getInstance().getMainFrame();
            LoginDialog loginDlg = new LoginDialog(parent, loginTitle, offlineAllowed(), appToken);
            loginDlg.setVisible(true);
            mDefaultConnection = loginDlg.getPortalContext();
            mDefaultConnectionString = loginDlg.getLoginURL();
        }
        return mDefaultConnection;
    }

    String getDefaultLoginURL()
    {
        return mDefaultConnectionString;
    }

    static PortalContext getNewConnection(Frame parent, boolean okToWorkOffline, String appToken)
    {
        LoginDialog loginDlg = new LoginDialog(parent, loginTitle, okToWorkOffline, appToken);
        loginDlg.setVisible(true);
        return loginDlg.getPortalContext();
    }

    static PortalContext connect(String url)
    {
        try
        {
            FList loginParams = new FList();
            PortalContext.parseConnectString(url, loginParams);
            if(loginParams.hasField(FldLogin.getInst()))
            {
                String login = loginParams.get(FldLogin.getInst());
                loginParams.set(FldLogin.getInst(), URLDecoder.decode(login));
            }
            if(loginParams.hasField(FldPasswdClear.getInst()))
            {
                String passwd = loginParams.get(FldPasswdClear.getInst());
                loginParams.set(FldPasswdClear.getInst(), URLDecoder.decode(passwd));
            }
            String fail = null;
            for(int i = 1; (fail = PortalContext.getUserProperty((new StringBuilder()).append("failover.").append(i).toString())) != null; i++)
            {
                if(fail == null || fail.length() == 0)
                {
                    AppManager.getLogger().warning((new StringBuilder()).append("Infranet.properties value specified by 'infranet.failover.").append(i).append("' is empty").toString());
                    continue;
                }
                try
                {
                    PortalContext.parseConnectString(fail, loginParams);
                }
                catch(ParseException pex)
                {
                    AppManager.getLogger().warning((new StringBuilder()).append("Infranet.properties value specified by 'infranet.failover.").append(i).append("' is invalid").toString());
                }
            }

            loginParams.set(FldType.getInst(), new Integer(1));
            PortalContext conn = new BRMClientContext(loginParams);
            return conn;
        }
        catch(EBufException e)
        {
            ebuf = e;
            return null;
        }
        catch(Exception ex)
        {
            AppManager.getLogger().log(Level.SEVERE, "Connection to Portal failed", ex);
        }
        return null;
    }

    static PortalContext connectToServer(String url)
        throws EBufException
    {
        PortalContext context = connect(url);
        if(context == null && ebuf != null)
            throw ebuf;
        else
            return context;
    }

    static PortalContext cloneConnection(PortalContext ctx)
    {
        if(ctx == null)
            return null;
        PortalContext newCtx;
        try
        {
            newCtx = ctx.cloneConnection();
        }
        catch(Exception ex)
        {
            newCtx = null;
        }
        return newCtx;
    }

    void closeDefaultConnection()
    {
        if(mDefaultConnection != null)
            try
            {
                mDefaultConnection.close(true);
            }
            catch(EBufException ex) { }
    }

    boolean isOnline()
    {
        return mOnline;
    }

    private static ConnectionManager mConnMgr;
    private static PortalContext mDefaultConnection;
    private boolean mOnline;
    private boolean mTriedToLogin;
    private static LoginFrame mainLoginDlg;
    private static String loginTitle;
    private String mDefaultConnectionString;
    private static EBufException ebuf = null;

}