// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AboutAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.AboutDialog;
import com.portal.pfc.ui.PFCAction;
import com.portal.pfc.ui.PFCDialog;
import com.portal.pfc.ui.SwingHelper;
import com.portal.pfc.util.PI18nHelper;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

// Referenced classes of package com.portal.appcenter:
//            ApplicationDescriptorTableModel, LoggingPanel, ApplicationDescriptor, AppManager

class AboutAction extends PFCAction
{

    public AboutAction(String tok, Properties p, ResourceBundle rb)
    {
        super(tok, p, rb);
    }

    public void actionPerformed(ActionEvent ae)
    {
        createInfoPanel();
        createAboutDlg();
        JFrame currFrame = SwingHelper.getFrame((Component)ae.getSource());
        if(currFrame == mDlg.getParent())
            mDlg.setVisible(true);
        else
            (new AboutDialog(currFrame, mInfoPanel)).setVisible(true);
    }

    private void createAboutDlg()
    {
        if(mDlg == null)
        {
            JFrame mainFrame = AppManager.getInstance().getMainFrame();
            String title = null;
            try
            {
                ResourceBundle resource = ResourceBundle.getBundle("com.portal.pfc.ui.UIResources");
                title = (new StringBuilder()).append(resource.getString("dialog.about.dialogtitle")).append(" ").append(AppManager.getProperties().getProperty("suite.name")).toString();
            }
            catch(MissingResourceException e)
            {
                AppManager.getLogger().log(Level.WARNING, "Missing Resouce for setting About title", e);
            }
            mDlg = new AboutDialog(mainFrame, title, null, mInfoPanel);
        }
    }

    private void createInfoPanel()
    {
        if(mInfoPanel == null)
        {
            GridBagLayout gbc = new GridBagLayout();
            GridBagConstraints c = new GridBagConstraints();
            mInfoPanel = new JPanel(gbc);
            java.util.List apps = new ArrayList(AppManager.getInstance().getConfiguredApps().values());
            ApplicationDescriptor ha = AppManager.getInstance().getHomeAppDescriptor();
            if(ha != null && !"com.portal.appcenter.HomeApplication".equals(ha.getClassName()))
                apps.add(0, ha);
            javax.swing.table.TableModel tm = new ApplicationDescriptorTableModel(apps);
            TableCellRenderer renderer = new TableCellRenderer() {

                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
                {
                    return (JLabel)value;
                }

                final AboutAction this$0;

            
            {
                this$0 = AboutAction.this;
                super();
            }
            }
;
            JTable tbl = new JTable(tm);
            TableColumnModel cm = tbl.getColumnModel();
            TableColumn tc = cm.getColumn(0);
            tc.setCellRenderer(renderer);
            tbl.setPreferredScrollableViewportSize(new Dimension(350, 60));
            JScrollPane scroller = new JScrollPane(tbl);
            String tblNameStr = (new StringBuilder()).append(AppManager.getResBundle().getString("appcenter.action.about.tblname")).append(" ").append(AppManager.getProperties().getProperty("suite.name")).toString();
            JLabel tblName = new JLabel(tblNameStr);
            PI18nHelper.setFontStyle(tblName, 1);
            c.gridx = c.gridy = 0;
            c.insets = new Insets(3, 0, 10, 0);
            c.anchor = 17;
            c.ipady = 3;
            mInfoPanel.add(tblName, c);
            c.gridy++;
            c.insets = new Insets(0, 0, 0, 0);
            mInfoPanel.add(scroller, c);
            JLabel appctr = new JLabel(AppManager.getResBundle().getString("appcenter.action.about.appctrfwk"));
            PI18nHelper.setFontStyle(appctr, 1);
            c.gridy++;
            mInfoPanel.add(appctr, c);
            FlowLayout fl = new FlowLayout();
            fl.setHgap(0);
            fl.setVgap(0);
            JPanel p = new JPanel(fl);
            JLabel appctr2 = new JLabel((new StringBuilder()).append(AppManager.getResBundle().getString("appcenter.action.about.version")).append(": ").toString());
            PI18nHelper.setFontStyle(appctr2, 1);
            JLabel appctrver = new JLabel(AppManager.getProperties().getProperty("appcenter.version"));
            p.add(appctr2);
            p.add(appctrver);
            c.gridy++;
            mInfoPanel.add(p, c);
            mInfoPanel.addMouseListener(new MouseAdapter() {

                public void mouseClicked(MouseEvent me)
                {
                    if(me.getClickCount() == 3 && (me.getModifiers() & 1) != 0 && (me.getModifiers() & 2) != 0)
                        displayOpcodeLogDetails();
                }

                final AboutAction this$0;

            
            {
                this$0 = AboutAction.this;
                super();
            }
            }
);
        }
    }

    private void displayOpcodeLogDetails()
    {
        if(mOpLogDlg == null)
        {
            JFrame mainFrame = AppManager.getInstance().getMainFrame();
            mOpLogDlg = new PFCDialog(mainFrame, AppManager.getResBundle().getString("appcenter.log.dialog.title"), true);
            mLogPanel = new LoggingPanel();
            mOpLogDlg.setMainPanel(mLogPanel);
            JButton okB = new JButton(AppManager.getResBundle().getString("appcenter.ok"));
            mOpLogDlg.addButton(okB);
            okB.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent ae)
                {
                    mOpLogDlg.setVisible(false);
                }

                final AboutAction this$0;

            
            {
                this$0 = AboutAction.this;
                super();
            }
            }
);
        }
        mLogPanel.updateUIElements(AppManager.getInstance().getRunningApps().iterator());
        mOpLogDlg.setVisible(true);
    }

    private AboutDialog mDlg;
    private PFCDialog mOpLogDlg;
    private LoggingPanel mLogPanel;
    private JPanel mInfoPanel;


}