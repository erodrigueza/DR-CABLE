// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoggingPanel.java

package com.portal.appcenter;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            LogTableModel, Application, ApplicationServices, ApplicationDescriptor

class LoggingPanel extends JPanel
{

    public LoggingPanel()
    {
        setLayout(new BorderLayout());
        tableModel = new LogTableModel();
        table = new JTable(tableModel);
        JScrollPane jsp = new JScrollPane(table);
        table.setPreferredScrollableViewportSize(new Dimension(350, 75));
        add("Center", jsp);
    }

    public void updateUIElements(Iterator itr)
    {
        ArrayList al = new ArrayList(4);
        do
        {
            if(!itr.hasNext())
                break;
            Application app = (Application)itr.next();
            String homeT = app.getApplicationServices().getDescriptor().getToken();
            if(!"homeapp".equals(homeT))
                al.add(app.getApplicationServices());
        } while(true);
        tableModel.setData(al);
    }

    LogTableModel tableModel;
    JTable table;
}