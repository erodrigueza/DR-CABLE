// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrefsPageContainer.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCDialog;
import com.portal.pfc.ui.VerticalButtonNavigator;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

// Referenced classes of package com.portal.appcenter:
//            ApplicationDescriptor, PrefsPageDescriptor, PreferencesPage, Application, 
//            Constants, AppManager, PreferenceManager, ApplicationServices, 
//            ACProperties

class PrefsPageContainer extends JPanel
    implements ListSelectionListener, Constants
{

    PrefsPageContainer()
    {
        mAppList = new VerticalButtonNavigator();
        mContents = new JPanel();
        mCardLayout = new CardLayout();
        mRes = AppManager.getResBundle();
        mProps = PreferenceManager.getPreferenceManager().getPreferences();
        mOKButton = new JButton(mRes.getString("appcenter.ok"));
        mOKButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                processPrefPanels(true);
                mContents.removeAll();
            }

            final PrefsPageContainer this$0;

            
            {
                this$0 = PrefsPageContainer.this;
                super();
            }
        }
);
        mCancelButton = new JButton(mRes.getString("appcenter.cancel"));
        mCancelButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e)
            {
                processPrefPanels(false);
                mContents.removeAll();
            }

            final PrefsPageContainer this$0;

            
            {
                this$0 = PrefsPageContainer.this;
                super();
            }
        }
);
        mNameToDesc = new HashMap();
        createAppListModel();
        setLayout(new BorderLayout());
        mContents.setLayout(mCardLayout);
        mAppList.setModel(mAppListModel);
        mAppList.addListSelectionListener(this);
        mAppList.setSelectedIndex(0);
        add(mAppList, "West");
        add(mContents, "Center");
        createTabbedPanel(mRes.getString("prefs.general"), null, PreferenceManager.getPreferenceManager().getAppCenterPrefPanels());
        updateRunningApps();
    }

    void reset()
    {
        createTabbedPanel(mRes.getString("prefs.general"), null, PreferenceManager.getPreferenceManager().getAppCenterPrefPanels());
        mAppList.setSelectedValue(mRes.getString("prefs.general"));
        updateRunningApps();
    }

    public void valueChanged(ListSelectionEvent evt)
    {
        String sel = null;
        if(!evt.getValueIsAdjusting())
        {
            sel = (String)mAppList.getSelectedValue();
            ApplicationDescriptor ad = (ApplicationDescriptor)mNameToDesc.get(sel);
            if(ad != null)
            {
                java.util.List panels = PreferenceManager.getPreferenceManager().getApplicationPrefPanels(ad);
                createTabbedPanel(sel, ad, panels);
                mNameToDesc.remove(sel);
            }
        }
        mCardLayout.show(mContents, sel);
    }

    JButton getOKButton()
    {
        return mOKButton;
    }

    JButton getCancelButton()
    {
        return mCancelButton;
    }

    private void createTabbedPanel(String displayLabel, ApplicationDescriptor appDesc, java.util.List panels)
    {
        String name = appDesc != null ? appDesc.getName() : displayLabel;
        JComponent comp = null;
        if(panels.size() == 0)
        {
            JPanel p = new JPanel();
            comp = p;
            p.add(new JLabel(mRes.getString("prefs.noprefs")));
        } else
        {
            JTabbedPane tp = new JTabbedPane();
            comp = tp;
            Iterator i = panels.iterator();
            do
            {
                if(!i.hasNext())
                    break;
                PrefsPageDescriptor ppd = (PrefsPageDescriptor)i.next();
                PreferencesPage prefPage = ppd.getObject();
                String tabName = ppd.getLabel();
                if(tabName != null && prefPage != null)
                {
                    prefPage.displayDefaults();
                    tp.addTab(tabName, (JPanel)prefPage);
                    if(appDesc != null)
                        ppd.setObject(null);
                } else
                {
                    StringBuffer err = new StringBuffer("didn't display PreferencePage '");
                    err.append(ppd.getClassName()).append("' because ");
                    if(tabName == null && prefPage == null)
                    {
                        err.append("prefs.tab.");
                        err.append("<prefpagetoken> wasn't specified and ");
                        err.append(ppd.getClassName()).append("couldn't be loaded");
                    } else
                    if(tabName == null)
                    {
                        err.append("prefs.tab.");
                        err.append("<prefpagetoken> wasn't specified");
                    } else
                    if(prefPage == null)
                        err.append(ppd.getClassName()).append("couldn't be loaded");
                    AppManager.getLogger().log(Level.SEVERE, err.toString());
                }
            } while(true);
        }
        mContents.add(comp, name);
        comp.putClientProperty("appdesc", appDesc);
        comp.putClientProperty("display.label", displayLabel);
        if(appDesc == null)
            comp.putClientProperty("appcenter", "true");
    }

    private PFCDialog getDialog()
    {
        PFCDialog pfcdlg = null;
        Component c = getParent();
        do
        {
            if(c == null)
                break;
            if(c instanceof PFCDialog)
            {
                pfcdlg = (PFCDialog)c;
                break;
            }
            c = c.getParent();
        } while(true);
        return pfcdlg;
    }

    private void processPrefPanels(boolean commitChanges)
    {
        Component jTabbedPanes[] = mContents.getComponents();
        for(int i = 0; i < jTabbedPanes.length; i++)
        {
            JComponent comp = (JComponent)jTabbedPanes[i];
            if(comp instanceof JTabbedPane)
            {
                JTabbedPane tp = (JTabbedPane)jTabbedPanes[i];
                Component prefPanels[] = tp.getComponents();
                for(int j = 0; j < prefPanels.length; j++)
                {
                    PreferencesPage prefPg = (PreferencesPage)prefPanels[j];
                    if(!commitChanges)
                        continue;
                    if(prefPg.isValid())
                    {
                        prefPg.storePrefs();
                    } else
                    {
                        tp.setSelectedComponent((Component)prefPg);
                        mCardLayout.show(mContents, (String)comp.getClientProperty("display.label"));
                        mAppList.setSelectedValue((String)comp.getClientProperty("display.label"));
                        return;
                    }
                }

            }
            if(comp.getClientProperty("appcenter") == null)
            {
                mContents.remove(comp);
                mNameToDesc.put(comp.getClientProperty("display.label"), comp.getClientProperty("appdesc"));
                comp = null;
            }
        }

        getDialog().setVisible(false);
        getDialog().dispose();
    }

    private void updateRunningApps()
    {
        Set s = AppManager.getInstance().getRunningApps();
        Set runningAppNames = new HashSet();
        Application app;
        for(Iterator i = s.iterator(); i.hasNext(); runningAppNames.add(app.getApplicationServices().getDescriptor().getName()))
            app = (Application)i.next();

        Map apps = AppManager.getInstance().getConfiguredApps();
        int cnt = 1;
        for(Iterator i = apps.keySet().iterator(); i.hasNext();)
        {
            Object key = i.next();
            ApplicationDescriptor ad = (ApplicationDescriptor)apps.get(key);
            String app = ad.getName();
            if(runningAppNames.contains(app))
                mAppList.setValueEnabled(app, true);
            else
                mAppList.setValueEnabled(app, false);
            cnt++;
        }

    }

    void createAppListModel()
    {
        if(mAppListModel != null)
            return;
        mAppListModel = new DefaultListModel();
        mAppListModel.add(0, mRes.getString("prefs.general"));
        Map apps = AppManager.getInstance().getConfiguredApps();
        int cnt = 1;
        for(Iterator i = apps.keySet().iterator(); i.hasNext();)
        {
            Object key = i.next();
            ApplicationDescriptor ad = (ApplicationDescriptor)apps.get(key);
            mAppListModel.add(cnt, ad.getName());
            mNameToDesc.put(ad.getName(), ad);
            cnt++;
        }

    }

    private VerticalButtonNavigator mAppList;
    private JPanel mContents;
    private DefaultListModel mAppListModel;
    private CardLayout mCardLayout;
    private ResourceBundle mRes;
    private JButton mOKButton;
    private JButton mCancelButton;
    private ACProperties mProps;
    private java.util.List mPrefPanelList;
    private Map mNameToDesc;


}