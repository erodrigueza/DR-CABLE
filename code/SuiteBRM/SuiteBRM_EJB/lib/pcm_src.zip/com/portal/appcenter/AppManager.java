// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AppManager.java

package com.portal.appcenter;

import com.jgoodies.looks.plastic.PlasticTheme;
import com.jgoodies.looks.plastic.theme.Silver;
import com.portal.pcm.Poid;
import com.portal.pcm.PortalContext;
import com.portal.pfc.infranet.restriction.Restriction;
import com.portal.pfc.infranet.restriction.RestrictionManager;
import com.portal.pfc.ui.PFCImage;
import com.portal.pfc.util.nestedjars.NestedJarClassLoader;
import com.portal.pfc.util.nestedjars.PortalURLStreamHandlerFactory;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import oracle.bali.ewt.olaf2.OracleBlueTheme;
import oracle.bali.ewt.olaf2.OracleLookAndFeel;
import oracle.bali.ewt.olaf2.OracleTheme;

// Referenced classes of package com.portal.appcenter:
//            PrimaryAppCenterFrame, AuthorizationException, ExitEvent, ExitListener, 
//            AppCenterFrame, Application, ApplicationDescriptor, LaunchAppAction, 
//            AppFactory, Constants, AppPanel, ACProperties, 
//            PreferenceManager, ConnectionManager, ApplicationServices, ActionManager, 
//            LoginPanel

class AppManager
    implements Constants
{

    static synchronized AppManager getInstance()
    {
        if(!$assertionsDisabled && sAppManager == null)
            throw new AssertionError();
        else
            return sAppManager;
    }

    static void init(String suite)
    {
        if(sAppManager == null)
        {
            if(suite == null)
                getLogger().severe("Suite not specified. Exiting...");
            getLogger().info((new StringBuilder()).append("Suite token: ").append(suite).toString());
            URL.setURLStreamHandlerFactory(new PortalURLStreamHandlerFactory());
            sAppManager = new AppManager(suite);
            sAppManager.configureLauncher();
        }
    }

    static Properties getProperties()
    {
        if(mAppCenterProps == null)
            loadAppCenterProperties();
        return mAppCenterProps;
    }

    static ResourceBundle getResBundle()
    {
        if(mAppCenterResBundle == null)
            mAppCenterResBundle = ResourceBundle.getBundle("com.portal.appcenter.AppCenterResources");
        return mAppCenterResBundle;
    }

    static Logger getLogger()
    {
        if(mLogger == null)
        {
            mLogger = Logger.getLogger("com.portal.appcenter");
            setLoggerLevel(mLogger);
        }
        return mLogger;
    }

    static void setLoggerLevel(Logger logger)
    {
        if(mLogLevel != null)
        {
            logger.setLevel(mLogLevel);
            return;
        }
        if(System.getProperty("loglevel") != null)
        {
            String loglevel = System.getProperty("loglevel");
            mLogLevel = Level.parse(loglevel);
        } else
        {
            mLogLevel = Level.WARNING;
        }
        logger.setLevel(mLogLevel);
    }

    Properties getSuiteProperties()
    {
        return mSuiteProps;
    }

    Image getSuiteIcon()
    {
        Image icon = null;
        String s = mSuiteProps.getProperty("icon");
        if(s != null && s.length() > 0)
            icon = PFCImage.getImage(mNJCL, s);
        if(icon == null)
            icon = PFCImage.getImage(getClass(), "/com/portal/appcenter/images/appcenter.gif");
        return icon;
    }

    private AppManager(String suite)
    {
        mExitListeners = new ArrayList();
        try
        {
            mNJCL = NestedJarClassLoader.getNestedJarClassLoader(getClass().getClassLoader());
        }
        catch(IOException ioex)
        {
            getLogger().log(Level.SEVERE, "Unable to initialize NestedJarClassLoader. Exiting...", ioex);
            String error;
            String errorDlgTitle;
            try
            {
                error = getResBundle().getString("error.initializing.classloader");
                errorDlgTitle = getResBundle().getString("error.dialog.title");
            }
            catch(MissingResourceException mre)
            {
                error = "Unable to initialize ClassLoader. Exiting application.";
                errorDlgTitle = "Error";
            }
            JOptionPane.showMessageDialog(null, error, errorDlgTitle, 0);
            System.exit(1);
        }
        loadAppCenterProperties();
        addExitListener(PreferenceManager.getPreferenceManager());
        setLookAndFeel();
        loadSuiteProperties(suite);
        loadCustomSuiteProperties();
        processConfiguredApplicationsProperty();
        mAppToFrame = new HashMap(5);
    }

    ChangeListener getLoginHandler()
    {
        return new ChangeListener() {

            public void stateChanged(ChangeEvent e)
            {
                LoginPanel lp = (LoginPanel)e.getSource();
                if(!lp.offlineSelected() && !ConnectionManager.getInstance().isOnline())
                    shutdown();
                else
                    launchInitialApp();
            }

            final AppManager this$0;

            
            {
                this$0 = AppManager.this;
                super();
            }
        }
;
    }

    void launch(ApplicationDescriptor appDesc)
    {
        AppPanel appPanel = initApplication(appDesc, null);
        if(appPanel == null)
        {
            return;
        } else
        {
            PrimaryAppCenterFrame primaryFrame = (PrimaryAppCenterFrame)mFrame;
            primaryFrame.addApp(appPanel, getAppDisplayName(appPanel.getApplication(), appDesc));
            mAppToFrame.put(appPanel.getApplication(), mFrame);
            return;
        }
    }

    void launchWithNewConn(ApplicationDescriptor appDesc)
    {
        PrimaryAppCenterFrame primaryFrame = (PrimaryAppCenterFrame)mFrame;
        ConnectionManager.getInstance();
        PortalContext ctx = ConnectionManager.getNewConnection(mFrame, false, appDesc.getToken());
        if(ctx == null)
            return;
        try
        {
            checkAuthorization(ctx, appDesc);
        }
        catch(AuthorizationException e)
        {
            return;
        }
        AppPanel appPanel = initApplication(appDesc, ctx);
        if(appPanel == null)
        {
            return;
        } else
        {
            primaryFrame.addApp(appPanel, getAppDisplayName(appPanel.getApplication(), appDesc));
            mAppToFrame.put(appPanel.getApplication(), mFrame);
            return;
        }
    }

    static void checkAuthorization(PortalContext ctx, ApplicationDescriptor appDesc)
        throws AuthorizationException
    {
        if(ctx.getUserID().getId() == 2L)
            return;
        String permString = (new StringBuilder()).append("/appcenter/").append(appDesc.getToken()).toString();
        RestrictionManager mgr = RestrictionManager.getInstance(ctx);
        Restriction perm = mgr.getRestriction(permString, null);
        if(perm.getViewRestriction() == 0)
        {
            String errMsgStr = getResBundle().getString("error.app.permission.denied");
            Object arg[] = {
                ctx.getUserName(), appDesc.getToken(), ctx.getHost(), ctx.getPort()
            };
            String errMsg = MessageFormat.format(errMsgStr, arg);
            JOptionPane.showMessageDialog(null, errMsg, getResBundle().getString("error.dialog.title"), 0);
            throw new AuthorizationException();
        } else
        {
            return;
        }
    }

    void undock()
    {
        AppCenterFrame f = ((PrimaryAppCenterFrame)mFrame).undock();
        if(f == null)
        {
            return;
        } else
        {
            final Application app = f.getAppPanel().getApplication();
            mAppToFrame.put(app, f);
            f.addWindowListener(new WindowAdapter() {

                public void windowClosing(WindowEvent e)
                {
                    close(app);
                }

                final Application val$app;
                final AppManager this$0;

            
            {
                this$0 = AppManager.this;
                app = application;
                super();
            }
            }
);
            return;
        }
    }

    void dock(AppCenterFrame acf)
    {
        if(acf instanceof PrimaryAppCenterFrame)
        {
            return;
        } else
        {
            AppPanel appPanel = acf.getAppPanel();
            acf.setVisible(false);
            acf.dispose();
            ((PrimaryAppCenterFrame)mFrame).addApp(appPanel, appPanel.getApplication().getApplicationServices().getDisplayName(), true);
            mAppToFrame.put(appPanel.getApplication(), mFrame);
            return;
        }
    }

    boolean close(Application app)
    {
        java.util.List l = app.getApplicationServices().getExitListeners();
        java.util.List exitListeners = new ArrayList(l);
        ExitListener el = null;
        boolean okToExit = true;
        ExitEvent exitEvt = new ExitEvent(app);
        for(Iterator i = exitListeners.iterator(); i.hasNext();)
        {
            el = (ExitListener)i.next();
            okToExit = el.okToExit(exitEvt);
            if(!okToExit)
                return okToExit;
        }

        app.close();
        app.getApplicationServices().releaseResources();
        if(!isHomeApp(app))
        {
            AppCenterFrame acf = (AppCenterFrame)mAppToFrame.get(app);
            acf.close();
        }
        mAppToFrame.remove(app);
        app = null;
        if(!multipleApps())
            shutdown();
        return true;
    }

    void closeAll()
    {
        if(mFrame instanceof PrimaryAppCenterFrame)
            ((PrimaryAppCenterFrame)mFrame).saveBounds();
        Set apps = new HashSet(getRunningApps());
        boolean appClosed = false;
        Application app = null;
        for(Iterator i = apps.iterator(); i.hasNext();)
        {
            app = (Application)i.next();
            if(!isHomeApp(app))
            {
                appClosed = close(app);
                if(!appClosed)
                    return;
            }
        }

        if(mHomeApp == null || mHomeApp != null && close(mHomeApp))
            shutdown();
        else
            return;
    }

    Application getAppByFrame(JFrame jframe)
    {
        Application app = null;
        if(jframe instanceof AppCenterFrame)
            app = ((AppCenterFrame)jframe).getAppPanel().getApplication();
        return app;
    }

    JFrame getFrameByApp(Application app)
    {
        return (JFrame)mAppToFrame.get(app);
    }

    void setFrameByApp(Application app, JFrame frame)
    {
        mAppToFrame.put(app, frame);
    }

    void removeFrameByApp(Application app)
    {
        mAppToFrame.remove(app);
    }

    boolean multipleApps()
    {
        return mConfiguredApps.size() != 1;
    }

    AppCenterFrame getMainFrame()
    {
        return mFrame;
    }

    Set getRunningApps()
    {
        return mAppToFrame.keySet();
    }

    java.util.List getConfiguredAppsList()
    {
        return mAppOrderedList;
    }

    Map getConfiguredApps()
    {
        return mConfiguredApps;
    }

    ApplicationDescriptor getHomeAppDescriptor()
    {
        return mHomeAppDesc;
    }

    boolean isHomeApp(Application app)
    {
        return app == mHomeApp;
    }

    private String getAppDisplayName(Application app, ApplicationDescriptor appDesc)
    {
        int count = 0;
        Iterator i = getRunningApps().iterator();
        do
        {
            if(!i.hasNext())
                break;
            Application runningApp = (Application)i.next();
            if(runningApp.getApplicationServices().getDescriptor() == appDesc)
                count++;
        } while(true);
        String displayName = appDesc.getName();
        if(count > 1)
        {
            StringBuffer appName = new StringBuffer(displayName);
            appName.append(" ( ");
            appName.append(Integer.toString(count));
            appName.append(" )");
            displayName = appName.toString();
        }
        app.getApplicationServices().setDisplayName(displayName);
        return displayName;
    }

    private void loadHomeAppProperties(String homeAppToken)
    {
        Properties p = new Properties();
        try
        {
            InputStream is = null;
            if("homeapp".equals(homeAppToken))
                is = getClass().getResourceAsStream((new StringBuilder()).append(homeAppToken).append(".properties").toString());
            else
                is = mNJCL.getResourceAsStream((new StringBuilder()).append(homeAppToken).append(".properties").toString());
            if(is == null)
                throw new IOException((new StringBuilder()).append("couldn't find properties for ").append(homeAppToken).toString());
            p.load(is);
            mHomeAppDesc = new ApplicationDescriptor(homeAppToken, p);
        }
        catch(IOException ioex)
        {
            getLogger().log(Level.SEVERE, (new StringBuilder()).append("Couldn't load properties for home app ").append(homeAppToken).toString(), ioex);
        }
    }

    private static void loadAppCenterProperties()
    {
        mAppCenterProps = new Properties();
        try
        {
            InputStream is = com/portal/appcenter/AppManager.getResourceAsStream("AppCenter.properties");
            mAppCenterProps.load(is);
        }
        catch(Exception ioex)
        {
            ioex.printStackTrace();
            getLogger().severe("Could not load AppCenter.properties. Exiting...");
            String error;
            String errorDlgTitle;
            try
            {
                error = getResBundle().getString("error.loading.appcenter.props");
                errorDlgTitle = getResBundle().getString("error.dialog.title");
            }
            catch(MissingResourceException mre)
            {
                error = "Could not load AppCenter.properties. Exiting application.";
                errorDlgTitle = "Error";
            }
            JOptionPane.showMessageDialog(null, error, errorDlgTitle, 0);
            System.exit(1);
        }
    }

    private static void setLookAndFeel()
    {
        ACProperties mPrefs = PreferenceManager.getPreferenceManager().getPreferences();
        String prefsTheme = mPrefs.getProperty("appcenter.lookandfeel.theme");
        if(prefsTheme == null)
            prefsTheme = getProperties().getProperty("appcenter.lookandfeel.theme", "sandstone");
        PlasticTheme theme = null;
        if("default".equals(prefsTheme))
            theme = new OracleTheme();
        else
        if("bluewhite".equals(prefsTheme))
            theme = new OracleBlueTheme();
        else
        if("gray".equals(prefsTheme))
            theme = new Silver();
        else
        if("sandstone".equals(prefsTheme))
            theme = new OracleTheme();
        try
        {
            OracleLookAndFeel laf = new OracleLookAndFeel();
            OracleLookAndFeel _tmp = laf;
            OracleLookAndFeel.setMyCurrentTheme(theme);
            UIManager.setLookAndFeel(laf);
        }
        catch(UnsupportedLookAndFeelException lnfx) { }
    }

    private void loadSuiteProperties(String suiteName)
    {
        mSuiteProps = new Properties();
        String propName = (new StringBuilder()).append(suiteName).append(".properties").toString();
        try
        {
            InputStream is = mNJCL.getResourceAsStream(propName);
            mSuiteProps.load(is);
            mAppCenterProps.setProperty("suite.name", mSuiteProps.getProperty("name", "<none>"));
        }
        catch(Exception ex)
        {
            getLogger().log(Level.SEVERE, (new StringBuilder()).append("Couldn't load suite definition file; make sure '").append(suiteName).append(".properties' is in the nested jar file").toString(), ex);
            String error;
            String errorDlgTitle;
            try
            {
                error = getResBundle().getString("error.loading.suite");
                errorDlgTitle = getResBundle().getString("error.dialog.title");
            }
            catch(MissingResourceException mre)
            {
                error = "Could not load suite definition file. Exiting application.";
                errorDlgTitle = "Error";
            }
            JOptionPane.showMessageDialog(null, error, errorDlgTitle, 0);
            System.exit(1);
        }
    }

    private void loadCustomSuiteProperties()
    {
        String propName = "customsuite.properties";
        InputStream is;
        is = mNJCL.getResourceAsStream(propName);
        if(is == null)
            return;
        try
        {
            mCustomSuiteProps = new Properties();
            mCustomSuiteProps.load(is);
            String val = null;
            if((val = mCustomSuiteProps.getProperty("offline.allowed")) != null)
                mSuiteProps.setProperty("offline.allowed", val);
        }
        catch(Exception ex)
        {
            getLogger().log(Level.SEVERE, "Couldn't load customsuite.properties definition file; make sure file is in the nested jar file", ex);
            String error;
            String errorDlgTitle;
            try
            {
                error = getResBundle().getString("error.loading.custom.suite");
                errorDlgTitle = getResBundle().getString("error.dialog.title");
            }
            catch(MissingResourceException mre)
            {
                error = "Could not load custom suite definition file.";
                errorDlgTitle = "Error";
            }
            JOptionPane.showMessageDialog(null, error, errorDlgTitle, 0);
            System.exit(1);
        }
        return;
    }

    private void processConfiguredApplicationsProperty()
    {
        String configuredApps = mSuiteProps.getProperty("configured.applications", "");
        if(mCustomSuiteProps != null)
        {
            String custConfiguredApps = mCustomSuiteProps.getProperty("configured.applications");
            if(custConfiguredApps != null)
                configuredApps = custConfiguredApps;
            String customApps = mCustomSuiteProps.getProperty("custom.applications");
            if(customApps != null)
                configuredApps = configuredApps + " " + customApps;
        }
        StringTokenizer tok = new StringTokenizer(configuredApps);
        String appToken = null;
        mAppOrderedList = new ArrayList();
        mConfiguredApps = new HashMap();
        String defaultApp = mSuiteProps.getProperty("default.application", "").trim();
        do
        {
            if(!tok.hasMoreTokens())
                break;
            appToken = tok.nextToken();
            if(appToken.equals("<SEP>"))
            {
                mAppOrderedList.add("<SEP>");
                continue;
            }
            String propName = (new StringBuilder()).append(appToken).append(".properties").toString();
            Properties props = new Properties();
            try
            {
                InputStream is = mNJCL.getResourceAsStream(propName);
                if(is == null)
                    throw new IOException((new StringBuilder()).append("couldn't find properties for application: ").append(appToken).toString());
                props.load(is);
            }
            catch(IOException ioex)
            {
                getLogger().log(Level.SEVERE, (new StringBuilder()).append("Couldn't find properties for application: ").append(appToken).append(". Make sure they're in the '").append(appToken).append(".properties' file which is in a nested jar in the classpath.").toString());
                continue;
            }
            ApplicationDescriptor desc = new ApplicationDescriptor(appToken, props, mNJCL);
            mConfiguredApps.put(appToken, desc);
            mAppOrderedList.add(desc);
            if(appToken.equals(defaultApp))
                mDefaultAppDesc = desc;
        } while(true);
    }

    private void configureLauncher()
    {
        StringBuffer launchMenuItems = new StringBuffer();
        Map actionMap = ActionManager.getDefaultActionMap();
        ApplicationDescriptor appDesc = null;
        Iterator i = mAppOrderedList.iterator();
        do
        {
            if(!i.hasNext())
                break;
            Object item = i.next();
            if(item instanceof ApplicationDescriptor)
            {
                appDesc = (ApplicationDescriptor)item;
                launchMenuItems.append(appDesc.getToken());
                launchMenuItems.append(" ");
                LaunchAppAction launchAction = new LaunchAppAction("", getProperties(), getResBundle(), appDesc);
                actionMap.put(appDesc.getToken(), launchAction);
            }
        } while(true);
        mAppCenterProps.put("appcenter.cascade.launchmenu", launchMenuItems.toString());
    }

    private void launchInitialApp()
    {
        AppPanel appToRun = null;
        if(multipleApps())
        {
            mFrame = new PrimaryAppCenterFrame();
            mFrame.setCursor(Cursor.getPredefinedCursor(3));
            boolean displayHomePage = true;
            String dispProp = mSuiteProps.getProperty("display.homepage");
            if(dispProp != null && dispProp.equals("false"))
                displayHomePage = false;
            String homeAppToken = mSuiteProps.getProperty("homepage.app");
            if(homeAppToken != null && displayHomePage)
                loadHomeAppProperties(homeAppToken);
            if(mHomeAppDesc == null)
                loadHomeAppProperties("homeapp");
            AppPanel homeAppPanel = initApplication(mHomeAppDesc, null);
            mHomeApp = homeAppPanel.getApplication();
            ((PrimaryAppCenterFrame)mFrame).setHomeApp(homeAppPanel);
            if(mDefaultAppDesc != null)
            {
                appToRun = initApplication(mDefaultAppDesc, null);
                if(appToRun != null)
                    ((PrimaryAppCenterFrame)mFrame).addApp(appToRun, appToRun.getApplication().getApplicationServices().getDescriptor().getName());
            }
            mFrame.setVisible(true);
        } else
        {
            mFrame = new AppCenterFrame();
            mFrame.setCursor(Cursor.getPredefinedCursor(3));
            appToRun = initApplication((ApplicationDescriptor)mAppOrderedList.get(0), ConnectionManager.getInstance().getDefaultConnection(""));
            if(appToRun == null)
                shutdown();
            mFrame.setInitialApp(appToRun, false);
            mFrame.setVisible(true);
        }
        mFrame.setDefaultCloseOperation(0);
        mFrame.addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent e)
            {
                closeAll();
            }

            final AppManager this$0;

            
            {
                this$0 = AppManager.this;
                super();
            }
        }
);
        mFrame.setCursor(Cursor.getDefaultCursor());
    }

    private AppPanel initApplication(ApplicationDescriptor appDesc, PortalContext ctx)
    {
        AppFactory nursery = new AppFactory(appDesc, mFrame, ctx);
        Application app = nursery.getApplication();
        AppPanel appPanel = nursery.getAppPanel();
        return appPanel;
    }

    void addExitListener(ExitListener listener)
    {
        mExitListeners.add(listener);
    }

    void removeExitListener(ExitListener listener)
    {
        mExitListeners.remove(listener);
    }

    private void shutdown()
    {
        ExitListener el = null;
        boolean okToExit = true;
        ExitEvent exitEvt = new ExitEvent(this);
        Iterator i = mExitListeners.iterator();
        do
        {
            if(!i.hasNext())
                break;
            el = (ExitListener)i.next();
            okToExit = el.okToExit(exitEvt);
            if(!okToExit)
                System.out.println("AppManager: not OK to exit");
        } while(true);
        ConnectionManager.getInstance().closeDefaultConnection();
        getLogger().info("exiting...");
        System.exit(0);
    }

    private static AppManager sAppManager;
    private static Properties mAppCenterProps;
    private static ResourceBundle mAppCenterResBundle;
    private Properties mSuiteProps;
    private Properties mCustomSuiteProps;
    private Map mConfiguredApps;
    private ApplicationDescriptor mDefaultAppDesc;
    private ApplicationDescriptor mHomeAppDesc;
    private Application mHomeApp;
    private java.util.List mAppOrderedList;
    private Map mAppToFrame;
    private AppCenterFrame mFrame;
    private ClassLoader mNJCL;
    private java.util.List mExitListeners;
    private static Logger mLogger;
    private static Level mLogLevel;
    static final boolean $assertionsDisabled = !com/portal/appcenter/AppManager.desiredAssertionStatus();



}