// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoginPanel.java

package com.portal.appcenter;

import com.portal.pcm.*;
import com.portal.pfc.ui.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.Beans;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

// Referenced classes of package com.portal.appcenter:
//            KeyAction, AuthModule, PasswordChangeDialog, AppManager, 
//            ConnectionManager

class LoginPanel extends ImagePanel
    implements ActionListener, FocusListener, ItemListener
{

    LoginPanel(String appToken)
    {
        this(false, appToken);
    }

    LoginPanel(boolean showOfflineCheckBox, String appToken)
    {
        super(null, 0);
        dontExit = false;
        mPortalCxt = null;
        gridBagLayout1 = new GridBagLayout();
        loginNameL = new JLabel();
        passL = new JLabel();
        portL = new JLabel();
        hostL = new JLabel();
        loginname = new JTextField();
        password = new JPasswordField();
        database = new JTextField();
        number = new JTextField();
        loginButton = new JButton();
        cancelButton = new JButton();
        offlineCheckbox = new JCheckBox();
        connectButton = new JToggleButton();
        buttonPanel = new JPanel();
        sectionHeader = new JPanel();
        connectTitle = new JLabel();
        mSaveConnectionInfoLocally = true;
        mShowConnectInfoInitially = false;
        mShowConnectInfoAtAll = true;
        authMod = null;
        mShowOfflineCheckBox = false;
        isServicesDown = false;
        mAppToken = appToken;
        mShowOfflineCheckBox = showOfflineCheckBox;
        props = AppManager.getProperties();
        String s = props.getProperty("login.connection.display");
        if(s != null)
            mShowConnectInfoAtAll = Boolean.valueOf(s).booleanValue();
        s = props.getProperty("login.connection.save.locally");
        if(s != null)
            mSaveConnectionInfoLocally = Boolean.valueOf(s).booleanValue();
        initialize();
    }

    void setConnectionInfoVisible(boolean b)
    {
        mShowConnectInfoInitially = b;
    }

    boolean offlineSelected()
    {
        return offlineCheckbox.isSelected();
    }

    public void addChangeListener(ChangeListener l)
    {
        mChangeListeners.addElement(l);
    }

    public void removeChangeListener(ChangeListener l)
    {
        mChangeListeners.removeElement(l);
    }

    void dontExitOnCancel(Boolean b)
    {
        dontExit = b.booleanValue();
    }

    private void fireChangeEvent()
    {
        if(mChangeListeners == null || mChangeListeners.size() == 0)
            return;
        Vector targets = null;
        synchronized(this)
        {
            if(mChangeListeners != null && mChangeListeners.size() != 0)
                targets = (Vector)mChangeListeners.clone();
        }
        int i = 0;
        for(int len = targets.size(); i < len; i++)
        {
            ChangeListener cl = (ChangeListener)targets.elementAt(i);
            cl.stateChanged(new ChangeEvent(this));
        }

    }

    private void initialize()
    {
        mChangeListeners = new Vector();
        if(!Beans.isDesignTime())
            res = AppManager.getResBundle();
        try
        {
            jbInit();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        loadDefaults();
        mImageIcon = new ImageIcon(PFCImage.getImage(getClass(), "/com/portal/pfc/ui/plaf/icons/login_sandstone.gif"));
        if(mShowConnectInfoAtAll)
        {
            connectButton.addActionListener(this);
            String mnemonic = res.getString("login.connect.info.mnemonic");
            connectButton.setMnemonic(mnemonic.charAt(0));
        }
        loginButton.addActionListener(this);
        cancelButton.addActionListener(this);
        if(mShowOfflineCheckBox)
        {
            offlineCheckbox.addItemListener(this);
            KeyStroke keyStr = KeyStroke.getKeyStroke('\n');
            offlineCheckbox.getInputMap(2).put(keyStr, "enter");
            offlineCheckbox.getActionMap().put("enter", new KeyAction(this));
        }
        password.addActionListener(this);
        number.addActionListener(this);
        loginname.addActionListener(this);
        database.addActionListener(this);
        database.addFocusListener(this);
        number.addFocusListener(this);
        password.addFocusListener(this);
        loginname.addFocusListener(this);
        setOpaque(false);
        repaint();
    }

    private void jbInit()
        throws Exception
    {
        loginNameL.setHorizontalAlignment(4);
        loginNameL.setText(res.getString("login.username"));
        setLayout(gridBagLayout1);
        passL.setHorizontalAlignment(4);
        passL.setText(res.getString("login.password"));
        connectButton.setText(res.getString("login.connect.info"));
        loginButton.setText(res.getString("appcenter.ok"));
        loginButton.setMnemonic(res.getString("appcenter.ok.mnemonic").charAt(0));
        cancelButton.setText(res.getString("appcenter.cancel"));
        cancelButton.setMnemonic(res.getString("appcenter.cancel.mnemonic").charAt(0));
        offlineCheckbox.setText(res.getString("login.offline"));
        portL.setHorizontalAlignment(4);
        portL.setText(res.getString("login.number"));
        hostL.setHorizontalAlignment(4);
        hostL.setText(res.getString("login.host"));
        loginname.setColumns(10);
        password.setColumns(10);
        database.setColumns(10);
        number.setColumns(10);
        sectionHeader.setLayout(new BorderLayout());
        connectTitle.setText(res.getString("login.extended.title"));
        if(mShowOfflineCheckBox)
            add(offlineCheckbox, new GridBagConstraints(0, 0, 2, 1, 0.0D, 0.0D, 18, 2, new Insets(30, 10, 0, 0), 0, 0));
        add(loginNameL, new GridBagConstraints(0, 1, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(15, 10, 0, 0), 0, 0));
        add(passL, new GridBagConstraints(0, 2, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(7, 10, 0, 0), 0, 0));
        add(sectionHeader, new GridBagConstraints(0, 3, 3, 1, 1.0D, 0.0D, 10, 2, new Insets(15, 10, 0, 0), 0, 0));
        sectionHeader.add(connectTitle, "West");
        add(hostL, new GridBagConstraints(0, 4, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 0, 0), 0, 0));
        add(portL, new GridBagConstraints(0, 5, 1, 1, 0.0D, 0.0D, 10, 2, new Insets(7, 10, 0, 0), 0, 0));
        add(buttonPanel, new GridBagConstraints(0, 6, 3, 1, 1.0D, 0.0D, 10, 2, new Insets(15, 5, 0, 5), 0, 0));
        buttonPanel.setLayout(new BorderLayout(10, 5));
        if(mShowConnectInfoAtAll)
            buttonPanel.add(connectButton, "West");
        JPanel p = new JPanel(new GridLayout(1, 2));
        p.add(loginButton);
        p.add(cancelButton);
        buttonPanel.add(p, "East");
        add(loginname, new GridBagConstraints(1, 1, 2, 1, 0.0D, 0.0D, 10, 2, new Insets(15, 10, 0, 25), 0, 0));
        add(password, new GridBagConstraints(1, 2, 2, 1, 0.0D, 0.0D, 10, 2, new Insets(7, 10, 0, 25), 0, 0));
        add(database, new GridBagConstraints(1, 4, 2, 1, 0.0D, 0.0D, 10, 2, new Insets(10, 10, 0, 25), 0, 0));
        add(number, new GridBagConstraints(1, 5, 2, 1, 0.0D, 0.0D, 10, 2, new Insets(7, 10, 0, 25), 0, 0));
        ArrayList btnList = new ArrayList();
        btnList.add(loginButton);
        btnList.add(cancelButton);
        SwingHelper.setPreferredButtonSize(btnList);
        java.awt.Color bg = UIManager.getColor("Header.background");
        p.setBackground(bg);
        buttonPanel.setBackground(bg);
        loginButton.setBackground(bg);
        cancelButton.setBackground(bg);
    }

    public JPanel getCommandButtons()
    {
        remove(buttonPanel);
        return buttonPanel;
    }

    public void addNotify()
    {
        super.addNotify();
        displayConnectionInfo(mShowConnectInfoInitially);
        connectButton.setSelected(mShowConnectInfoInitially);
        loginname.requestFocus();
        loginname.requestFocus();
        LookAndFeel.installColors(sectionHeader, "Header.background", "Header.foreground");
    }

    public void focusGained(FocusEvent e)
    {
        JTextField tf = (JTextField)e.getSource();
        if(loginButton.isEnabled())
            tf.selectAll();
    }

    public void focusLost(FocusEvent focusevent)
    {
    }

    public void itemStateChanged(ItemEvent e)
    {
        if(offlineCheckbox.isSelected())
        {
            loginname.setEnabled(false);
            password.setEnabled(false);
            if(mShowConnectInfoAtAll)
            {
                connectButton.setEnabled(false);
                database.setEnabled(false);
                number.setEnabled(false);
            }
        } else
        {
            loginname.setEnabled(true);
            password.setEnabled(true);
            password.setBackground(UIManager.getColor("PasswordField.background"));
            connectButton.setEnabled(true);
            if(mShowConnectInfoAtAll)
            {
                connectButton.setEnabled(true);
                database.setEnabled(true);
                number.setEnabled(true);
            }
        }
    }

    public void actionPerformed(ActionEvent event)
    {
        Object src = event.getSource();
        if(src == loginname || src == password)
        {
            String p = getPassword();
            if(p == null || p.length() == 0)
            {
                password.requestFocus();
                return;
            }
            handleLogin();
        } else
        if(src == database || src == number)
        {
            String p = number.getText();
            if(p == null || p.length() == 0)
            {
                number.requestFocus();
                return;
            }
            handleLogin();
        }
        if(src == loginButton)
            handleLogin();
        else
        if(src == cancelButton)
        {
            if(!dontExit)
                System.exit(0);
            else
                fireChangeEvent();
        } else
        if(src == connectButton)
            displayConnectionInfo(connectButton.isSelected());
        else
        if(src == offlineCheckbox)
            handleLogin();
    }

    private void displayConnectionInfo(boolean b)
    {
        hostL.setVisible(b);
        database.setVisible(b);
        portL.setVisible(b);
        number.setVisible(b);
        sectionHeader.setVisible(b);
        if(b)
            database.requestFocus();
    }

    private void handleLogin()
    {
        loginButton.setEnabled(false);
        cancelButton.setEnabled(false);
        offlineCheckbox.setEnabled(false);
        loginname.requestFocus();
        if(offlineCheckbox.isSelected())
        {
            mPortalCxt = null;
            fireChangeEvent();
            return;
        }
        String module = props.getProperty("portal.authentication.module");
        if(module == null)
            break MISSING_BLOCK_LABEL_239;
        int authStatus;
        String errTitle;
        String errMsg;
        try
        {
            parentWindowVisibility(false);
            if(authMod == null)
                authMod = (AuthModule)Class.forName(module).newInstance();
            authStatus = authMod.authenticate(loginname.getText(), database.getText(), number.getText(), mAppToken);
            if(authStatus == 1)
            {
                mPortalCxt = null;
                fireChangeEvent();
                return;
            }
        }
        catch(Exception ex)
        {
            AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("Problems instantiating ").append(module).toString(), ex);
            mPortalCxt = null;
            fireChangeEvent();
            return;
        }
        if(authStatus == 0)
        {
            errTitle = res.getString("login.error.title");
            errMsg = res.getString("login.error.message");
            JOptionPane.showMessageDialog(this, errMsg, errTitle, 0);
            parentWindowVisibility(true);
            loginButton.setEnabled(true);
            cancelButton.setEnabled(true);
            return;
        }
        String url;
        boolean serviceLocked;
        url = null;
        if(service == null)
            service = "/service/admin_client";
        try
        {
            StringBuffer buff = new StringBuffer();
            buff.append("pcp://");
            buff.append(URLEncoder.encode(loginname.getText()));
            buff.append(":");
            buff.append(URLEncoder.encode(getPassword()));
            buff.append("@");
            buff.append(database.getText());
            buff.append(":");
            buff.append(number.getText());
            buff.append(service);
            url = buff.toString();
        }
        catch(Exception exx)
        {
            DefaultLog.log((new StringBuilder()).append(" Exception while preparing the URL").append(url).toString());
        }
        PortalContext ctx = null;
        serviceLocked = false;
        try
        {
            isServicesDown = false;
            ctx = ConnectionManager.connectToServer(url);
        }
        catch(EBufException ebuf)
        {
            if(ebuf.getError() == 27 || ebuf.getError() == 57)
            {
                JOptionPane.showMessageDialog(this, res.getString("login.error.servicedown"), res.getString("login.error.title"), 0);
                isServicesDown = true;
            } else
            if(ebuf.getError() == 121)
            {
                String userName = loginname.getText().trim();
                String message = res.getString("login.servicelocked.error");
                Object args[] = {
                    userName
                };
                message = MessageFormat.format(message, args);
                JOptionPane.showMessageDialog(this, new JLabel(message), res.getString("login.servicelocked.error.title"), 0);
                serviceLocked = true;
            }
            AppManager.getLogger().log(Level.SEVERE, "Connection to Portal failed", ebuf);
            ctx = null;
        }
        mPortalCxt = ctx;
        if(ctx == null)
            break MISSING_BLOCK_LABEL_723;
        passwordAction();
        mDefaultLoginURL = url;
        if(authMod != null)
            authMod.postInfranetAuthenticate();
        fireChangeEvent();
        if(!mSaveConnectionInfoLocally)
            return;
        try
        {
            mLocalPrefs.put("login", loginname.getText());
            mLocalPrefs.put("host", database.getText());
            mLocalPrefs.put("port", number.getText());
            StringBuffer buff = new StringBuffer(20);
            buff.append(System.getProperty("user.home"));
            buff.append(System.getProperty("file.separator"));
            buff.append(".custcent.prop");
            FileOutputStream os = new FileOutputStream(buff.toString());
            mLocalPrefs.store(os, null);
            mLocalPrefs.clear();
        }
        catch(Exception ex) { }
        break MISSING_BLOCK_LABEL_795;
        if(!isServicesDown && !serviceLocked)
        {
            String errTitle = res.getString("login.error.title");
            String errMsg = res.getString("login.error.message");
            JOptionPane.showMessageDialog(this, errMsg, errTitle, 0);
        }
        parentWindowVisibility(true);
        loginButton.setEnabled(true);
        cancelButton.setEnabled(true);
        offlineCheckbox.setEnabled(true);
        if(mPortalCxt != null)
            mDefaultLoginURL = url;
        return;
    }

    private void parentWindowVisibility(boolean b)
    {
        Component c;
        for(c = getParent(); !(c instanceof JDialog) && !(c instanceof JFrame); c = c.getParent());
        if(c instanceof JDialog)
            ((JDialog)c).setVisible(b);
        else
        if(c instanceof JFrame)
            ((JFrame)c).setVisible(b);
    }

    private void loadDefaults()
    {
        try
        {
            ArrayList list = new ArrayList();
            String url = PortalContext.getUserProperty("connection");
            if(url != null)
                parseURL(url);
            parseLocalConnectionInfo();
        }
        catch(Exception e) { }
    }

    private void parseURL(String cStr)
        throws ParseException
    {
        int idx = cStr.indexOf("://");
        if(idx == -1)
            throw new ParseException("Missing protocol", 0);
        if(!cStr.substring(0, idx).equalsIgnoreCase("pcp"))
            throw new ParseException("Illegal protocol", 0);
        int idx2 = cStr.indexOf("/", idx + 3);
        String hostInfo = null;
        if(idx2 == -1)
            hostInfo = cStr.substring(idx + 3).trim();
        else
            hostInfo = cStr.substring(idx + 3, idx2);
        String user = null;
        String pass = null;
        int at = hostInfo.indexOf("@");
        if(at != -1)
        {
            String usr = hostInfo.substring(0, at);
            hostInfo = hostInfo.substring(at + 1).trim();
            int pws = usr.indexOf(":");
            if(pws == -1)
            {
                user = usr;
            } else
            {
                user = usr.substring(0, pws);
                pass = usr.substring(pws + 1).trim();
            }
        }
        String host = null;
        String port = null;
        int colon = hostInfo.indexOf(":");
        if(colon == -1)
            throw new ParseException("Missing Port", idx);
        host = hostInfo.substring(0, colon);
        port = hostInfo.substring(colon + 1).trim();
        if(host != null)
            database.setText(host);
        if(port != null)
            number.setText(port);
        if(user != null)
            loginname.setText(user);
        if(pass != null)
            password.setText(pass);
        service = null;
        if(idx2 != -1)
        {
            service = cStr.substring(idx2).trim();
            int inst = service.indexOf(":");
            if(inst != -1)
            {
                String instStr = service.substring(inst + 1);
                service = (new StringBuilder()).append(service.substring(0, inst)).append(" ").append(instStr).toString();
            }
        }
    }

    private void parseLocalConnectionInfo()
    {
        if(mShowConnectInfoAtAll && mSaveConnectionInfoLocally)
        {
            mLocalPrefs = new Properties();
            try
            {
                StringBuffer buff = new StringBuffer(20);
                buff.append(System.getProperty("user.home"));
                buff.append(System.getProperty("file.separator"));
                buff.append(".custcent.prop");
                FileInputStream in = new FileInputStream(buff.toString());
                mLocalPrefs.load(in);
                String user = mLocalPrefs.getProperty("login");
                if(user != null)
                    loginname.setText(user);
                String host = mLocalPrefs.getProperty("host");
                if(host != null)
                    database.setText(host);
                String port = mLocalPrefs.getProperty("port");
                if(port != null)
                    number.setText(port);
            }
            catch(Exception ex) { }
        }
    }

    private String getPassword()
    {
        char pass[] = password.getPassword();
        return new String(pass);
    }

    private void passwordAction()
    {
        try
        {
            int passwdStatus = mPortalCxt.getReasonCode();
            if(passwdStatus == 4 || passwdStatus == 5)
            {
                Frame parent = null;
                try
                {
                    parent = (Frame)SwingUtilities.windowForComponent(this);
                }
                catch(Exception c)
                {
                    parent = null;
                }
                PasswordChangeDialog pcd = new PasswordChangeDialog(parent, mPortalCxt, passwdStatus, loginname.getText().trim(), appName);
                password.setText(pcd.getPassword());
            } else
            if(passwdStatus == 6)
            {
                JOptionPane.showMessageDialog(this, res.getString("login.reason.invalid.error"), res.getString("login.error.title"), 0);
                System.exit(0);
            }
        }
        catch(Exception ex)
        {
            AppManager.getInstance();
            AppManager.getLogger().info(ex.getMessage());
        }
    }

    public void setAppName(String appName)
    {
        this.appName = appName;
    }

    private String appName;
    static final String SERVICE_DEF = "/service/admin_client";
    static final String PCP_PROTOCOL = "pcp://";
    private String service;
    private Vector mChangeListeners;
    private boolean dontExit;
    PortalContext mPortalCxt;
    GridBagLayout gridBagLayout1;
    JLabel loginNameL;
    JLabel passL;
    JLabel portL;
    JLabel hostL;
    JTextField loginname;
    JPasswordField password;
    JTextField database;
    JTextField number;
    JButton loginButton;
    JButton cancelButton;
    JCheckBox offlineCheckbox;
    JToggleButton connectButton;
    JPanel buttonPanel;
    JPanel sectionHeader;
    JLabel connectTitle;
    Properties mLocalPrefs;
    boolean mSaveConnectionInfoLocally;
    boolean mShowConnectInfoInitially;
    boolean mShowConnectInfoAtAll;
    private static final String PROP_FILE = ".custcent.prop";
    AuthModule authMod;
    ResourceBundle res;
    Properties props;
    private boolean mShowOfflineCheckBox;
    private String mAppToken;
    String mDefaultLoginURL;
    private static final int TEMPORARY_PASSWORD = 4;
    private static final int EXPIRED_PASSWORD = 5;
    private static final int INVALID_PASSWORD = 6;
    private boolean isServicesDown;
}