// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ActionManager.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.logging.Logger;

// Referenced classes of package com.portal.appcenter:
//            Application, ACAction, AppManager, ApplicationServices, 
//            ApplicationDescriptor

class ActionManager
{

    ActionManager()
    {
    }

    static Map getDefaultActionMap()
    {
        if(defaultActions == null)
            defaultActions = loadDefaultActions(AppManager.getProperties(), AppManager.getResBundle());
        return defaultActions;
    }

    static Map loadDefaultActions(Properties p, ResourceBundle rb)
    {
        Map actionMap = new HashMap();
        String actions = p.getProperty("appcenter.actions");
        if(actions == null)
            return actionMap;
        StringTokenizer st = new StringTokenizer(actions);
        String action = null;
        do
        {
            if(!st.hasMoreTokens())
                break;
            action = st.nextToken();
            String actionClass = p.getProperty((new StringBuilder()).append("appcenter.action.").append(action).append(".class").toString());
            if(actionClass != null && actionClass.length() > 0)
                try
                {
                    Class c = Class.forName(actionClass);
                    Class args[] = {
                        java/lang/String, java/util/Properties, java/util/ResourceBundle
                    };
                    Constructor cons = c.getDeclaredConstructor(args);
                    Object argObjs[] = {
                        (new StringBuilder()).append("appcenter.action.").append(action).toString(), p, rb
                    };
                    PFCAction actionObj = (PFCAction)cons.newInstance(argObjs);
                    actionMap.put(action, actionObj);
                }
                catch(ClassNotFoundException cnfe)
                {
                    cnfe.printStackTrace();
                }
                catch(NoSuchMethodException nsme)
                {
                    nsme.printStackTrace();
                }
                catch(InvocationTargetException itee)
                {
                    itee.printStackTrace();
                }
                catch(IllegalAccessException iae)
                {
                    iae.printStackTrace();
                }
                catch(InstantiationException ie)
                {
                    ie.printStackTrace();
                }
        } while(true);
        return actionMap;
    }

    static Map loadApplicationActions(Application app, Map actionMap)
    {
        Properties p = app.getApplicationServices().getDescriptor().getProperties();
        String appToken = app.getApplicationServices().getDescriptor().getToken();
        String actions = p.getProperty((new StringBuilder()).append(appToken).append(".actions").toString());
        if(actions == null)
            return actionMap;
        ClassLoader cl = app.getClass().getClassLoader();
        StringTokenizer st = new StringTokenizer(actions);
        String action = null;
        do
        {
            if(!st.hasMoreTokens())
                break;
            action = st.nextToken();
            String actionPrefix = appToken + ".action." + action;
            String actionClass = p.getProperty((new StringBuilder()).append(actionPrefix).append(".class").toString());
            if(p.containsKey((new StringBuilder()).append(actionPrefix).append(".donotinit").toString()) || actionClass == null)
                AppManager.getLogger().warning((new StringBuilder()).append("Not loading action '").append(action).append("'").toString());
            else
            if(actionClass != null && actionClass.length() > 0)
                try
                {
                    Class c = Class.forName(actionClass, true, cl);
                    Class args[] = {
                        java/lang/String, com/portal/appcenter/Application
                    };
                    Constructor cons = c.getDeclaredConstructor(args);
                    Object argObjs[] = {
                        actionPrefix.toString(), app
                    };
                    ACAction actionObj = (ACAction)cons.newInstance(argObjs);
                    actionMap.put(action, actionObj);
                }
                catch(ClassNotFoundException cnfe)
                {
                    cnfe.printStackTrace();
                }
                catch(NoSuchMethodException nsme)
                {
                    nsme.printStackTrace();
                }
                catch(InvocationTargetException itee)
                {
                    itee.printStackTrace();
                }
                catch(IllegalAccessException iae)
                {
                    iae.printStackTrace();
                }
                catch(InstantiationException ie)
                {
                    ie.printStackTrace();
                }
        } while(true);
        return actionMap;
    }

    private static Map defaultActions;
    private static final String AC_ACTIONS = "appcenter.actions";
    private static final String AC_ACTION = "appcenter.action.";
    private static final String CLASS = ".class";
    private static final String ACTION = ".action.";
    private static final String ACTIONS = ".actions";
    private static final String DO_NOT_INIT = ".donotinit";
}