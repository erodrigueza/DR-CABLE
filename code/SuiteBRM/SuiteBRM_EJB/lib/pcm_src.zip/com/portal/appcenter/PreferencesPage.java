// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PreferencesPage.java

package com.portal.appcenter;


public interface PreferencesPage
{

    public abstract void displayDefaults();

    public abstract void storePrefs();

    public abstract String getHelpID();

    public abstract boolean isValid();
}