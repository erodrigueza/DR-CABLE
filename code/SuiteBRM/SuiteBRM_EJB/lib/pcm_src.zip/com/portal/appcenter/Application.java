// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Application.java

package com.portal.appcenter;

import java.awt.Component;

// Referenced classes of package com.portal.appcenter:
//            ApplicationServices, Navigator, ApplicationContext

public interface Application
{

    public abstract void setApplicationServices(ApplicationServices applicationservices);

    public abstract ApplicationServices getApplicationServices();

    public abstract Component getWorkarea();

    public abstract Navigator getNavigator();

    public abstract void close();

    public abstract ApplicationContext getApplicationContext();

    public abstract void goOffline();

    public abstract void goOnline();

    public static final String ACTIVE = "ACTIVE";
    public static final String INACTIVE = "INACTIVE";
    public static final String DOCK = "DOCK";
    public static final String UNDOCK = "UNDOCK";
}