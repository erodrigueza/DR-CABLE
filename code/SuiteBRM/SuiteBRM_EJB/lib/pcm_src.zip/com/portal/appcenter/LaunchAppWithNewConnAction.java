// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LaunchAppWithNewConnAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import java.awt.event.ActionEvent;

// Referenced classes of package com.portal.appcenter:
//            ApplicationDescriptor, AppManager

class LaunchAppWithNewConnAction extends PFCAction
{

    LaunchAppWithNewConnAction(ApplicationDescriptor appDesc)
    {
        mAppDesc = appDesc;
        putValue("Name", appDesc.getName());
    }

    public void actionPerformed(ActionEvent ae)
    {
        AppManager.getInstance().launchWithNewConn(mAppDesc);
    }

    private ApplicationDescriptor mAppDesc;
}