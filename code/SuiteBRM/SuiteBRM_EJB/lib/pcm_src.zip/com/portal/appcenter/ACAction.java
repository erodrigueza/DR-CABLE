// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ACAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;

// Referenced classes of package com.portal.appcenter:
//            Application, ApplicationServices

public abstract class ACAction extends PFCAction
{

    public ACAction()
    {
    }

    public ACAction(String actionToken, Application app)
    {
        super(actionToken, app.getApplicationServices().getProperties(), app.getApplicationServices().getResources());
        appServices = app.getApplicationServices();
    }

    protected ApplicationServices appServices;
}