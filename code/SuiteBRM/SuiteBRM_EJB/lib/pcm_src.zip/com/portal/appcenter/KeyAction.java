// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoginPanel.java

package com.portal.appcenter;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

// Referenced classes of package com.portal.appcenter:
//            LoginPanel

class KeyAction extends AbstractAction
{

    public KeyAction(LoginPanel lp)
    {
        loginP = lp;
    }

    public void actionPerformed(ActionEvent ae)
    {
        loginP.actionPerformed(ae);
    }

    LoginPanel loginP;
}