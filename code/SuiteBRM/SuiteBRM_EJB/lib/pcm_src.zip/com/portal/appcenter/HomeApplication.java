// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   HomeApplication.java

package com.portal.appcenter;

import com.portal.pfc.ui.ImagePanel;
import com.portal.pfc.ui.PFCImage;
import com.portal.pfc.util.nestedjars.NestedJarClassLoader;
import java.awt.Color;
import java.awt.Component;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

// Referenced classes of package com.portal.appcenter:
//            AbstractApplication, AppManager

class HomeApplication extends AbstractApplication
{

    HomeApplication()
    {
    }

    public Component getWorkarea()
    {
        Properties props = AppManager.getInstance().getSuiteProperties();
        String resName = props.getProperty("homepage.image");
        ImageIcon homePg = null;
        if(resName != null)
            try
            {
                ClassLoader cl = NestedJarClassLoader.getNestedJarClassLoader(props.getClass().getClassLoader());
                homePg = new ImageIcon(PFCImage.getImage(cl, resName));
            }
            catch(Exception ex)
            {
                AppManager.getLogger().log(Level.WARNING, "Unable to load the specified homepage image.", ex);
                homePg = new ImageIcon(com/portal/appcenter/HomeApplication.getResource("images/homePage.gif"));
            }
        else
            homePg = new ImageIcon(com/portal/appcenter/HomeApplication.getResource("images/homePage.gif"));
        ImagePanel homePanel = new ImagePanel(homePg, 0);
        homePanel.setBackground(Color.white);
        return homePanel;
    }
}