// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BrandTreeAction.java

package com.portal.appcenter;

import com.portal.pcm.PortalContext;
import com.portal.pfc.infranetui.BrandTree;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package com.portal.appcenter:
//            ACAction, AuthorizationException, Application, ApplicationServices, 
//            AppManager

public class BrandTreeAction extends ACAction
{

    BrandTreeAction(String actionToken, Application app)
    {
        super(actionToken, app);
        PortalContext conn = null;
        try
        {
            conn = app.getApplicationServices().getConnection();
        }
        catch(AuthorizationException e) { }
        if(conn == null)
        {
            AppManager.getLogger().log(Level.WARNING, "couldn't instantiate the brand tree action because there is no Portal connection");
        } else
        {
            mBrandTree = new BrandTree(conn);
            if(app instanceof PropertyChangeListener)
                mBrandTree.addPropertyChangeListener((PropertyChangeListener)app);
        }
    }

    public Component getCustomToolbarComponent()
    {
        if(mBrandTree.isBrandingEnabled())
        {
            int maxWidth = mBrandTree.getMaximumSize().width;
            int maxHeight = mBrandTree.getPreferredSize().height;
            mBrandTree.setMaximumSize(new Dimension(maxWidth, maxHeight));
            return mBrandTree;
        } else
        {
            return null;
        }
    }

    public void actionPerformed(ActionEvent actionevent)
    {
    }

    private BrandTree mBrandTree;
}