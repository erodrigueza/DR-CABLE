// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AppFactory.java

package com.portal.appcenter;

import com.portal.pcm.PortalContext;
import com.portal.pfc.infranetui.InfranetStatusBar;
import com.portal.pfc.ui.StatusBar;
import com.portal.pfc.util.ChainedResourceBundle;
import com.portal.pfc.util.nestedjars.NestedJarClassLoader;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package com.portal.appcenter:
//            ApplicationServices, ConfigurationLoader, Application, ACMenuBar, 
//            ACToolBar, AppPanel, AuthorizationException, ApplicationDescriptor, 
//            AppCenterFrame, AppManager, ActionManager

class AppFactory
{

    AppFactory(ApplicationDescriptor appDesc, AppCenterFrame frame, PortalContext conn)
    {
        mAppDesc = appDesc;
        try
        {
            mClassLoader = NestedJarClassLoader.getNestedJarClassLoader(getClass().getClassLoader());
            mActionMap = new HashMap();
            mServ = new ApplicationServices(appDesc, mClassLoader, mActionMap);
            if(conn != null)
                mServ.setConnection(conn);
            initApp(frame);
        }
        catch(Exception ex)
        {
            mApp = null;
            mServ = null;
            mAppPanel = null;
            mActionMap = null;
            AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("couldn't load app identified by: ").append(mAppDesc).toString(), ex);
        }
    }

    Application getApplication()
    {
        return mApp;
    }

    AppPanel getAppPanel()
    {
        if(mAppPanel == null)
            createAppPanel();
        return mAppPanel;
    }

    void initConfigurationLoader()
    {
        String cl = mAppDesc.getConfigurationLoader();
        if(cl == null)
            return;
        try
        {
            Class clCls = Class.forName(cl, true, mClassLoader);
            mConfigLoader = (ConfigurationLoader)clCls.newInstance();
            AppManager.getLogger().info((new StringBuilder()).append("loaded ConfigLoader: ").append(mConfigLoader).toString());
        }
        catch(Exception ex)
        {
            mConfigLoader = null;
            AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("couldn't load ").append(cl).toString(), ex);
        }
    }

    private void initApp(AppCenterFrame frame)
    {
        try
        {
            initConfigurationLoader();
            loadProperties();
            loadResources();
            createStatusBar();
            Class c = Class.forName(mAppDesc.getClassName(), true, mClassLoader);
            mApp = (Application)c.newInstance();
            AppManager.getLogger().info((new StringBuilder()).append("loaded app: ").append(mApp).toString());
            AppManager.getInstance().setFrameByApp(mApp, frame);
            mServ.setApplication(mApp);
            mApp.setApplicationServices(mServ);
            ActionManager.loadApplicationActions(mApp, mActionMap);
        }
        catch(Exception ex)
        {
            AppManager.getInstance().removeFrameByApp(mApp);
            mApp = null;
            mServ = null;
            mAppPanel = null;
            mActionMap = null;
            if(!(ex instanceof IllegalStateException))
                AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("couldn't load app identified by: ").append(mAppDesc).toString(), ex);
        }
    }

    private void loadResources()
    {
        ResourceBundle rb = null;
        if(mConfigLoader != null)
        {
            rb = mConfigLoader.loadResources();
        } else
        {
            String rl[] = mAppDesc.getResourceList();
            String res = null;
            for(int i = 0; i < rl.length; i++)
            {
                res = rl[i];
                try
                {
                    rb = ChainedResourceBundle.getBundle(rb, res, Locale.getDefault(), mClassLoader);
                }
                catch(Exception e)
                {
                    AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("Could not load '").append(res).append("' resource bundle.").toString(), e);
                }
            }

        }
        mServ.setResourceBundle(rb);
    }

    private void loadProperties()
    {
        Properties p = null;
        if(mConfigLoader != null)
        {
            p = mConfigLoader.loadProperties();
        } else
        {
            String propsArray[] = mAppDesc.getPropertiesList();
            if(propsArray != null && propsArray.length > 0)
            {
                p = new Properties();
                for(int i = 0; i < propsArray.length; i++)
                    try
                    {
                        InputStream is = mClassLoader.getResourceAsStream(propsArray[i]);
                        if(is == null)
                            throw new IOException((new StringBuilder()).append("couldn't find property file: ").append(propsArray[i]).toString());
                        p.load(is);
                    }
                    catch(IOException ioex)
                    {
                        AppManager.getLogger().warning(ioex.getMessage());
                    }

            }
        }
        mServ.setProperties(p);
    }

    private void createAppPanel()
    {
        if(mApp == null)
            return;
        if(mAppPanel == null && mApp != null)
        {
            ACMenuBar mb = new ACMenuBar(mServ, ActionManager.getDefaultActionMap(), mActionMap);
            ACToolBar tb = new ACToolBar(mServ, ActionManager.getDefaultActionMap(), mActionMap);
            mAppPanel = new AppPanel(getApplication(), mb, tb, mServ.getStatusBar());
            mServ.setAppPanel(mAppPanel);
        }
    }

    private void createStatusBar()
    {
        Properties p = mServ.getProperties();
        StatusBar statusBar = null;
        if(p != null)
        {
            String cName = p.getProperty((new StringBuilder()).append(mAppDesc.getToken()).append(".statusbar.class").toString());
            if(cName != null)
                try
                {
                    Class c = Class.forName(cName, true, mClassLoader);
                    statusBar = (StatusBar)c.newInstance();
                }
                catch(Exception e)
                {
                    AppManager.getLogger().log(Level.WARNING, (new StringBuilder()).append("Could not create status bar identified by '").append(cName).append("' property. Returning default status bar.").toString(), e);
                }
        }
        if(statusBar == null)
        {
            statusBar = new InfranetStatusBar();
            if(mServ.isOnline())
                try
                {
                    PortalContext ctx = mServ.getConnection();
                    ((InfranetStatusBar)statusBar).setConnectStatus(true, ctx);
                }
                catch(AuthorizationException e)
                {
                    ((InfranetStatusBar)statusBar).setConnectStatus(false, null);
                }
        }
        mServ.setStatusBar(statusBar);
    }

    private Application mApp;
    private AppPanel mAppPanel;
    private Map mActionMap;
    private ApplicationDescriptor mAppDesc;
    private ApplicationServices mServ;
    private ConfigurationLoader mConfigLoader;
    private ClassLoader mClassLoader;
    private static final String CUSTOM_STATUSBAR = ".statusbar.class";
}