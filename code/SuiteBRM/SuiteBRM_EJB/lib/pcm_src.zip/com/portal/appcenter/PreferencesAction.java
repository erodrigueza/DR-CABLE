// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PreferencesAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.*;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;
import javax.swing.JFrame;

// Referenced classes of package com.portal.appcenter:
//            PrefsPageContainer, AppManager

class PreferencesAction extends PFCAction
{

    PreferencesAction(String tok, Properties p, ResourceBundle rb)
    {
        super(tok, p, rb);
    }

    public void actionPerformed(ActionEvent ae)
    {
        JFrame parent = SwingHelper.getFrame((Component)ae.getSource());
        PFCDialog d = new PFCDialog(parent, AppManager.getResBundle().getString("prefs.preferences"), true);
        if(mPP == null)
            mPP = new PrefsPageContainer();
        else
            mPP.reset();
        d.setMainPanel(mPP);
        d.addButton(mPP.getOKButton());
        d.addButton(mPP.getCancelButton());
        d.setSize(640, 480);
        d.setVisible(true);
    }

    private PrefsPageContainer mPP;
}