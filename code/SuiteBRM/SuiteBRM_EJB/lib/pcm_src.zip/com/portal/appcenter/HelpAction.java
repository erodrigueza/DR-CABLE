// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:04 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   HelpAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import com.portal.pfc.ui.SwingHelper;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import oracle.help.CSHManager;
import oracle.help.Help;
import oracle.help.htmlBrowser.ICEBrowser;
import oracle.help.library.helpset.HelpSet;

// Referenced classes of package com.portal.appcenter:
//            AppManager

class HelpAction extends PFCAction
{

    public HelpAction(String token, Properties properties, ResourceBundle rb)
    {
        super(token, properties, rb);
        if(!AppManager.getInstance().multipleApps())
            setConfigured(false);
    }

    public void actionPerformed(ActionEvent ae)
    {
        JFrame jf = SwingHelper.getFrame((Component)ae.getSource());
        jf.setCursor(3);
        CSHManager helpManager = getAppCenterHelpBroker();
        if(helpManager != null)
            helpManager.showNavigatorWindow();
        else
            AppManager.getLogger().log(Level.WARNING, "Couldn't display help");
        jf.setCursor(0);
        jf.setCursor(0);
    }

    CSHManager getAppCenterHelpBroker()
    {
        createHelpSet();
        return mCSHManager;
    }

    private void createHelpSet()
    {
        if(mCSHManager == null)
        {
            String helpsetName = AppManager.getResBundle().getString("appcenter.helpset");
            if(!helpsetName.endsWith(".hs"))
                helpsetName = (new StringBuilder()).append(helpsetName).append(".hs").toString();
            if(helpsetName != null)
                try
                {
                    ICEBrowser icBrowser = new ICEBrowser();
                    Help mHelp = new Help(icBrowser.getClass(), false, true, false, true);
                    ClassLoader cl = getClass().getClassLoader();
                    java.net.URL url = cl.getResource(helpsetName);
                    HelpSet mHelpSet = new HelpSet(url);
                    mHelp.addBook(mHelpSet);
                    mHelp.setDefaultBook(mHelpSet);
                    mCSHManager = new CSHManager(mHelp);
                }
                catch(Exception e)
                {
                    AppManager.getLogger().log(Level.SEVERE, (new StringBuilder()).append("Error while loading HelpSet '").append(helpsetName).append("'").toString(), e);
                }
        }
    }

    private static CSHManager mCSHManager;
}