// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   UndockAction.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCAction;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.ResourceBundle;

// Referenced classes of package com.portal.appcenter:
//            AppManager

class UndockAction extends PFCAction
{

    UndockAction(String token, Properties properties, ResourceBundle rb)
    {
        super(token, properties, rb);
        if(!AppManager.getInstance().multipleApps())
            setConfigured(false);
    }

    public void actionPerformed(ActionEvent ae)
    {
        AppManager.getInstance().undock();
    }
}