// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AppCenterMain.java

package com.portal.appcenter;

import java.io.PrintStream;
import javax.swing.UIManager;
import oracle.bali.ewt.olaf2.OracleLookAndFeel;
import oracle.bali.ewt.olaf2.OracleTheme;

// Referenced classes of package com.portal.appcenter:
//            AppManager, ConnectionManager

public class AppCenterMain
{

    public AppCenterMain()
    {
    }

    public static void main(String args[])
    {
        try
        {
            OracleLookAndFeel laf = new OracleLookAndFeel();
            OracleLookAndFeel _tmp = laf;
            OracleLookAndFeel.setMyCurrentTheme(new OracleTheme());
            UIManager.setLookAndFeel(laf);
            AppManager.init(args[0]);
            ConnectionManager connMgr = ConnectionManager.getInstance();
            connMgr.addLoginListener(AppManager.getInstance().getLoginHandler());
        }
        catch(Exception ex)
        {
            System.out.println("Unable to launch Portal AppCenter.");
            ex.printStackTrace();
            System.exit(1);
        }
    }
}