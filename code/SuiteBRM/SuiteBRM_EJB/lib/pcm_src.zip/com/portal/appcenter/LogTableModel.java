// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoggingPanel.java

package com.portal.appcenter;

import com.portal.pcm.PortalContext;
import java.util.*;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;

// Referenced classes of package com.portal.appcenter:
//            ApplicationServices, AuthorizationException, AppManager

class LogTableModel extends DefaultTableModel
{

    public LogTableModel()
    {
        mData = new ArrayList(0);
        setColumnIdentifiers(HEADERS);
    }

    public void setData(ArrayList newData)
    {
        mData = newData;
        if(mData == null)
            mData = new ArrayList(0);
        fireTableChanged(new TableModelEvent(this));
    }

    public ArrayList getData()
    {
        return mData;
    }

    public void clear()
    {
        if(mData.size() > 0)
            fireTableRowsDeleted(0, mData.size() - 1);
        mData.clear();
    }

    public int getRowCount()
    {
        if(mData == null)
            return 0;
        else
            return mData.size();
    }

    public boolean isCellEditable(int row, int col)
    {
        return col == 1;
    }

    public Class getColumnClass(int col)
    {
        if(col == 1)
            return java/lang/Boolean;
        else
            return java/lang/String;
    }

    public void setValueAt(Object obj, int row, int col)
    {
        if(col != 1)
            return;
        ApplicationServices appS = (ApplicationServices)mData.get(row);
        try
        {
            if(appS.isOnline())
            {
                PortalContext ctx = appS.getConnection();
                Boolean bVal = (Boolean)obj;
                ctx.enableOpcodeLogging(bVal.booleanValue());
                setLogFileProperty("infranet.log.opcodes.enabled", bVal.toString());
                if(bVal.booleanValue())
                {
                    String s = PortalContext.getUserProperty("log.opcodes.file");
                    if(s == null)
                        setLogFileProperty("infranet.log.opcodes.file", "opcodes.log");
                }
            }
        }
        catch(AuthorizationException ae) { }
    }

    public Object getValueAt(int row, int col)
    {
        ApplicationServices appS = (ApplicationServices)mData.get(row);
        PortalContext ctx = null;
        try
        {
            if(appS.isOnline())
                ctx = appS.getConnection();
        }
        catch(AuthorizationException ae) { }
        switch(col)
        {
        case 0: // '\0'
            if(appS.isOnline())
                return appS.getDisplayName();
            else
                return (new StringBuilder()).append(appS.getDisplayName()).append(" (Offline)").toString();

        case 1: // '\001'
            if(ctx == null)
                return Boolean.FALSE;
            else
                return new Boolean(ctx.isOpcodeLoggingEnabled());
        }
        return null;
    }

    private void setLogFileProperty(String key, String val)
    {
        Properties p = new Properties();
        p.setProperty(key, val);
        try
        {
            PortalContext.setLocalProperties(p);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    private static final String FILE_DEFAULT = "opcodes.log";
    private static final String INF_LOG_FILE = "infranet.log.opcodes.file";
    private static final String LOG_FILE = "log.opcodes.file";
    private static final String INF_LOG_ENABLE = "infranet.log.opcodes.enabled";
    private static final String HEADERS[] = {
        AppManager.getResBundle().getString("appcenter.log.tblcolheader.app"), AppManager.getResBundle().getString("appcenter.log.tblcolheader.log")
    };
    ArrayList mData;

}