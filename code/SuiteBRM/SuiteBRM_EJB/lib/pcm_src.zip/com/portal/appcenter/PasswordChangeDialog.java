// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PasswordChangeDialog.java

package com.portal.appcenter;

import com.portal.app.util.CustomerValErrorData;
import com.portal.app.util.CustomerValErrorParser;
import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.awt.*;
import java.awt.event.*;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            AppManager

public class PasswordChangeDialog extends JDialog
    implements ActionListener
{

    public PasswordChangeDialog(Frame parent, PortalContext portalContext, int passwordStatus, String userName, String appName)
    {
        super(parent, "", true);
        bundle = AppManager.getResBundle();
        mButtonPanel = new JPanel(new GridBagLayout());
        setLocationRelativeTo(parent);
        mPortalContext = portalContext;
        mPasswordStatus = passwordStatus;
        mUserName = userName;
        mAppName = appName;
        try
        {
            jbInit();
        }
        catch(Exception ex)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, ex);
        }
    }

    private void jbInit()
        throws Exception
    {
        GridBagLayout gbLayout = new GridBagLayout();
        getContentPane().setLayout(gbLayout);
        setTitle(bundle.getString("login.passwordchange.dialog.title"));
        mLoginNameLbl = new JLabel(bundle.getString("login.username"));
        mLoginNameFld = new JTextField(mUserName);
        mLoginNameFld.setEditable(false);
        mLoginNameFld.setVisible(false);
        mLoginNameLbl.setVisible(false);
        String message = null;
        if(mPasswordStatus == 4)
            message = bundle.getString("login.passwordchange.temporary.desc");
        else
        if(mPasswordStatus == 5)
            message = bundle.getString("login.passwordchange.expired.desc");
        else
        if(mPasswordStatus == 0)
        {
            mLoginNameFld.setVisible(true);
            mLoginNameLbl.setVisible(true);
        }
        mMessageLbl = new JLabel(message);
        mMessageLbl.setPreferredSize(new Dimension(330, 40));
        mCurrentPasswordLbl = new JLabel(bundle.getString("login.passwordchange.currentpass.label"));
        mCurrentPasswordFld = new JPasswordField();
        mCurrentPasswordFld.addActionListener(this);
        mPasswordLbl = new JLabel(bundle.getString("login.passwordchange.newpass.label"));
        mPasswordFld = new JPasswordField();
        mPasswordFld.addActionListener(this);
        mRetypePasswordLbl = new JLabel(bundle.getString("login.passwordchange.retypepass.label"));
        mRetypePasswordFld = new JPasswordField();
        mRetypePasswordFld.addActionListener(this);
        getContentPane().add(mMessageLbl, new GridBagConstraints(0, 0, 2, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(5, 10, 0, 0), 0, 0));
        getContentPane().add(mLoginNameLbl, new GridBagConstraints(0, 1, 2, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(5, 10, 0, 0), 0, 0));
        getContentPane().add(mCurrentPasswordLbl, new GridBagConstraints(0, 2, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 5), 0, 0));
        getContentPane().add(mPasswordLbl, new GridBagConstraints(0, 3, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 5), 0, 0));
        getContentPane().add(mRetypePasswordLbl, new GridBagConstraints(0, 4, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 5), 0, 0));
        getContentPane().add(mLoginNameFld, new GridBagConstraints(1, 1, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 15), 140, 0));
        getContentPane().add(mCurrentPasswordFld, new GridBagConstraints(1, 2, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 15), 70, 0));
        getContentPane().add(mPasswordFld, new GridBagConstraints(1, 3, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 15), 70, 0));
        getContentPane().add(mRetypePasswordFld, new GridBagConstraints(1, 4, 1, 1, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(10, 10, 0, 15), 70, 0));
        getContentPane().add(mButtonPanel, new GridBagConstraints(0, 6, 0, 0, 0.10000000000000001D, 0.10000000000000001D, 10, 2, new Insets(20, 0, 0, 0), 0, 0));
        mOKButton = new JButton(bundle.getString("appcenter.ok"));
        mOKButton.addActionListener(this);
        mOKButton.setMnemonic(bundle.getString("appcenter.ok.mnemonic").charAt(0));
        mCancelButton = new JButton(bundle.getString("appcenter.cancel"));
        mCancelButton.addActionListener(this);
        mCancelButton.setMnemonic(bundle.getString("appcenter.cancel.mnemonic").charAt(0));
        ActionListener actionListener = new ActionListener() {

            public void actionPerformed(ActionEvent actionEvent)
            {
                if(mPasswordStatus == 0)
                    dispose();
            }

            final PasswordChangeDialog this$0;

            
            {
                this$0 = PasswordChangeDialog.this;
                super();
            }
        }
;
        KeyStroke stroke = KeyStroke.getKeyStroke(27, 0);
        getRootPane().registerKeyboardAction(actionListener, stroke, 2);
        mButtonPanel.add(mOKButton, new GridBagConstraints(1, 0, 1, 1, 0.5D, 0.0D, 13, 0, new Insets(0, 0, 0, 3), 0, 0));
        mButtonPanel.add(mCancelButton, new GridBagConstraints(2, 0, 1, 1, 0.0D, 0.0D, 13, 0, new Insets(0, 0, 0, 10), 0, 0));
        addWindowListener(new WindowAdapter() {

            public void windowActivated(WindowEvent event)
            {
                if(firstTime)
                {
                    mCurrentPasswordFld.requestFocus();
                    firstTime = false;
                }
            }

            public void windowClosing(WindowEvent event)
            {
                if(mPasswordStatus == 4 || mPasswordStatus == 5)
                    System.exit(0);
                else
                if(mPasswordStatus == 0)
                    dispose();
            }

            private boolean firstTime;
            final PasswordChangeDialog this$0;

            
            {
                this$0 = PasswordChangeDialog.this;
                super();
                firstTime = true;
            }
        }
);
        pack();
        setVisible(true);
    }

    public void actionPerformed(ActionEvent event)
    {
        Object object = event.getSource();
        if(object == mOKButton || object == mCurrentPasswordFld || object == mPasswordFld || object == mRetypePasswordFld)
            entryValidation();
        else
        if(object == mCancelButton)
            if(mPasswordStatus == 4 || mPasswordStatus == 5)
                System.exit(0);
            else
            if(mPasswordStatus == 0)
                dispose();
    }

    private void entryValidation()
    {
        String currentPassword = getPassword(mCurrentPasswordFld);
        password = getPassword(mPasswordFld);
        String retypePassword = getPassword(mRetypePasswordFld);
        int reasoncode = 0;
        if(currentPassword.equals(""))
        {
            JOptionPane.showMessageDialog(this, bundle.getString("login.passwordchange.currentpwdmissing.error"), bundle.getString("error.dialog.title"), 0);
            return;
        }
        if(!password.equals("") || !retypePassword.equals(""))
        {
            if(!password.equals(retypePassword))
            {
                JOptionPane.showMessageDialog(this, (new StringBuilder()).append(bundle.getString("login.passwordchange.pwdmismatch.error")).append(" ").append(bundle.getString("login.passwordchange.tryagain")).toString(), bundle.getString("error.dialog.title"), 0);
                return;
            }
        } else
        {
            JOptionPane.showMessageDialog(this, bundle.getString("login.passwordchange.newpwdmissing.error"), bundle.getString("error.dialog.title"), 0);
            return;
        }
        try
        {
            FList input = new FList();
            input.set(FldLogin.getInst(), mUserName);
            input.set(FldPasswdClear.getInst(), currentPassword);
            input.set(FldAction.getInst(), "DEFAULT");
            long db = mPortalContext.getCurrentDB();
            Poid servicePoid = new Poid(db, -1L, "/service/admin_client");
            input.set(FldPoid.getInst(), servicePoid);
            FList output = mPortalContext.opcode(158, input);
            if(output.hasField(FldReason.getInst()))
                reasoncode = output.get(FldReason.getInst()).intValue();
        }
        catch(EBufException ex)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, ex);
            JOptionPane.showMessageDialog(this, (new StringBuilder()).append(bundle.getString("login.passwordchange.error")).append(" ").append(bundle.getString("login.passwordchange.tryagain")).toString(), bundle.getString("error.dialog.title"), 0);
            return;
        }
        if(reasoncode == 2)
            JOptionPane.showMessageDialog(this, (new StringBuilder()).append(bundle.getString("login.passwordchange.wrongcurrentpwd")).append(" ").append(bundle.getString("login.passwordchange.tryagain")).toString(), bundle.getString("error.dialog.title"), 0);
        else
        if(reasoncode == 7)
        {
            String message = bundle.getString("login.passwordconfirm.servicelocked");
            Object args[] = {
                mUserName
            };
            message = MessageFormat.format(message, args);
            JOptionPane.showMessageDialog(this, new JLabel(message), bundle.getString("login.servicelocked.error.title"), 0);
            System.exit(0);
        } else
        if(changePassword())
            dispose();
    }

    private String getPassword(JPasswordField mCurrentPasswordFld)
    {
        char pass[] = mCurrentPasswordFld.getPassword();
        return new String(pass);
    }

    public String getPassword()
    {
        return password;
    }

    private boolean changePassword()
    {
        boolean isPasswordChanged = false;
        try
        {
            Poid serPoid = mPortalContext.getUserID();
            FList input = new FList();
            input.set(FldPoid.getInst(), serPoid);
            input.set(FldAccountObj.getInst(), Poid.NULL_POID);
            FList out = mPortalContext.opcode(4, input);
            Poid acctPoid = out.get(FldAccountObj.getInst());
            input = new FList();
            input.set(FldPoid.getInst(), acctPoid);
            input.set(FldProgramName.getInst(), mAppName);
            FList servicesFList = new FList();
            servicesFList.set(FldPoid.getInst(), serPoid);
            servicesFList.set(FldPasswdClear.getInst(), password);
            if(mPasswordStatus == 5)
                servicesFList.set(FldPasswdStatus.getInst(), 2);
            else
            if(mPasswordStatus == 4)
                servicesFList.set(FldPasswdStatus.getInst(), 0);
            input.setElement(FldServices.getInst(), 0, servicesFList);
            out = mPortalContext.opcode(86, input);
            isPasswordChanged = true;
        }
        catch(EBufException e)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, e);
            String errorMsg = null;
            FList error = e.getOpcodeFList();
            if(error != null && error.hasField(FldField.getInst()))
            {
                CustomerValErrorParser parser = new CustomerValErrorParser(error);
                CustomerValErrorData data[] = parser.getErrorDataAsArray();
                errorMsg = (new StringBuilder()).append(data[0].getErrorMessage()).append(" ").append(data[0].getFieldData()).toString();
            } else
            {
                errorMsg = CustomerValErrorParser.getErrorMessage(e);
            }
            if(errorMsg == null || errorMsg != null && "".equals(errorMsg.trim()))
                errorMsg = (new StringBuilder()).append(bundle.getString("login.passwordchange.error")).append(bundle.getString("login.passwordchange.tryagain")).toString();
            isPasswordChanged = false;
            JOptionPane.showMessageDialog(this, errorMsg, bundle.getString("error.dialog.title"), 0);
            return isPasswordChanged;
        }
        try
        {
            mPortalContext.close(true);
            mPortalContext.reconnectAfterUpdatePwd(password);
        }
        catch(EBufException e)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, e);
            JOptionPane.showMessageDialog(this, (new StringBuilder()).append(bundle.getString("login.passwordchange.reconnect.error")).append("\n\n").append(bundle.getString("login.passwordchange.servicelocked.exiting.error")).toString(), bundle.getString("error.dialog.title"), 0);
            System.exit(0);
        }
        return isPasswordChanged;
    }

    ResourceBundle bundle;
    private JButton mOKButton;
    private JButton mCancelButton;
    private JLabel mLoginNameLbl;
    private JLabel mCurrentPasswordLbl;
    private JLabel mPasswordLbl;
    private JLabel mRetypePasswordLbl;
    private JLabel mMessageLbl;
    private JTextField mLoginNameFld;
    private JPasswordField mCurrentPasswordFld;
    private JPasswordField mPasswordFld;
    private JPasswordField mRetypePasswordFld;
    private JPanel mButtonPanel;
    private int mPasswordStatus;
    private PortalContext mPortalContext;
    private String mAppName;
    private String mUserName;
    private static final int NORMAL_PASSWORD = 0;
    private static final int WRONG_PASSWORD = 2;
    private static final int TEMPORARY_PASSWORD = 4;
    private static final int EXPIRED_PASSWORD = 5;
    private static final int SERVICE_LOCKED = 7;
    private String password;


}