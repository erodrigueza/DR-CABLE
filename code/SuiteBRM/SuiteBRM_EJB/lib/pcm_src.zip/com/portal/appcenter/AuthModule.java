// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AuthModule.java

package com.portal.appcenter;


public interface AuthModule
{

    public abstract int authenticate(String s, String s1, String s2, String s3);

    public abstract void postInfranetAuthenticate();

    public static final int REDISPLAY_CODE = 0;
    public static final int FAILURE_CODE = 1;
    public static final int SUCCESS_CODE = 2;
    public static final String MODULE_PROPERTY = "portal.authentication.module";
}