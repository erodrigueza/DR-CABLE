// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AppPanel.java

package com.portal.appcenter;

import com.portal.pfc.ui.StatusBar;
import java.awt.BorderLayout;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            Application, Navigator

class AppPanel extends JPanel
{

    AppPanel(Application app, JMenuBar menubar, JToolBar toolbar, StatusBar statusbar)
    {
        borderLayout1 = new BorderLayout();
        jSplitPane = new JSplitPane();
        mToolbarPanel = new JPanel(new BorderLayout());
        mToolbarSwitcherPanel = new JSplitPane();
        mMenubar = menubar;
        mToolbar = toolbar;
        mStatusBar = statusbar;
        mApp = app;
        setLayout(borderLayout1);
        mNavigator = app.getNavigator();
        if(mNavigator != null)
        {
            jSplitPane.setContinuousLayout(true);
            add(jSplitPane, "Center");
            jSplitPane.setRightComponent(app.getWorkarea());
            jSplitPane.setLeftComponent(mNavigator);
        } else
        {
            add(app.getWorkarea(), "Center");
        }
        mToolbarPanel.setBorder(null);
        mToolbarPanel.add("West", mToolbar);
        mToolbarPanel.add("East", Box.createGlue());
        mToolbarSwitcherPanel.setBorder(null);
        mToolbarSwitcherPanel.setRightComponent(mToolbarPanel);
        mToolbarSwitcherPanel.setContinuousLayout(true);
    }

    JMenuBar getMenuBar()
    {
        return mMenubar;
    }

    JToolBar getToolBar()
    {
        return mToolbar;
    }

    JPanel getToolBarPanel()
    {
        return mToolbarPanel;
    }

    JSplitPane getToolBarWithSwitcher()
    {
        return mToolbarSwitcherPanel;
    }

    StatusBar getStatusBar()
    {
        return mStatusBar;
    }

    Navigator getNavigator()
    {
        return mNavigator;
    }

    Application getApplication()
    {
        return mApp;
    }

    private BorderLayout borderLayout1;
    private JSplitPane jSplitPane;
    private JMenuBar mMenubar;
    private JToolBar mToolbar;
    private JPanel mToolbarPanel;
    private JSplitPane mToolbarSwitcherPanel;
    private StatusBar mStatusBar;
    private Navigator mNavigator;
    private Application mApp;
}