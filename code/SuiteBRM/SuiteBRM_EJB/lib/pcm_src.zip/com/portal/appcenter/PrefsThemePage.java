// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrefsThemePage.java

package com.portal.appcenter;

import com.portal.pfc.ui.PFCImage;
import com.portal.pfc.ui.PSectionHeader;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ResourceBundle;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            PreferencesPage, Constants, AppManager, PreferenceManager, 
//            ACProperties

class PrefsThemePage extends JPanel
    implements ItemListener, PreferencesPage, Constants
{

    PrefsThemePage()
    {
        mBundle = AppManager.getResBundle();
        mShowingDefault = false;
        mDefaultRB = new JRadioButton();
        mGrayRB = new JRadioButton();
        mBlueRB = new JRadioButton();
        mPreviewImage = new JLabel();
        mPrefs = PreferenceManager.getPreferenceManager().getPreferences();
        try
        {
            mImgSS = new ImageIcon(PFCImage.getImage(getClass(), this, "images/ThumbDefault.gif"));
            mImgB = new ImageIcon(PFCImage.getImage(getClass(), this, "images/ThumbBlue.gif"));
            mImgG = new ImageIcon(PFCImage.getImage(getClass(), this, "images/ThumbGray.gif"));
            mPreviewImage.setIcon(mImgSS);
            init();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void itemStateChanged(ItemEvent ie)
    {
        mShowingDefault = false;
        Object src = ie.getSource();
        if(src == mDefaultRB)
        {
            mTheme = "sandstone";
            mPreviewImage.setIcon(mImgSS);
        } else
        if(src == mBlueRB)
        {
            mTheme = "bluewhite";
            mPreviewImage.setIcon(mImgB);
        } else
        if(src == mGrayRB)
        {
            mTheme = "gray";
            mPreviewImage.setIcon(mImgG);
        }
    }

    public void storePrefs()
    {
        if(mShowingDefault)
        {
            return;
        } else
        {
            mPrefs.setProperty("appcenter.lookandfeel.theme", mTheme);
            return;
        }
    }

    public void displayDefaults()
    {
        String origTheme = mPrefs.getProperty("appcenter.lookandfeel.theme");
        if(origTheme == null)
        {
            mShowingDefault = true;
            origTheme = "sandstone";
        }
        mDefaultRB.setSelected(false);
        mBlueRB.setSelected(false);
        mGrayRB.setSelected(false);
        if("sandstone".equals(origTheme))
            mDefaultRB.setSelected(true);
        else
        if("default".equals(origTheme))
            mDefaultRB.setSelected(true);
        else
        if("bluewhite".equals(origTheme))
            mBlueRB.setSelected(true);
        else
        if("gray".equals(origTheme))
            mGrayRB.setSelected(true);
    }

    public String getHelpID()
    {
        return null;
    }

    private void init()
    {
        setLayout(new BorderLayout());
        JPanel themePanel = new JPanel();
        themePanel.setLayout(new GridBagLayout());
        mDefaultRB.setText(mBundle.getString("prefs.theme.sandstone"));
        mGrayRB.setText(mBundle.getString("prefs.theme.gray"));
        mBlueRB.setText(mBundle.getString("prefs.theme.blue"));
        mPreviewImage.setMaximumSize(new Dimension(270, 200));
        mPreviewImage.setMinimumSize(new Dimension(270, 200));
        mPreviewImage.setPreferredSize(new Dimension(270, 200));
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setPreferredSize(new Dimension(450, 330));
        PSectionHeader header = new PSectionHeader();
        header.setLayout(new BorderLayout());
        JLabel headerL = new JLabel(mBundle.getString("prefs.color.theme"));
        header.add(headerL, "West");
        header.setHeaderLabel(headerL);
        add(header, "North");
        GridBagConstraints gbc = new GridBagConstraints();
        Insets insets = new Insets(0, 3, 0, 0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.0D;
        gbc.weighty = 0.0D;
        gbc.anchor = 18;
        gbc.fill = 0;
        gbc.insets = insets;
        themePanel.add(mDefaultRB, gbc);
        gbc.gridy = 1;
        themePanel.add(mGrayRB, gbc);
        gbc.gridy = 2;
        themePanel.add(mBlueRB, gbc);
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0D;
        gbc.anchor = 10;
        gbc.fill = 3;
        insets.left = 0;
        java.awt.Component vertSpacer = Box.createVerticalStrut(8);
        themePanel.add(vertSpacer, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 4;
        gbc.weightx = 0.0D;
        gbc.weighty = 0.0D;
        gbc.fill = 0;
        insets.top = 5;
        insets.left = 15;
        themePanel.add(mPreviewImage, gbc);
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridheight = 1;
        gbc.weightx = 1.0D;
        gbc.fill = 2;
        insets.top = 0;
        insets.left = 0;
        java.awt.Component horizSpacer = Box.createHorizontalStrut(8);
        themePanel.add(horizSpacer, gbc);
        add(themePanel, "Center");
        ButtonGroup themeButtons = new ButtonGroup();
        themeButtons.add(mDefaultRB);
        themeButtons.add(mGrayRB);
        themeButtons.add(mBlueRB);
        mDefaultRB.addItemListener(this);
        mGrayRB.addItemListener(this);
        mBlueRB.addItemListener(this);
    }

    private ACProperties mPrefs;
    private ResourceBundle mBundle;
    private boolean mShowingDefault;
    String mTheme;
    JRadioButton mDefaultRB;
    JRadioButton mGrayRB;
    JRadioButton mBlueRB;
    ImageIcon mImgSS;
    ImageIcon mImgW;
    ImageIcon mImgB;
    ImageIcon mImgG;
    JLabel mPreviewImage;
}