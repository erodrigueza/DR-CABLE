// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BRMClientContext.java

package com.portal.appcenter;

import com.portal.pcm.*;
import com.portal.pcm.fields.FldAutoReconnect;
import java.awt.Frame;
import java.awt.KeyboardFocusManager;
import java.text.MessageFormat;
import java.util.Properties;
import java.util.ResourceBundle;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            ConfirmPasswordDialog, AppManager

public class BRMClientContext extends PortalContext
{

    public BRMClientContext()
        throws EBufException
    {
        super(null, null);
        bundle = AppManager.getResBundle();
    }

    public BRMClientContext(FList login)
        throws EBufException
    {
        super(login, null);
        bundle = AppManager.getResBundle();
        close(true);
        open(login);
    }

    public BRMClientContext(FList login, Properties uprops)
        throws EBufException
    {
        super(login, uprops);
        bundle = AppManager.getResBundle();
        close(true);
        open(login);
    }

    protected BRMClientContext(PortalContext srcPortalCtx)
    {
        super(srcPortalCtx);
        bundle = AppManager.getResBundle();
        userName = getUserName();
    }

    protected BRMClientContext(BRMClientContext srcPortalCtx)
        throws EBufException
    {
        bundle = AppManager.getResBundle();
    }

    public BRMClientContext(Properties uprops)
        throws EBufException
    {
        this(null, uprops);
    }

    public synchronized void open(FList in)
        throws EBufException
    {
        in.set(FldAutoReconnect.getInst(), 0);
        super.open(in);
        userName = getUserName();
    }

    public PortalContext cloneConnection()
        throws EBufException
    {
        PortalContext context = null;
        try
        {
            context = super.cloneConnection();
        }
        catch(EBufException e)
        {
            if(isTimeoutError(e))
            {
                confirmPassword(e);
                context = super.cloneConnection();
            } else
            {
                throw e;
            }
        }
        BRMClientContext clientContext = new BRMClientContext(context);
        if(clientContext.userName == null)
            clientContext.userName = userName;
        return clientContext;
    }

    public synchronized void reconnect()
        throws EBufException
    {
        try
        {
            super.reconnect();
        }
        catch(EBufException e)
        {
            if(isTimeoutError(e))
                confirmPassword(e);
            else
                throw e;
        }
    }

    public synchronized FList opcode(int op, int flags, FList in)
        throws EBufException
    {
        if((op == 7 || op == 17 || op == 18 || op == 19) && flags != 0x20000000 && flags != 0x10000000 && flags != 0x10000010)
            flags |= 0x20000000;
        FList out = null;
        try
        {
            out = super.opcode(op, flags, in);
        }
        catch(EBufException e)
        {
            if(isTimeoutError(e))
            {
                confirmPassword(e);
                out = opcode(op, flags, in);
            } else
            {
                throw e;
            }
        }
        return out;
    }

    private void confirmPassword(EBufException exp)
        throws EBufException
    {
        if(DefaultLog.doLog(8))
            DefaultLog.log(this, 8, exp);
        String password = getPassword(exp);
        if(password == null)
            throw exp;
        try
        {
            super.reconnect(password);
        }
        catch(EBufException e)
        {
            Frame frame = getActiveFrame();
            if(e.getError() == 121)
            {
                String message = bundle.getString("login.passwordconfirm.servicelocked");
                Object args[] = {
                    userName
                };
                message = MessageFormat.format(message, args);
                JLabel label = new JLabel(message);
                JOptionPane.showMessageDialog(frame, label, bundle.getString("login.servicelocked.error.title"), 0);
                System.exit(0);
            } else
            if(e.getError() == 56)
            {
                JOptionPane.showMessageDialog(frame, bundle.getString("login.passwordconfirm.error"), bundle.getString("error.dialog.title"), 0);
            } else
            {
                if(DefaultLog.doLog(2))
                    DefaultLog.log(this, 2, e);
                JOptionPane.showMessageDialog(frame, bundle.getString("login.error.servicedown"), bundle.getString("error.dialog.title"), 0);
            }
            confirmPassword(e);
        }
    }

    private boolean isTimeoutError(EBufException exp)
    {
        return exp.getError() == 49 || exp.getError() == 16;
    }

    private String getPassword(EBufException exp)
    {
        String password = null;
        if(exp.getError() != 56)
            password = getStoredPassword();
        if(password == null || PortalContext.getUserProperty("timeout.prompt") != null && PortalContext.getUserProperty("timeout.prompt").trim().equalsIgnoreCase("true"))
        {
            Frame frame = getActiveFrame();
            ConfirmPasswordDialog confirmDlg = new ConfirmPasswordDialog(frame, userName);
            password = confirmDlg.getPasswordOnPrompt();
            confirmDlg.dispose();
        }
        return password;
    }

    private String getStoredPassword()
    {
        String password = null;
        try
        {
            if(PortalContext.getUserProperty("password") != null)
            {
                password = PortalContext.getUserProperty("password").trim();
            } else
            {
                String connection = PortalContext.getUserProperty("connection");
                if(connection == null)
                    throw new Exception("Connection property Not Found");
                int idx = connection.indexOf("://");
                if(idx == -1)
                    throw new Exception("Missing protocol");
                if(!connection.substring(0, idx).equalsIgnoreCase("pcp"))
                    throw new Exception("Illegal protocol");
                int idx2 = connection.indexOf("/", idx + 3);
                String hostInfo = null;
                if(idx2 == -1)
                    hostInfo = connection.substring(idx + 3).trim();
                else
                    hostInfo = connection.substring(idx + 3, idx2);
                String user = null;
                String pass = null;
                int at = hostInfo.indexOf("@");
                if(at != -1)
                {
                    String usr = hostInfo.substring(0, at);
                    hostInfo = hostInfo.substring(at + 1).trim();
                    int pws = usr.indexOf(":");
                    if(pws == -1)
                    {
                        user = usr;
                    } else
                    {
                        user = usr.substring(0, pws);
                        pass = usr.substring(pws + 1).trim();
                    }
                }
                String host = null;
                String port = null;
                int colon = hostInfo.indexOf(":");
                if(colon == -1)
                    throw new Exception("Missing Port");
                host = hostInfo.substring(0, colon);
                port = hostInfo.substring(colon + 1).trim();
                if(host == null || !getHost().equals(host))
                    throw new Exception("Host Not Match");
                if(port == null || !getPort().equals(port))
                    throw new Exception("Port Not Match");
                if(user == null || !getUserName().equals(user))
                    throw new Exception("User Not Match");
                if(pass == null)
                    throw new Exception("Password null");
                password = pass;
            }
        }
        catch(Exception exp)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, exp);
        }
        return password;
    }

    private Frame getActiveFrame()
    {
        Frame frame = null;
        try
        {
            java.awt.Component comp = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
            java.awt.Window window = SwingUtilities.windowForComponent(comp);
            if(window != null && (window instanceof Frame))
                frame = (Frame)window;
        }
        catch(Exception e)
        {
            frame = null;
        }
        return frame;
    }

    private ResourceBundle bundle;
    private String userName;
}