// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ACMenuBar.java

package com.portal.appcenter;

import com.portal.pfc.ui.*;
import java.awt.Component;
import java.util.*;
import java.util.logging.Logger;
import javax.swing.*;

// Referenced classes of package com.portal.appcenter:
//            CloseAction, SwitchAction, DockAction, UndockAction, 
//            ApplicationServices, ApplicationDescriptor, AppManager

class ACMenuBar extends JMenuBar
{

    ACMenuBar(ApplicationServices appSvcs, Map appCtrActionMap, Map appActionMap)
    {
        mAppSvcs = appSvcs;
        mAppActionMap = appActionMap;
        mAppProps = mAppSvcs.getDescriptor().getProperties();
        mAppToken = mAppSvcs.getDescriptor().getToken();
        mACActionMap = appCtrActionMap;
        mACProps = AppManager.getProperties();
        mACRes = AppManager.getResBundle();
        mGlue = Box.createHorizontalGlue();
        mDockI = new ImageIcon(PFCImage.getImage(getClass(), "/com/portal/appcenter/images/dock.gif"));
        mUndockI = new ImageIcon(PFCImage.getImage(getClass(), "/com/portal/appcenter/images/undock.gif"));
        mCloseI = new ImageIcon(PFCImage.getImage(getClass(), "/com/portal/appcenter/images/x.gif"));
        buildMenuBar();
    }

    private void buildMenuBar()
    {
        String acMenus = mACProps.getProperty("appcenter.menus");
        String appMenus = mAppProps.getProperty((new StringBuilder()).append(mAppToken).append(".menus").toString());
        if(acMenus != null)
        {
            StringTokenizer menus = new StringTokenizer(acMenus);
            String menu = null;
label0:
            do
            {
                if(!menus.hasMoreElements())
                    break;
                menu = menus.nextToken();
                if(menu.equals("<CUSTOM>"))
                {
                    if(appMenus == null)
                        continue;
                    StringTokenizer appSt = new StringTokenizer(appMenus);
                    String appMenu = null;
                    do
                    {
                        JMenu appJMenu;
                        boolean empty;
                        do
                        {
                            if(!appSt.hasMoreElements())
                                continue label0;
                            appMenu = appSt.nextToken();
                            StringBuffer key = new StringBuffer();
                            key.append(mAppToken);
                            key.append(".menu.");
                            key.append(appMenu);
                            String appMenuString = null;
                            try
                            {
                                appMenuString = mAppSvcs.getResources().getString(key.toString());
                            }
                            catch(MissingResourceException mre)
                            {
                                appMenuString = appMenu;
                            }
                            appJMenu = new JMenu(appMenuString);
                            try
                            {
                                String mnem = mAppSvcs.getResources().getString(key.append(".mnemonic").toString());
                                if(mnem != null && mnem.length() > 0)
                                    appJMenu.setMnemonic(mnem.charAt(0));
                            }
                            catch(MissingResourceException mre) { }
                            add(appJMenu);
                            loadMenuEntries(appJMenu, appMenu, true);
                            empty = true;
                            Component comp = null;
                            int i = 0;
                            do
                            {
                                if(i >= appJMenu.getMenuComponentCount())
                                    break;
                                comp = appJMenu.getMenuComponent(i);
                                if(!(comp instanceof JSeparator))
                                {
                                    empty = false;
                                    break;
                                }
                                i++;
                            } while(true);
                        } while(!empty);
                        remove(appJMenu);
                    } while(true);
                }
                StringBuffer key = new StringBuffer();
                key.append("appcenter");
                key.append(".menu.");
                key.append(menu);
                String menuString = null;
                try
                {
                    menuString = mACRes.getString(key.toString());
                }
                catch(MissingResourceException mre)
                {
                    menuString = menu;
                }
                JMenu jmenu = new JMenu(menuString);
                try
                {
                    String mnem = mACRes.getString(key.append(".mnemonic").toString());
                    if(mnem != null && mnem.length() > 0)
                        jmenu.setMnemonic(mnem.charAt(0));
                }
                catch(MissingResourceException mre) { }
                add(jmenu);
                loadMenuEntries(jmenu, menu, false);
                boolean empty = true;
                Component comp = null;
                int i = 0;
                do
                {
                    if(i >= jmenu.getMenuComponentCount())
                        break;
                    comp = jmenu.getMenuComponent(i);
                    if(!(comp instanceof JSeparator))
                    {
                        empty = false;
                        break;
                    }
                    i++;
                } while(true);
                if(empty)
                    remove(jmenu);
                if(menu.equalsIgnoreCase("window"))
                    mWindowMenu = jmenu;
                else
                if(menu.equalsIgnoreCase("file"))
                    mFileMenu = jmenu;
            } while(true);
        }
        PFCAction undockAction = (PFCAction)mACActionMap.get("undock");
        if(undockAction != null)
            addDockUndockButton(undockAction);
    }

    private void loadMenuEntries(JMenu jmenu, String menuToken, boolean customMenu)
    {
        String acMenuEntries = mACProps.getProperty((new StringBuilder()).append("appcenter.menu.").append(menuToken).toString());
        String appMenuEntries = mAppProps.getProperty((new StringBuilder()).append(mAppToken).append(".menu.").append(menuToken).toString());
        if(customMenu)
        {
            loadCustomEntries(jmenu, appMenuEntries);
        } else
        {
            if(acMenuEntries == null || acMenuEntries.length() == 0)
                return;
            StringTokenizer menuTokens = new StringTokenizer(acMenuEntries);
            String menuEntry = null;
            while(menuTokens.hasMoreElements()) 
            {
                menuEntry = menuTokens.nextToken();
                if(menuEntry.equals("<CUSTOM>"))
                    loadCustomEntries(jmenu, appMenuEntries);
                else
                if(menuEntry.startsWith("<CASCADE"))
                    loadCascadeMenuEntries(jmenu, menuEntry, mACActionMap, false);
                else
                    addActionToMenu(jmenu, menuEntry, mACActionMap);
            }
        }
    }

    private void loadCustomEntries(JMenu jmenu, String appMenuEntries)
    {
        if(appMenuEntries == null || appMenuEntries.length() == 0)
            return;
        StringTokenizer menuTokens = new StringTokenizer(appMenuEntries);
        String menuEntry = null;
        while(menuTokens.hasMoreElements()) 
        {
            menuEntry = menuTokens.nextToken();
            if(menuEntry.startsWith("<CASCADE"))
                loadCascadeMenuEntries(jmenu, menuEntry, mAppActionMap, true);
            else
                addActionToMenu(jmenu, menuEntry, mAppActionMap);
        }
    }

    private void loadCascadeMenuEntries(JMenu jmenu, String token, Map actionMap, boolean custom)
    {
        String cascade = token.substring(token.indexOf('=') + 1, token.lastIndexOf('>'));
        String menuEntries = null;
        String cascadeName = null;
        String cascadeMnem = null;
        if(custom)
        {
            try
            {
                cascadeName = mAppSvcs.getResources().getString((new StringBuilder()).append(mAppToken).append(".cascade.").append(cascade).append(".name").toString());
            }
            catch(MissingResourceException mre)
            {
                cascadeName = cascade;
            }
            try
            {
                cascadeMnem = mAppSvcs.getResources().getString((new StringBuilder()).append(mAppToken).append(".cascade.").append(cascade).append(".mnemonic").toString());
            }
            catch(MissingResourceException mre) { }
            menuEntries = mAppProps.getProperty((new StringBuilder()).append(mAppToken).append(".cascade.").append(cascade).toString());
        } else
        {
            try
            {
                cascadeName = mACRes.getString((new StringBuilder()).append("appcenter.cascade.").append(cascade).append(".name").toString());
            }
            catch(MissingResourceException mre)
            {
                cascadeName = cascade;
            }
            try
            {
                cascadeMnem = mACRes.getString((new StringBuilder()).append("appcenter.cascade.").append(cascade).append(".mnemonic").toString());
            }
            catch(MissingResourceException mre) { }
            menuEntries = mACProps.getProperty((new StringBuilder()).append("appcenter.cascade.").append(cascade).toString());
        }
        JMenu cascadingMenu = new JMenu(cascadeName);
        if(cascadeMnem != null && cascadeMnem.length() != 0)
            cascadingMenu.setMnemonic(cascadeMnem.charAt(0));
        if(menuEntries == null)
            return;
        StringTokenizer st = new StringTokenizer(menuEntries);
        String entryToken = null;
        for(; st.hasMoreTokens(); addActionToMenu(cascadingMenu, entryToken, custom ? mAppActionMap : mACActionMap))
            entryToken = st.nextToken();

        if(token.equals("<CASCADE=launchmenu>"))
            mLaunchMenuItem = cascadingMenu;
        if(cascadingMenu.getMenuComponentCount() != 0)
        {
            if(mLaunchMenuItem == cascadingMenu && !AppManager.getInstance().multipleApps())
                return;
            jmenu.add(cascadingMenu);
        }
    }

    private void addActionToMenu(JMenu jmenu, String token, Map actionMap)
    {
        if(token.equals("<SEP>"))
        {
            jmenu.addSeparator();
            return;
        }
        PFCAction action = (PFCAction)actionMap.get(token);
        if(action == null)
        {
            AppManager.getLogger().warning((new StringBuilder()).append("Action '").append(token).append("' is not available in ").append(actionMap).toString());
            return;
        }
        if(action.isConfigured())
        {
            addActionToMenu(jmenu, action, -1);
        } else
        {
            actionMap.remove(token);
            return;
        }
    }

    private void addActionToMenu(JMenu jmenu, PFCAction action, int index)
    {
        String type = (String)action.getValue("type");
        JMenuItem jmi = null;
        if(type == null || type.length() == 0 || type.equals("menuitem"))
            jmi = new JMenuItem(action);
        else
        if(type.equals("checkbox"))
            jmi = new JCheckBoxMenuItem(action);
        else
        if(!type.equals("radio") && type.equals("menu"))
            jmi = new JMenu(action);
        jmi.setIcon(null);
        jmenu.add(jmi, index);
        setActionProperties(jmi, action);
    }

    private void setActionProperties(JMenuItem jmi, PFCAction action)
    {
        String mnem = (String)action.getValue("mnemonic");
        if(mnem != null && mnem.length() != 0)
            jmi.setMnemonic(mnem.charAt(0));
        KeyStroke accel = (KeyStroke)action.getValue("accelerator");
        if(accel != null)
            jmi.setAccelerator(accel);
        Icon icon = (Icon)action.getValue("disabledIcon");
        jmi.setDisabledIcon(icon);
        icon = (Icon)action.getValue("pressedIcon");
        jmi.setPressedIcon(icon);
        if((String)action.getValue("Name") == null)
            jmi.setText(action.getToken());
        if(action instanceof CloseAction)
        {
            StringBuffer sb = new StringBuffer(jmi.getText());
            jmi.setText(sb.append(" ").append(mAppSvcs.getDisplayName()).toString());
        }
    }

    JMenu getWindowMenu()
    {
        return mWindowMenu;
    }

    void addWindowAction(PFCAction action, int index)
    {
        JMenu win = getWindowMenu();
        if(win != null)
            addActionToMenu(win, action, index);
    }

    void removeWindowAction(PFCAction action)
    {
        JMenu win = getWindowMenu();
        removeActionFromMenu(win, action);
    }

    void removeLaunchMenuAction()
    {
        if(mLaunchMenuItem != null)
            mFileMenu.remove(mLaunchMenuItem);
    }

    void replaceLaunchMenuAction()
    {
        if(mLaunchMenuItem != null)
            mFileMenu.add(mLaunchMenuItem, 0);
    }

    void removeCloseAction()
    {
        PFCAction closeAction = (PFCAction)mACActionMap.get("close");
        if(closeAction != null)
            removeActionFromMenu(mFileMenu, closeAction);
    }

    void addUndockAction()
    {
        PFCAction undockAct = (PFCAction)mACActionMap.get("undock");
        addWindowAction(undockAct, 0);
        addDockUndockButton(undockAct);
    }

    void removeExitAction()
    {
        PFCAction exitAction = (PFCAction)mACActionMap.get("exit");
        if(exitAction != null)
            removeActionFromMenu(mFileMenu, exitAction);
    }

    void replaceExitAction()
    {
        PFCAction exitAction = (PFCAction)mACActionMap.get("exit");
        JMenuItem jmi = new JMenuItem(exitAction);
        if(exitAction != null)
            mFileMenu.add(jmi, -1);
    }

    void removeUndockAction()
    {
        removeActionFromMenu(mWindowMenu, (PFCAction)mACActionMap.get("undock"));
        remove(mGlue);
        if(mUndockMenuBtn != null)
            remove(mUndockMenuBtn);
        if(mCloseMenuBtn != null)
            remove(mCloseMenuBtn);
    }

    void addDockAction()
    {
        PFCAction dockAct = (PFCAction)mACActionMap.get("dock");
        addWindowAction(dockAct, 0);
        addDockUndockButton(dockAct);
    }

    void removeDockAction()
    {
        removeActionFromMenu(mWindowMenu, (PFCAction)mACActionMap.get("dock"));
        remove(mGlue);
        if(mDockMenuBtn != null)
            remove(mDockMenuBtn);
        if(mCloseMenuBtn != null)
            remove(mCloseMenuBtn);
    }

    void removeAllSwitchActions()
    {
        Component entries[] = mWindowMenu.getMenuComponents();
        int i = 0;
        for(int len = entries.length; i < len; i++)
        {
            Component comp = entries[i];
            if(!(comp instanceof JMenuItem))
                continue;
            JMenuItem jmi = (JMenuItem)comp;
            javax.swing.Action menuAction = jmi.getAction();
            if(menuAction instanceof SwitchAction)
                mWindowMenu.remove(jmi);
        }

    }

    private void removeActionFromMenu(JMenu jmenu, PFCAction action)
    {
        Component entries[] = jmenu.getMenuComponents();
        int i = 0;
        for(int len = entries.length; i < len; i++)
        {
            Component comp = entries[i];
            if(!(comp instanceof JMenuItem))
                continue;
            JMenuItem jmi = (JMenuItem)comp;
            javax.swing.Action menuAction = jmi.getAction();
            if(action == menuAction)
            {
                jmenu.remove(jmi);
                return;
            }
        }

    }

    private void addDockUndockButton(PFCAction action)
    {
        add(mGlue);
        if(action instanceof DockAction)
        {
            if(mDockMenuBtn == null)
            {
                mDockMenuBtn = new PToolBarButton(action);
                mDockMenuBtn.setText(null);
                mDockMenuBtn.setIcon(mDockI);
            }
            add(mDockMenuBtn);
        } else
        if(action instanceof UndockAction)
        {
            if(mUndockMenuBtn == null)
            {
                mUndockMenuBtn = new PToolBarButton(action);
                mUndockMenuBtn.setText(null);
                mUndockMenuBtn.setIcon(mUndockI);
            }
            add(mUndockMenuBtn);
        }
        PFCAction closeAction = (PFCAction)mACActionMap.get("close");
        if(closeAction != null)
        {
            if(mCloseMenuBtn == null)
            {
                mCloseMenuBtn = new PToolBarButton(closeAction);
                mCloseMenuBtn.setText(null);
                mCloseMenuBtn.setIcon(mCloseI);
            }
            add(mCloseMenuBtn);
        }
    }

    private Icon mIcon;
    private boolean mImageLoading;
    private String mResBase;
    private ApplicationServices mAppSvcs;
    private Properties mAppProps;
    private String mAppToken;
    private Map mAppActionMap;
    private Properties mACProps;
    private ResourceBundle mACRes;
    private Map mACActionMap;
    private JMenu mWindowMenu;
    private JMenu mFileMenu;
    private JMenuItem mLaunchMenuItem;
    private Component mGlue;
    private PToolBarButton mDockMenuBtn;
    private PToolBarButton mUndockMenuBtn;
    private PToolBarButton mCloseMenuBtn;
    private ImageIcon mDockI;
    private ImageIcon mUndockI;
    private ImageIcon mCloseI;
}