// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:03 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   AuthorizationException.java

package com.portal.appcenter;


public class AuthorizationException extends Exception
{

    public AuthorizationException()
    {
    }

    public AuthorizationException(String msg)
    {
        super(msg);
    }
}