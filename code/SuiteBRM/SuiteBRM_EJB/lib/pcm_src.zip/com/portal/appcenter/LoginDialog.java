// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:05 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoginDialog.java

package com.portal.appcenter;

import com.portal.pcm.PortalContext;
import java.awt.*;
import javax.swing.JDialog;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

// Referenced classes of package com.portal.appcenter:
//            LoginPanel

class LoginDialog extends JDialog
    implements ChangeListener
{

    LoginDialog(Frame parent, String title, boolean workOfflineAvailable, String appToken)
    {
        super(parent, title, true);
        setResizable(false);
        getContentPane().setLayout(new BorderLayout());
        loginPanel = new LoginPanel(workOfflineAvailable, appToken);
        loginPanel.dontExitOnCancel(Boolean.TRUE);
        getContentPane().add(loginPanel, "Center");
        getContentPane().add(loginPanel.getCommandButtons(), "South");
        loginPanel.addChangeListener(this);
        pack();
        setSize(295, 267);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((d.width - 295) / 2, (d.height - 267) / 2);
    }

    public void stateChanged(ChangeEvent e)
    {
        loginPanel.removeChangeListener(this);
        dispose();
    }

    PortalContext getPortalContext()
    {
        return loginPanel.mPortalCxt;
    }

    String getLoginURL()
    {
        return loginPanel.mDefaultLoginURL;
    }

    private LoginPanel loginPanel;
    private static final int HEIGHT = 267;
    private static final int WIDTH = 295;
}