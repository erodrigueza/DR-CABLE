// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:02 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ACProperties.java

package com.portal.appcenter;

import java.awt.Rectangle;
import java.io.*;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package com.portal.appcenter:
//            AppManager

public class ACProperties
{

    ACProperties(String filename)
    {
        this(filename, null);
    }

    ACProperties(String filename, Properties defaults)
    {
        mDirty = false;
        if(filename == null)
        {
            throw new NullPointerException("filename shouldn't be null");
        } else
        {
            mDefs = defaults;
            mFilename = filename;
            initProps();
            return;
        }
    }

    public void setDefaults(Properties defaults)
    {
        mDefs = defaults;
    }

    public void remove(String key)
    {
        if(mProperties.containsKey(key))
        {
            mProperties.remove(key);
            mDirty = true;
        }
    }

    public void setProperty(String key, boolean val)
    {
        setProperty(key, String.valueOf(val));
    }

    public void setProperty(String key, String val)
    {
        String curVal = mProperties.getProperty(key);
        if(curVal != null && curVal.equals(val) || curVal == val)
        {
            return;
        } else
        {
            mProperties.setProperty(key, val);
            mDirty = true;
            return;
        }
    }

    public String getStringProp(String key)
    {
        String s = null;
        if(mDefs != null)
            s = mDefs.getProperty(key);
        String s2 = mProperties.getProperty(key);
        if(s2 != null)
            s = s2;
        return s;
    }

    public Rectangle getBoundsProp(String key)
    {
        String sizeVal = getProperty(key);
        if(sizeVal == null)
            return null;
        sizeVal = sizeVal.trim();
        if(!sizeVal.startsWith("(") || !sizeVal.endsWith(")"))
            return null;
        StringTokenizer st = new StringTokenizer(sizeVal.substring(1, sizeVal.length() - 1), ",");
        if(st.countTokens() != 4)
            return null;
        int i = 0;
        int list[] = new int[4];
        while(st.hasMoreElements()) 
            try
            {
                Integer val = Integer.valueOf((String)st.nextElement());
                list[i] = val.intValue();
                i++;
            }
            catch(NumberFormatException e)
            {
                return null;
            }
        Rectangle rect = new Rectangle(list[0], list[1], list[2], list[3]);
        return rect;
    }

    public void setBoundsProp(String key, Rectangle rectToSave)
    {
        StringBuffer strBuffer = new StringBuffer();
        strBuffer.append("(");
        strBuffer.append(rectToSave.x);
        strBuffer.append(",");
        strBuffer.append(rectToSave.y);
        strBuffer.append(",");
        strBuffer.append(rectToSave.width);
        strBuffer.append(",");
        strBuffer.append(rectToSave.height);
        strBuffer.append(")");
        setProperty(key, strBuffer.toString());
    }

    public Rectangle getBoundsPreference(String className)
    {
        String key = (new StringBuilder()).append(className).append(".bounds").toString();
        return getBoundsProp(key);
    }

    public void setBoundsPreference(String className, Rectangle rectToSave)
    {
        String key = (new StringBuilder()).append(className).append(".bounds").toString();
        setBoundsProp(key, rectToSave);
    }

    public String getProperty(String key)
    {
        return mProperties.getProperty(key);
    }

    public void dump()
    {
        try
        {
            mProperties.store(System.out, "DEBUG");
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }

    boolean hasUnsavedChanges()
    {
        return mDirty;
    }

    void reset()
    {
        mProperties.clear();
        try
        {
            serialize();
        }
        catch(Exception ex) { }
        initProps();
    }

    void serialize()
        throws IOException
    {
        if(!hasUnsavedChanges())
            return;
        AppManager.getLogger().info((new StringBuilder()).append("Saving prefs to: ").append(mFilename).toString());
        File f = new File(mFilename);
        File parent = f.getParentFile();
        if(!parent.exists())
            parent.mkdirs();
        f.createNewFile();
        FileOutputStream fo = new FileOutputStream(f);
        mProperties.store(fo, "Portal AppCenter");
        mDirty = false;
        fo.close();
    }

    private void initProps()
    {
        Properties diskProperties = null;
        try
        {
            diskProperties = new Properties();
            AppManager.getLogger().info((new StringBuilder()).append("Loading prefs from: ").append(mFilename).toString());
            FileInputStream fi = new FileInputStream(mFilename);
            diskProperties.load(fi);
            fi.close();
        }
        catch(Exception ex)
        {
            AppManager.getLogger().log(Level.WARNING, (new StringBuilder()).append("Couldn't load preferences from ").append(mFilename).toString(), ex);
        }
        mProperties = diskProperties;
    }

    private Properties mProperties;
    private Properties mDefs;
    private boolean mDirty;
    private static ACProperties ccProperties;
    private String mFilename;
}