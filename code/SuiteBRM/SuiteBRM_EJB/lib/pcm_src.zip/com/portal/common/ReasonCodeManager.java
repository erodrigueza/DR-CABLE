// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ReasonCodeManager.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.util.*;

// Referenced classes of package com.portal.common:
//            InfranetCachedData, ReasonCodeComparator, ReasonCodeData, InfranetLocaleData

public class ReasonCodeManager extends InfranetCachedData
{
    private static class RCMInstanceBuilder extends InfranetCachedData.InstanceBuilder
    {

        public String getClassName()
        {
            return "com.portal.common.ReasonCodeManager";
        }

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return new ReasonCodeManager(connection);
        }

        private RCMInstanceBuilder()
        {
        }

    }


    protected ReasonCodeManager(PortalContext connection)
    {
        super(connection);
        m_localeDomainMap = null;
        m_localeTypeNameMap = null;
        m_localeNameTypeMap = null;
        m_Comparator = new ReasonCodeComparator();
        BuildHashTable();
    }

    public static ReasonCodeManager getInstance(PortalContext connection)
    {
        return getInstance(connection, false);
    }

    public static ReasonCodeManager getInstance(PortalContext connection, boolean rebuild)
    {
        return (ReasonCodeManager)getInstanceImpl(connection, rebuild, m_instBuilder);
    }

    public Vector getReasonData(int reasonType, String infranetLocale, int matchType)
    {
label0:
        {
            if(!ReasonCodeData.isValidReasonType(reasonType) || infranetLocale == null)
                return null;
            if(matchType == 0 || matchType == 2)
            {
                String domainName = (String)m_localeTypeNameMap.get(new Integer(reasonType));
                if(domainName == null)
                    return null;
                String key = (new StringBuilder()).append(infranetLocale.toLowerCase()).append(":").append(domainName.toLowerCase()).toString();
                Vector reasonCodes = (Vector)m_localeDomainMap.get(key);
                if(reasonCodes != null)
                    return reasonCodes;
            }
            if(matchType != 1 && matchType != 2)
                break label0;
            Enumeration localeDomainPairs = m_localeDomainMap.elements();
            Vector reasonCodes;
            ReasonCodeData data;
            do
            {
                if(!localeDomainPairs.hasMoreElements())
                    break label0;
                reasonCodes = (Vector)localeDomainPairs.nextElement();
                data = (ReasonCodeData)reasonCodes.elementAt(0);
            } while(data.getDomainType().intValue() != reasonType || !InfranetLocaleData.isEqual(data.getInfranetLocale(), infranetLocale, false));
            return reasonCodes;
        }
        for(Enumeration localeDomainPairs = m_localeDomainMap.elements(); localeDomainPairs.hasMoreElements();)
        {
            Vector reasonCodes = (Vector)localeDomainPairs.nextElement();
            ReasonCodeData data = (ReasonCodeData)reasonCodes.elementAt(0);
            if(data.getDomainType().intValue() == reasonType && InfranetLocaleData.isEqual(data.getInfranetLocale(), "en_US", false))
                return reasonCodes;
        }

        return null;
    }

    public Vector getReasonData(int reasonType, Locale javaLocale, int matchType)
    {
        if(!ReasonCodeData.isValidReasonType(reasonType) || javaLocale == null)
        {
            return null;
        } else
        {
            String javaLocStr = InfranetLocaleData.getJavaLocaleStr(javaLocale);
            return getReasonData(reasonType, javaLocStr, matchType);
        }
    }

    public ReasonCodeData[] getReasonDataAsArray(int reasonType, String infranetLocale, int matchType)
    {
        if(!ReasonCodeData.isValidReasonType(reasonType) || infranetLocale == null)
            return null;
        Vector rcData = getReasonData(reasonType, infranetLocale, matchType);
        if(rcData == null)
        {
            return null;
        } else
        {
            ReasonCodeData rcArray[] = new ReasonCodeData[rcData.size()];
            rcData.copyInto(rcArray);
            Arrays.sort(rcArray, m_Comparator);
            return rcArray;
        }
    }

    public ReasonCodeData[] getReasonDataAsArray(int reasonType, Locale javaLocale, int matchType)
    {
        if(!ReasonCodeData.isValidReasonType(reasonType) || javaLocale == null)
            return null;
        Vector rcData = getReasonData(reasonType, javaLocale, matchType);
        if(rcData == null)
        {
            return null;
        } else
        {
            ReasonCodeData rcArray[] = new ReasonCodeData[rcData.size()];
            rcData.copyInto(rcArray);
            Arrays.sort(rcArray, m_Comparator);
            return rcArray;
        }
    }

    private void BuildHashTable()
    {
        m_localeDomainMap = new Hashtable(20, 20F);
        m_localeTypeNameMap = new Hashtable(20, 20F);
        m_localeNameTypeMap = new Hashtable(20, 20F);
        FList inFlist = new FList();
        FList outFlist = new FList();
        try
        {
            Poid searchPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/search");
            inFlist.set(FldPoid.getInst(), searchPoid);
            inFlist.set(FldFlags.getInst(), 256);
            inFlist.set(FldTemplate.getInst(), "select X from /strings where F1 like V1 ");
            FList arg1Flist = new FList();
            arg1Flist.set(FldDomain.getInst(), "Reason Codes-%");
            inFlist.setElement(FldArgs.getInst(), 1, arg1Flist);
            inFlist.setElement(FldResults.getInst(), -1);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("ReasonCodeManager::BuildHashTable - Search input Flist.\n").append(inFlist.toString()).toString());
            outFlist = m_Connection.opcode(7, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("ReasonCodeManager::BuildHashTable - Search output Flist.\n").append(outFlist.toString()).toString());
            SparseArray resultsArray = outFlist.get(FldResults.getInst());
            Vector reasonCodes;
            ReasonCodeData data;
            for(Enumeration resultsIterator = resultsArray.getValueEnumerator(); resultsIterator.hasMoreElements(); reasonCodes.addElement(data))
            {
                FList strFList = (FList)resultsIterator.nextElement();
                String reasonText = strFList.get(FldString.getInst());
                Integer reasonCode = strFList.get(FldStringId.getInst());
                String domainName = strFList.get(FldDomain.getInst());
                String infranetLocale = strFList.get(FldLocale.getInst());
                Integer domainType = strFList.get(FldStrVersion.getInst());
                m_localeTypeNameMap.put(domainType, domainName);
                m_localeNameTypeMap.put(domainName, domainType);
                String localeDomainKey = (new StringBuilder()).append(infranetLocale.toLowerCase()).append(":").append(domainName.toLowerCase()).toString();
                reasonCodes = (Vector)m_localeDomainMap.get(localeDomainKey);
                if(reasonCodes == null)
                {
                    reasonCodes = new Vector(4, 4);
                    m_localeDomainMap.put(localeDomainKey, reasonCodes);
                }
                data = new ReasonCodeData(reasonText, reasonCode, domainType, domainName, infranetLocale);
            }

            return;
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("ReasonCodeManager::BuildHashTable - Search input Flist.\n").append(inFlist.toString()).toString());
                String tmp = outFlist != null ? outFlist.toString() : "<null flist>\n";
                DefaultLog.log(this, 2, (new StringBuilder()).append("ReasonCodeManager::BuildHashTable - Search output Flist.\n").append(tmp).toString());
            }
        }
        BuildHashTableUsingProperties();
    }

    private void BuildHashTableUsingProperties()
    {
        m_localeDomainMap = new Hashtable(20, 20F);
        m_localeTypeNameMap = new Hashtable(20, 20F);
        m_localeNameTypeMap = new Hashtable(20, 20F);
        ResourceBundle bundle = null;
        try
        {
            bundle = ResourceBundle.getBundle("com.portal.common.JavaCommon");
        }
        catch(MissingResourceException exception)
        {
            return;
        }
        try
        {
            int index = 0;
            do
            {
                String baseKey = (new StringBuilder()).append("curclass.rcm").append((new Integer(index)).toString()).toString();
                String reasonText = bundle.getString((new StringBuilder()).append(baseKey).append(".reason").toString());
                Integer reasonCode = new Integer(bundle.getString((new StringBuilder()).append(baseKey).append(".reason_code").toString()));
                Integer domainType = new Integer(bundle.getString((new StringBuilder()).append(baseKey).append(".domain_type").toString()));
                String domainName = bundle.getString((new StringBuilder()).append(baseKey).append(".domain_name").toString());
                String infranetLocale = bundle.getString((new StringBuilder()).append(baseKey).append(".locale").toString());
                String localeDomainKey = (new StringBuilder()).append(infranetLocale.toLowerCase()).append(":").append(domainName.toLowerCase()).toString();
                Vector reasonCodes = (Vector)m_localeDomainMap.get(localeDomainKey);
                if(reasonCodes == null)
                {
                    reasonCodes = new Vector(4, 4);
                    m_localeDomainMap.put(localeDomainKey, reasonCodes);
                    m_localeTypeNameMap.put(domainType, domainName);
                    m_localeNameTypeMap.put(domainName, domainType);
                }
                ReasonCodeData data = new ReasonCodeData(reasonText, reasonCode, domainType, domainName, infranetLocale);
                reasonCodes.addElement(data);
                index++;
            } while(true);
        }
        catch(MissingResourceException exception)
        {
            return;
        }
    }

    private Hashtable m_localeDomainMap;
    private Hashtable m_localeTypeNameMap;
    private Hashtable m_localeNameTypeMap;
    private static RCMInstanceBuilder m_instBuilder = new RCMInstanceBuilder();
    private ReasonCodeComparator m_Comparator;

}