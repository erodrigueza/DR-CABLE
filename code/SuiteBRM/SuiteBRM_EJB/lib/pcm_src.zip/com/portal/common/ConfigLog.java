// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ConfigLog.java

package com.portal.common;

import com.portal.pcm.DefaultLog;
import java.io.PrintStream;

// Referenced classes of package com.portal.common:
//            LoaderOptions

public class ConfigLog
{

    public ConfigLog()
    {
    }

    public static void init(LoaderOptions options)
    {
        mDebug = options.isDebug();
        mVerbose = options.isVerbose();
    }

    public static void logAndExit(String sMessage, int nExitCode)
    {
        mVerbose = true;
        log(sMessage);
        System.exit(nExitCode);
    }

    public static void log(Object source, int nFlag, String objErrorInfo)
    {
        if(nFlag == 8 && !mDebug)
            return;
        if(DefaultLog.doLog(nFlag))
            DefaultLog.log(source, nFlag, objErrorInfo);
    }

    public static void log(Object source, int nFlag, Throwable objErrorInfo)
    {
        if(nFlag == 8 && !mDebug)
            return;
        if(DefaultLog.doLog(nFlag))
            DefaultLog.log(source, nFlag, objErrorInfo);
    }

    public static void log(String sMessage)
    {
        if(mVerbose)
            System.out.println(sMessage);
    }

    private static boolean mVerbose = false;
    private static boolean mDebug = false;

}