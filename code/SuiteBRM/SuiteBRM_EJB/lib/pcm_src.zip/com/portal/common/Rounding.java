// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Rounding.java

package com.portal.common;

import java.util.Calendar;
import java.util.Date;

public class Rounding
{

    public Rounding()
    {
    }

    public static Date roundTo12AMApplyHourOffset(Date time, int hourOffset)
    {
        if(time.getTime() == 0L)
            return time;
        if(hourOffset < 0 || hourOffset > 23)
            return time;
        Calendar cal = Calendar.getInstance();
        cal.setTime(time);
        int hour = cal.get(11);
        if(hourOffset > hour)
            cal.add(6, -1);
        cal.set(10, hourOffset);
        cal.set(12, 0);
        cal.set(13, 0);
        return cal.getTime();
    }
}