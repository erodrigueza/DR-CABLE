// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BEIDData.java

package com.portal.common;

import java.io.Serializable;
import java.math.BigDecimal;

public class BEIDData
    implements Serializable, Comparable
{

    BEIDData(Integer resourceID, String stringCode, String description, String symbol, Integer status, String statusAsString, Integer rounding, 
            Integer roundingMode, Integer javaRoundingMode, BigDecimal toleranceAmountMin, BigDecimal toleranceAmountMax, BigDecimal tolerancePercent)
    {
        m_ResourceID = null;
        m_StringCode = null;
        m_Description = null;
        m_Symbol = null;
        m_IsCurrencyResource = false;
        m_Status = null;
        m_StatusDesc = null;
        m_Rounding = null;
        m_RoundingMode = null;
        m_JavaRoundingMode = null;
        m_ToleranceAmountMin = null;
        m_ToleranceAmountMax = null;
        m_TolerancePercent = null;
        m_ResourceID = resourceID;
        m_StringCode = stringCode;
        m_Description = description;
        m_Symbol = symbol;
        m_Status = status;
        m_StatusDesc = statusAsString;
        m_Rounding = rounding;
        m_RoundingMode = roundingMode;
        m_JavaRoundingMode = javaRoundingMode;
        m_ToleranceAmountMin = toleranceAmountMin;
        m_ToleranceAmountMax = toleranceAmountMax;
        m_TolerancePercent = tolerancePercent;
        m_IsCurrencyResource = isBEIDCurrencyResource(resourceID.intValue());
    }

    public static boolean isBEIDCurrencyResource(int resourceID)
    {
        return resourceID > 0 && resourceID <= 10000;
    }

    public boolean isCurrencyResource()
    {
        return m_IsCurrencyResource;
    }

    public Integer getResourceID()
    {
        return m_ResourceID;
    }

    public String getStringCode()
    {
        return m_StringCode;
    }

    public String getDescription()
    {
        return m_Description;
    }

    public String getSymbol()
    {
        return m_Symbol;
    }

    public Integer getStatus()
    {
        return m_Status;
    }

    public String getStatusAsString()
    {
        return m_StatusDesc;
    }

    public Integer getRounding()
    {
        return m_Rounding;
    }

    public Integer getRoundingMode()
    {
        return m_RoundingMode;
    }

    public Integer getJavaRoundingMode()
    {
        return m_JavaRoundingMode;
    }

    public BigDecimal getToleranceAmountMin()
    {
        return m_ToleranceAmountMin;
    }

    public BigDecimal getToleranceAmountMax()
    {
        return m_ToleranceAmountMax;
    }

    public BigDecimal getTolerancePercent()
    {
        return m_TolerancePercent;
    }

    public String toString()
    {
        return m_Description;
    }

    public int compareTo(Object o)
    {
        return m_Description.compareTo(((BEIDData)o).toString());
    }

    protected Integer m_ResourceID;
    private String m_StringCode;
    private String m_Description;
    private String m_Symbol;
    private boolean m_IsCurrencyResource;
    private Integer m_Status;
    private String m_StatusDesc;
    private Integer m_Rounding;
    private Integer m_RoundingMode;
    private Integer m_JavaRoundingMode;
    private BigDecimal m_ToleranceAmountMin;
    private BigDecimal m_ToleranceAmountMax;
    private BigDecimal m_TolerancePercent;
}