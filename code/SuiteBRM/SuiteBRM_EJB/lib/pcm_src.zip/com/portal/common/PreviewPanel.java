// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PreviewPanel.java

package com.portal.common;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

// Referenced classes of package com.portal.common:
//            PrintPreview, NullPrintableException, PrintManager, HFPageFormat

public class PreviewPanel extends JPanel
    implements ActionListener
{

    public PreviewPanel(PrintManager pm, JComponent sub, HFPageFormat pf, int pi)
    {
        super(new BorderLayout());
        setBackground(Color.black);
        this.pm = pm;
        addControlPanel();
        JPanel pvwPanel = new JPanel(true);
        pvwPanel.setLayout(new GridLayout(pm.getFormattedPagesCount(sub, pf), 1));
        pvwPanel.setBackground(Color.black);
        for(int i = 0; i < pm.getFormattedPagesCount(sub, pf); i++)
        {
            JPanel pvw = new JPanel();
            PrintPreview pp = new PrintPreview(sub, pf, i);
            pp.showPageNumbers(pm.getPageNumbersStatus());
            pp.showDateAndTime(pm.getDateAndTimeStatus());
            pvw.add(pp);
            pvwPanel.add(pvw);
            pvwPanel.revalidate();
        }

        JScrollPane pvwSPane = new JScrollPane(pvwPanel);
        add(pvwSPane);
        revalidate();
    }

    public void addControlPanel()
    {
        JPanel cp = new JPanel();
        BoxLayout bl = new BoxLayout(cp, 0);
        cp.setLayout(bl);
        cp.setBorder(BorderFactory.createEtchedBorder());
        printBut = new JButton("Print");
        printBut.setActionCommand("print");
        printBut.addActionListener(this);
        closeBut = new JButton("Close");
        closeBut.addActionListener(this);
        closeBut.setActionCommand("close");
        cp.add(Box.createHorizontalGlue());
        cp.add(printBut);
        cp.add(Box.createHorizontalStrut(10));
        cp.add(closeBut);
        cp.add(Box.createHorizontalStrut(25));
        add(cp, "South");
    }

    public void actionPerformed(ActionEvent e)
    {
        Object src = e.getSource();
        if(src instanceof JButton)
        {
            JButton but = (JButton)src;
            if(but.getActionCommand().equals("print"))
                try
                {
                    pm.executePrinting(this);
                }
                catch(NullPrintableException ne) { }
            else
            if(but.getActionCommand().equals("close"))
            {
                Component comp;
                for(comp = this; !(comp instanceof JDialog); comp = comp.getParent());
                ((JDialog)comp).dispose();
            }
        } else
        if(!(src instanceof JComboBox))
            if(!(src instanceof JCheckBox));
    }

    private PrintManager pm;
    private JButton printBut;
    private JButton closeBut;
}