// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BusinessTypeData.java

package com.portal.common;

import java.io.Serializable;

public class BusinessTypeData
    implements Serializable
{

    BusinessTypeData(int businessTypeID, String businessTypeDescription)
    {
        m_BusinessTypeID = businessTypeID;
        m_BusinessTypeDescription = businessTypeDescription;
    }

    public int getBusinessTypeID()
    {
        return m_BusinessTypeID;
    }

    public String getBusinessTypeDescription()
    {
        return m_BusinessTypeDescription;
    }

    private int m_BusinessTypeID;
    private String m_BusinessTypeDescription;
}