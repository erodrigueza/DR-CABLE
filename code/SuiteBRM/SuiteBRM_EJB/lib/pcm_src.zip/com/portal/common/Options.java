// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Options.java

package com.portal.common;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.*;

// Referenced classes of package com.portal.common:
//            CommandLineParser

public abstract class Options extends CommandLineParser
{
    protected class StringOptionDef extends OptionDef
    {

        final Options this$0;

        public StringOptionDef(String name, String defValue, String desc)
        {
            this$0 = Options.this;
            super(name, defValue, 1, desc);
        }

        public StringOptionDef(String name, String defValues[], String desc)
        {
            this$0 = Options.this;
            super(name, defValues, -1, desc);
        }

        public StringOptionDef(String name, String desc)
        {
            this$0 = Options.this;
            super(name, 1, desc);
        }
    }

    protected class DateOptionDef extends OptionDef
    {

        public void validateOption(ArrayList values)
            throws CommandLineParser.OptionDataException
        {
            super.validateOption(values);
            String str = (String)values.get(0);
            Date tmp;
            try
            {
                tmp = DateFormat.getDateInstance(3).parse(str);
            }
            catch(ParseException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, getName(), (new StringBuilder()).append("The option '").append(getName()).append("' must have a valid date value <").append(str).append("> following it.").toString());
            }
        }

        private String dateAsStr(Date defValue)
        {
            if(defValue == null)
                defValue = new Date();
            return DateFormat.getDateInstance(3).format(defValue);
        }

        final Options this$0;

        public DateOptionDef(String name, Date defValue, String desc)
        {
            this$0 = Options.this;
            super(name, "", 1, desc);
            mDefaultValues[0] = dateAsStr(defValue);
        }

        public DateOptionDef(String name, String desc)
        {
            this$0 = Options.this;
            super(name, 1, desc);
        }
    }

    protected class DecimalOptionDef extends OptionDef
    {

        public void validateOption(ArrayList values)
            throws CommandLineParser.OptionDataException
        {
            super.validateOption(values);
            String num = (String)values.get(0);
            BigDecimal tmp;
            try
            {
                tmp = new BigDecimal(num);
            }
            catch(NumberFormatException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, getName(), (new StringBuilder()).append("The option '").append(getName()).append("' must have a valid BigDecimal value <").append(num).append("> following it.").toString());
            }
        }

        final Options this$0;

        public DecimalOptionDef(String name, BigDecimal defValue, String desc)
        {
            this$0 = Options.this;
            super(name, defValue.toString(), 1, desc);
        }

        public DecimalOptionDef(String name, String desc)
        {
            this$0 = Options.this;
            super(name, 1, desc);
        }
    }

    protected class IntOptionDef extends OptionDef
    {

        public void validateOption(ArrayList values)
            throws CommandLineParser.OptionDataException
        {
            super.validateOption(values);
            String num = (String)values.get(0);
            Integer tmp;
            try
            {
                tmp = new Integer(num);
            }
            catch(NumberFormatException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, getName(), (new StringBuilder()).append("The option '").append(getName()).append("' must have a valid integer value <").append(num).append("> following it.").toString());
            }
        }

        final Options this$0;

        public IntOptionDef(String name, int defValue, String desc)
        {
            this$0 = Options.this;
            super(name, Integer.toString(defValue), 1, desc);
        }

        public IntOptionDef(String name, String desc)
        {
            this$0 = Options.this;
            super(name, 1, desc);
        }
    }

    protected class FlagOptionDef extends OptionDef
    {

        public void validateOption(ArrayList values)
            throws CommandLineParser.OptionDataException
        {
            if(values.size() != 0)
                throw new CommandLineParser.OptionDataException(Options.this, getName(), (new StringBuilder()).append("The option '").append(getName()).append("' is a boolean flag and does not hava a value: ").append(values.toString()).toString());
            else
                return;
        }

        public String getString(String values[], int i)
            throws CommandLineParser.OptionDataException
        {
            if(i == 0)
                return values != null ? "1" : "0";
            else
                throw new CommandLineParser.OptionDataException(Options.this, getName(), (new StringBuilder()).append("The option '").append(getName()).append("' does not have a value for index ").append(i).append(" (").append(values).append(")").toString());
        }

        final Options this$0;

        public FlagOptionDef(String name, String desc)
        {
            this$0 = Options.this;
            super(name, "0", 0, desc);
        }
    }

    protected abstract class OptionDef
    {

        public String getName()
        {
            return mName;
        }

        public String getDesc()
        {
            return mDesc;
        }

        public String getString(String values[], int i)
            throws CommandLineParser.OptionDataException
        {
            if(values != null && i >= 0 && i < values.length)
                return values[i];
            if(mRequired)
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' does not have a value for index ").append(i).append(" (").append(values).append(")").toString());
            else
                return getIthDefaultAsString(i);
        }

        public Integer getInteger(String values[], int i)
            throws CommandLineParser.OptionDataException
        {
            String str = getString(values, i);
            Integer tmp = null;
            try
            {
                tmp = new Integer(str);
            }
            catch(NumberFormatException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' could not have the ").append(i).append(" value (").append(str).append(") converted to an Integer (").append(values).append(")").toString());
            }
            return tmp;
        }

        public BigDecimal getBigDecimal(String values[], int i)
            throws CommandLineParser.OptionDataException
        {
            String str = getString(values, i);
            BigDecimal tmp = null;
            try
            {
                tmp = new BigDecimal(str);
            }
            catch(NumberFormatException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' could not have the ").append(i).append(" value (").append(str).append(") converted to a BigDecimal (").append(values).append(")").toString());
            }
            return tmp;
        }

        public boolean getBoolean(String values[], int i)
            throws CommandLineParser.OptionDataException
        {
            String str = getString(values, i);
            Integer tmp = null;
            try
            {
                tmp = new Integer(str);
            }
            catch(NumberFormatException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' could not have the ").append(i).append(" value (").append(str).append(") converted to an boolean (").append(values).append(")").toString());
            }
            return tmp.intValue() != 0;
        }

        public Date getDate(String values[], int i)
            throws CommandLineParser.OptionDataException
        {
            String str = getString(values, i);
            Date tmp = null;
            try
            {
                tmp = DateFormat.getDateInstance(3).parse(str);
            }
            catch(ParseException e)
            {
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' could not have the ").append(i).append(" value (").append(str).append(") converted to a Date (").append(values).append(")").toString());
            }
            return tmp;
        }

        public String[] getStrings(String values[])
            throws CommandLineParser.OptionDataException
        {
            if(values != null)
                return values;
            if(mRequired)
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' does not have any default values").toString());
            else
                return mDefaultValues;
        }

        public String[] getDefaultValues()
        {
            return mDefaultValues;
        }

        public boolean isRequiredOption()
        {
            return mRequired;
        }

        public void validateOption(ArrayList values)
            throws CommandLineParser.OptionDataException
        {
            if(mNumValuesNeeded != -1 && values.size() != mNumValuesNeeded)
                throw new CommandLineParser.OptionDataException(Options.this, getName(), (new StringBuilder()).append("The option '").append(getName()).append("' must have ").append(mNumValuesNeeded).append(" values following it.").toString());
            else
                return;
        }

        public int getNumValuesNeeded()
        {
            return mNumValuesNeeded;
        }

        public String toString()
        {
            StringBuffer sb = new StringBuffer(100);
            sb.append("Class: ");
            sb.append(removeClassPath(getClass().getName()));
            sb.append(", Name: ");
            sb.append(getName());
            sb.append(", IsRequired: ");
            sb.append(isRequiredOption());
            sb.append(", Desc: ");
            sb.append(getDesc());
            sb.append(", ValuesNeeded: ");
            sb.append(getNumValuesNeeded());
            sb.append(", Default Values: [");
            sb.append(CommandLineParser.strArrayToString(getDefaultValues()));
            sb.append("]");
            return sb.toString();
        }

        protected String getIthDefaultAsString(int i)
            throws CommandLineParser.OptionDataException
        {
            if(i < 0 || i >= mDefaultValues.length)
                throw new CommandLineParser.OptionDataException(Options.this, mName, (new StringBuilder()).append("The option '").append(mName).append("' does not have a default value for index ").append(i).append(" (").append(mDefaultValues).append(")").toString());
            else
                return mDefaultValues[i];
        }

        private String removeClassPath(String className)
        {
            int index = className.lastIndexOf('.');
            if(index != -1)
                return className.substring(index + 1);
            else
                return className;
        }

        private String mName;
        private boolean mRequired;
        private String mDesc;
        protected String mDefaultValues[];
        protected int mNumValuesNeeded;
        final Options this$0;

        protected OptionDef(String name, int numValuesNeeded, String desc)
        {
            this$0 = Options.this;
            super();
            mName = null;
            mRequired = true;
            mDesc = null;
            mDefaultValues = null;
            mNumValuesNeeded = -1;
            mName = name;
            mRequired = true;
            mDefaultValues = new String[0];
            mNumValuesNeeded = numValuesNeeded;
            mDesc = desc;
        }

        protected OptionDef(String name, String defaultValue, int numValuesNeeded, String desc)
        {
            this$0 = Options.this;
            super();
            mName = null;
            mRequired = true;
            mDesc = null;
            mDefaultValues = null;
            mNumValuesNeeded = -1;
            mName = name;
            mRequired = false;
            mDefaultValues = new String[1];
            mDefaultValues[0] = defaultValue;
            mNumValuesNeeded = numValuesNeeded;
            mDesc = desc;
        }

        protected OptionDef(String name, String defaultValues[], int numValuesNeeded, String desc)
        {
            this$0 = Options.this;
            super();
            mName = null;
            mRequired = true;
            mDesc = null;
            mDefaultValues = null;
            mNumValuesNeeded = -1;
            mName = name;
            mRequired = false;
            mDefaultValues = defaultValues;
            mNumValuesNeeded = numValuesNeeded;
            mDesc = desc;
        }
    }


    protected Options(String args[])
        throws CommandLineParser.InvalidOptionsException
    {
        super(args);
        mOptionDefs = new HashMap(10);
        mNumLeadToks = 0;
        mNumTrailToks = -1;
        addOptionDef(new FlagOptionDef("-h", getStrFromBundle("option.desc.help")));
    }

    protected Options(String args[], int numLeadToks, int numTrailToks)
        throws CommandLineParser.InvalidOptionsException
    {
        this(args);
        mNumLeadToks = numLeadToks;
        mNumTrailToks = numTrailToks;
    }

    public String getString(String optName)
        throws CommandLineParser.NoSuchOptionException, CommandLineParser.OptionDataException
    {
        String values[] = getOptValues(optName);
        OptionDef optDef = getOptionDef(optName);
        return optDef.getString(values, 0);
    }

    public boolean getBoolean(String optName)
        throws CommandLineParser.NoSuchOptionException, CommandLineParser.OptionDataException
    {
        String values[] = getOptValues(optName);
        OptionDef optDef = getOptionDef(optName);
        return optDef.getBoolean(values, 0);
    }

    public Integer getInteger(String optName)
        throws CommandLineParser.NoSuchOptionException, CommandLineParser.OptionDataException
    {
        String values[] = getOptValues(optName);
        OptionDef optDef = getOptionDef(optName);
        return optDef.getInteger(values, 0);
    }

    public BigDecimal getBigDecimal(String optName)
        throws CommandLineParser.NoSuchOptionException, CommandLineParser.OptionDataException
    {
        String values[] = getOptValues(optName);
        OptionDef optDef = getOptionDef(optName);
        return optDef.getBigDecimal(values, 0);
    }

    public Date getDate(String optName)
        throws CommandLineParser.NoSuchOptionException, CommandLineParser.OptionDataException
    {
        String values[] = getOptValues(optName);
        OptionDef optDef = getOptionDef(optName);
        return optDef.getDate(values, 0);
    }

    public String[] getStrings(String optName)
        throws CommandLineParser.NoSuchOptionException, CommandLineParser.OptionDataException
    {
        String values[] = getOptValues(optName);
        OptionDef optDef = getOptionDef(optName);
        return optDef.getStrings(values);
    }

    public String toString()
    {
        StringBuffer sb = new StringBuffer(100);
        sb.append(super.toString());
        sb.append("\r\n Option Defintions:");
        java.util.Map.Entry entry;
        OptionDef optDef;
        for(Iterator itr = mOptionDefs.entrySet().iterator(); itr.hasNext(); sb.append((new StringBuilder()).append("\r\n  ").append((String)entry.getKey()).append(": ").append(optDef.toString()).toString()))
        {
            entry = (java.util.Map.Entry)itr.next();
            optDef = (OptionDef)entry.getValue();
        }

        return sb.toString();
    }

    public boolean isHelp()
    {
        return containsOption("-h") || getArgs().length == 0;
    }

    public String getHelp()
    {
        StringBuffer sb = new StringBuffer(100);
        sb.append(getSyntaxHelp());
        sb.append("\r\n");
        OptionDef optDef;
        for(Iterator itr = mOptionDefs.entrySet().iterator(); itr.hasNext(); sb.append(optDef.getDesc()))
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)itr.next();
            optDef = (OptionDef)entry.getValue();
            sb.append("\r\n");
            sb.append(optDef.getName());
            sb.append("\t");
        }

        return sb.toString();
    }

    protected abstract String getSyntaxHelp();

    protected void validateLeadingTokens(ArrayList tokens)
        throws CommandLineParser.InvalidOptionsException
    {
        if(mNumLeadToks != -1 && tokens.size() != mNumLeadToks)
            throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("There can only be ").append(mNumLeadToks).append(" leading arguments").toString());
        else
            return;
    }

    protected void validateOption(String option, ArrayList values, boolean lastOption)
        throws CommandLineParser.InvalidOptionsException
    {
        OptionDef optDef = null;
        try
        {
            optDef = getOptionDef(option);
        }
        catch(CommandLineParser.NoSuchOptionException e)
        {
            throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("An undefined option has been encountered '").append(option).append("'").toString());
        }
        if(lastOption)
        {
            int numValues = optDef.getNumValuesNeeded();
            if(numValues != -1 && numValues < values.size())
            {
                for(int count = values.size() - numValues; count > 0; count--)
                    values.remove(numValues);

            }
        }
        try
        {
            optDef.validateOption(values);
        }
        catch(CommandLineParser.OptionDataException e)
        {
            throw new CommandLineParser.InvalidOptionsException(this, this, e.getMessage());
        }
    }

    protected void validateTrailingTokens(ArrayList tokens, int numLastOptionArgs)
        throws CommandLineParser.InvalidOptionsException
    {
        if(numLastOptionArgs > 0)
            for(; numLastOptionArgs > 0; numLastOptionArgs--)
                tokens.remove(0);

        if(mNumTrailToks != -1 && tokens.size() != mNumTrailToks)
            throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("There can only be ").append(mNumTrailToks).append(" trailing arguments").toString());
        else
            return;
    }

    protected void validateRequiredParameters()
        throws CommandLineParser.InvalidOptionsException
    {
        for(Iterator itr = mOptionDefs.entrySet().iterator(); itr.hasNext();)
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)itr.next();
            OptionDef optDef = (OptionDef)entry.getValue();
            if(optDef.isRequiredOption() && !containsOption(optDef.getName()))
                throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("The option '").append(optDef.getName()).append("' is required but was not present in the command line arguments.").toString());
        }

    }

    protected boolean storeAllTokensAsLeadingTokens()
    {
        return mNumLeadToks != 0;
    }

    protected final void addOptionDef(OptionDef optDef)
        throws CommandLineParser.InvalidOptionsException
    {
        String optName = optDef.getName().toLowerCase();
        if(!optName.startsWith("-"))
            throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("The option '").append(optDef.getName()).append("' needs to be prefixed with a '-'").toString());
        if(mOptionDefs.containsKey(optName))
        {
            throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("A duplicate option definition for '").append(optDef.getName()).append("' was detected").toString());
        } else
        {
            mOptionDefs.put(optName, optDef);
            return;
        }
    }

    protected final OptionDef getOptionDef(String optName)
        throws CommandLineParser.NoSuchOptionException
    {
        OptionDef optDef = (OptionDef)mOptionDefs.get(optName);
        if(optDef == null)
            throw new CommandLineParser.NoSuchOptionException(this, optName, (new StringBuilder()).append("Cannot find an option definition for: '").append(optName).append("'").toString());
        else
            return optDef;
    }

    protected String[] getOptValues(String optName)
    {
        String values[] = null;
        try
        {
            values = getValues(optName);
        }
        catch(CommandLineParser.NoSuchOptionException e)
        {
            values = null;
        }
        return values;
    }

    public static final String HELP = "-h";
    private HashMap mOptionDefs;
    private int mNumLeadToks;
    private int mNumTrailToks;
}