// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrintPreview.java

package com.portal.common;

import java.awt.*;
import java.awt.print.*;
import java.text.DateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.JTableHeader;

// Referenced classes of package com.portal.common:
//            HFPageFormat

public class PrintPreview extends JPanel
    implements Printable
{

    public PrintPreview(JComponent sub, HFPageFormat pf, int pi)
    {
        super(true);
        dtDisplay = true;
        pnDisplay = true;
        mLeftHeader = null;
        mRightHeader = null;
        mPageHeaderHeight = 0;
        pFormat = pf;
        pageIndex = pi;
        subject = sub;
        setPreferredSize(new Dimension((int)pf.getWidth(), (int)pf.getHeight()));
        setMinimumSize(new Dimension((int)pf.getWidth(), (int)pf.getHeight()));
        setMaximumSize(new Dimension((int)pf.getWidth(), (int)pf.getHeight()));
        setBackground(Color.white);
        if(dtDisplay)
            pFormat.setLeftFooterText(getDateAndTime());
        if(pnDisplay)
            pFormat.setRightFooterText(Integer.toString(pageIndex + 1));
    }

    public void setLeftHeaderText(String header)
    {
        mLeftHeader = header;
        pFormat.setLeftHeaderText(mLeftHeader);
    }

    public void setRightHeaderText(String header)
    {
        mRightHeader = header;
        pFormat.setRightHeaderText(mRightHeader);
    }

    public void showDateAndTime(boolean b)
    {
        dtDisplay = b;
        if(dtDisplay)
            pFormat.setLeftFooterText(getDateAndTime());
        else
            pFormat.setLeftFooterText(null);
    }

    public void showPageNumbers(boolean b)
    {
        pnDisplay = b;
        if(pnDisplay)
            pFormat.setRightFooterText(Integer.toString(pageIndex + 1));
        else
            pFormat.setRightFooterText(null);
    }

    public String getDateAndTime()
    {
        DateFormat dtF = DateFormat.getDateTimeInstance(3, 1);
        String dt = dtF.format(new Date());
        return dt;
    }

    public int getFormattedTableHeight(HFPageFormat pf)
    {
        if(!(subject instanceof JTable) || ((JTable)subject).getRowHeight() == 0)
        {
            return 0;
        } else
        {
            double Heff = pf.getImageableHeight() - (double)((JTable)subject).getTableHeader().getHeight();
            double rowCount = Heff / (double)((JTable)subject).getRowHeight();
            int formattedTableHeight = (int)(rowCount * (double)((JTable)subject).getRowHeight());
            return formattedTableHeight;
        }
    }

    protected void renderComponent(Graphics2D g2d, int scaledPageH, int UP_SHIFT, double scale)
    {
        JComponent jc = subject;
        Graphics2D g2;
        if(jc instanceof JTable)
        {
            int ROW_HEIGHT = 0;
            int rows = 0;
            ROW_HEIGHT = ((JTable)jc).getRowHeight();
            if(ROW_HEIGHT != 0)
                rows = (int)Math.floor((double)getFormattedTableHeight(pFormat) / scale / (double)ROW_HEIGHT) + 1;
            int tableShift = rows * ROW_HEIGHT;
            int tableHeaderHeight = ((JTable)jc).getTableHeader().getHeight();
            g2 = (Graphics2D)g2d.create(0, (0 - tableShift * pageIndex) + tableHeaderHeight, jc.getWidth(), (int)pFormat.getImageableHeight() + tableShift * pageIndex);
            g2.setClip(0, tableShift * pageIndex, jc.getWidth(), tableShift);
        } else
        {
            g2 = (Graphics2D)g2d.create(0, 0 - UP_SHIFT, jc.getWidth(), (int)pFormat.getImageableHeight() + UP_SHIFT);
            g2.setClip(0, UP_SHIFT, jc.getWidth(), scaledPageH);
        }
        if(jc.isDoubleBuffered())
        {
            jc.setDoubleBuffered(false);
            jc.paint(g2);
            jc.setDoubleBuffered(true);
        } else
        {
            jc.paint(g2);
        }
        g2.dispose();
    }

    protected void renderTableHeader(Graphics2D g2, int imgX, int imgY, int imgW, int imgH)
    {
        g2 = (Graphics2D)g2.create(imgX, imgY, imgW, ((JTable)subject).getTableHeader().getHeight());
        if(subject instanceof JTable)
            if(((JTable)subject).getTableHeader().isDoubleBuffered())
            {
                ((JTable)subject).getTableHeader().setDoubleBuffered(false);
                ((JTable)subject).getTableHeader().paint(g2);
                ((JTable)subject).getTableHeader().setDoubleBuffered(true);
            } else
            {
                ((JTable)subject).getTableHeader().paint(g2);
            }
    }

    protected void renderDateAndTime(Graphics2D g, int imgX, int imgY, int imgW, int imgH, int pOffSet)
    {
        if(dtDisplay)
        {
            g.setColor(Color.black);
            g.setClip(imgX, imgY, imgW, imgH + imgY + pOffSet);
            g.drawString(getDateAndTime(), imgX, imgY + imgH + pOffSet);
        }
    }

    protected void renderPageNumbers(Graphics g, int imgX, int imgY, int imgW, int imgH, int pOffSet)
    {
        if(pnDisplay)
        {
            g.setColor(Color.black);
            g.setClip(imgX, imgY, imgW, imgH + imgY + pOffSet);
            g.drawString(Integer.toString(pageIndex + 1), (imgX + imgW) - 10, imgY + imgH + pOffSet);
        }
    }

    protected void renderPageHeader(Graphics g)
    {
        if(mLeftHeader == null && mRightHeader == null)
        {
            return;
        } else
        {
            Color cTemp = g.getColor();
            g.setColor(Color.black);
            FontMetrics fm = g.getFontMetrics();
            int maxAscent = fm.getMaxAscent();
            int maxDescent = fm.getMaxDescent();
            g.drawString(mLeftHeader, 0, g.getFontMetrics().getMaxAscent());
            g.drawString(mRightHeader, (int)pFormat.getImageableWidth() - fm.stringWidth(mRightHeader), g.getFontMetrics().getMaxAscent());
            g.drawLine(0, maxAscent + maxDescent, (int)pFormat.getImageableWidth(), maxAscent + maxDescent);
            mPageHeaderHeight = maxAscent + maxDescent + 5;
            g.translate(0, mPageHeaderHeight);
            g.setColor(cTemp);
            return;
        }
    }

    protected void renderPageHeaderFooter(Graphics g)
    {
        if(dtDisplay)
            pFormat.setLeftFooterText(getDateAndTime());
        else
            pFormat.setLeftFooterText(null);
        if(pnDisplay)
            pFormat.setRightFooterText(Integer.toString(pageIndex + 1));
        else
            pFormat.setRightFooterText(null);
        pFormat.print(g, pFormat, pageIndex);
    }

    public void paint(Graphics g)
    {
        renderPageHeaderFooter(g);
        int pageW = (int)pFormat.getWidth();
        int pageH = (int)pFormat.getHeight();
        int imgX = (int)pFormat.getImageableX();
        int imgY = (int)pFormat.getImageableY();
        int imgW = (int)pFormat.getImageableWidth();
        int imgH = (int)pFormat.getImageableHeight();
        int subjW = subject.getWidth();
        int subjH = subject.getHeight();
        Graphics2D g2 = (Graphics2D)g.create(imgX, imgY, imgW, imgH);
        double scale = 1.0D;
        if(subject.getWidth() != 0)
            scale = pFormat.getImageableWidth() / (double)subject.getWidth();
        g2.scale(scale, scale);
        int scaledPageH = (int)((double)imgH / scale);
        int UP_SHIFT = pageIndex * scaledPageH;
        g2.setColor(Color.white);
        g2.fillRect(0, 0, imgW, imgH);
        if(subject instanceof JTable)
            renderTableHeader(g2, 0, 0, subjW, scaledPageH);
        renderComponent(g2, scaledPageH, UP_SHIFT, scale);
        g2.dispose();
        g.dispose();
    }

    public int print(Graphics g, PageFormat pf, int pageIndex)
        throws PrinterException
    {
        setSize(new Dimension((int)pf.getWidth(), (int)pf.getHeight()));
        if(pFormat == null)
            pFormat = (HFPageFormat)pf;
        paint(g);
        return 0;
    }

    private HFPageFormat pFormat;
    private int pageIndex;
    private JComponent subject;
    private boolean dtDisplay;
    private boolean pnDisplay;
    private String mLeftHeader;
    private String mRightHeader;
    private final int PAGE_HEADER_PADDING = 5;
    private final int SIDE_PADDING = 5;
    private int mPageHeaderHeight;
}