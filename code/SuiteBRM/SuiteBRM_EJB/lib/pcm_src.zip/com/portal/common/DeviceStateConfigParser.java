// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   DeviceStateConfigParser.java

package com.portal.common;

import com.portal.pcm.FList;
import com.portal.pcm.SparseArray;
import com.portal.pcm.fields.*;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;

// Referenced classes of package com.portal.common:
//            FileParser, LoaderOptions, ConfigLog

public class DeviceStateConfigParser extends FileParser
{
    private class IncompleteDeviceEntryException extends Exception
    {

        final DeviceStateConfigParser this$0;

        public IncompleteDeviceEntryException(String sMessage)
        {
            this$0 = DeviceStateConfigParser.this;
            super(sMessage);
        }
    }

    private class DuplicateEntryException extends Exception
    {

        final DeviceStateConfigParser this$0;

        public DuplicateEntryException(String sMessage)
        {
            this$0 = DeviceStateConfigParser.this;
            super(sMessage);
        }
    }

    private class NextState
    {

        public int getNextID()
        {
            return mNextID;
        }

        public int getOpcode()
        {
            return mOpcode;
        }

        public int getFlags()
        {
            return mFlags;
        }

        public void dump()
        {
            System.out.println("");
            System.out.println((new StringBuilder()).append("\t\tNextID:").append(getNextID()).toString());
            System.out.println((new StringBuilder()).append("\t\tOpcodeNum:").append(getOpcode()).toString());
            System.out.println((new StringBuilder()).append("\t\tFlags:").append(getFlags()).toString());
            System.out.println("");
        }

        public boolean equals(NextState nextState)
        {
            return nextState.getNextID() == getNextID();
        }

        private int mNextID;
        private int mOpcode;
        private int mFlags;
        final DeviceStateConfigParser this$0;

        public NextState(int nNextID, int nOpcodeNum, int nFlags)
        {
            this$0 = DeviceStateConfigParser.this;
            super();
            mNextID = nNextID;
            mOpcode = nOpcodeNum;
            mFlags = nFlags;
        }
    }

    private class StartState
    {

        public int getStartID()
        {
            return mStateID;
        }

        public int getStateType()
        {
            return mStateType;
        }

        public int getID()
        {
            return mStringID;
        }

        public int getVersion()
        {
            return mStringVersion;
        }

        public int getOpcode()
        {
            return mOpcode;
        }

        public int getFlags()
        {
            return mFlags;
        }

        public void dump()
        {
            System.out.println("");
            System.out.println((new StringBuilder()).append("\tStartStateID:").append(getStartID()).toString());
            System.out.println((new StringBuilder()).append("\tStartStateType:").append(getStateType()).toString());
            System.out.println((new StringBuilder()).append("\tStringID:").append(getID()).toString());
            System.out.println((new StringBuilder()).append("\tStringVersion:").append(getVersion()).toString());
            System.out.println((new StringBuilder()).append("\tOpcodeNumber:").append(getOpcode()).toString());
            System.out.println((new StringBuilder()).append("\tFlags:").append(getFlags()).toString());
            System.out.println("");
        }

        public boolean equals(StartState startState)
        {
            return startState.getStartID() == getStartID();
        }

        private int mStateID;
        private int mStateType;
        private int mStringID;
        private int mStringVersion;
        private int mOpcode;
        private int mFlags;
        final DeviceStateConfigParser this$0;

        public StartState(int nStartID, int nStateType, int nID, int nVersion, int nOpcode, int nFlags)
        {
            this$0 = DeviceStateConfigParser.this;
            super();
            mStateID = nStartID;
            mStateType = nStateType;
            mStringID = nID;
            mStringVersion = nVersion;
            mOpcode = nOpcode;
            mFlags = nFlags;
        }
    }

    private class StateTransitions
    {

        public StartState getStartState()
        {
            return mStartState;
        }

        public void addNextState(NextState nextState)
            throws DuplicateEntryException
        {
            Vector vNextStates = getNextStates();
            for(int i = 0; i < vNextStates.size(); i++)
            {
                NextState st = (NextState)vNextStates.elementAt(i);
                if(st.equals(nextState))
                    throw new DuplicateEntryException((new StringBuilder()).append("Duplicate Next State Entry: ").append(nextState.getNextID()).toString());
            }

            mNextStatesVector.addElement(nextState);
        }

        public Vector getNextStates()
        {
            return mNextStatesVector;
        }

        private StartState mStartState;
        private Vector mNextStatesVector;
        final DeviceStateConfigParser this$0;

        public StateTransitions(StartState startState, Device dDevice)
            throws DuplicateEntryException
        {
            this$0 = DeviceStateConfigParser.this;
            super();
            mNextStatesVector = new Vector();
            Vector vStateTransitions = dDevice.getStateTransitions();
            for(int i = 0; i < vStateTransitions.size(); i++)
            {
                StateTransitions st = (StateTransitions)vStateTransitions.elementAt(i);
                StartState tStartState = st.getStartState();
                if(tStartState.equals(startState))
                    throw new DuplicateEntryException((new StringBuilder()).append("Duplicate Start State Entry for device: ").append(dDevice.getDeviceType()).toString());
            }

            mStartState = startState;
            dDevice.addStateTransition(this);
        }
    }

    private class Device
    {

        public String getDeviceType()
        {
            return mDeviceType;
        }

        public void addStateTransition(StateTransitions state)
        {
            mTransitionsVector.addElement(state);
        }

        public Vector getStateTransitions()
        {
            return mTransitionsVector;
        }

        public void checkValid()
            throws IncompleteDeviceEntryException
        {
            if(mTransitionsVector.size() == 0)
                throw new IncompleteDeviceEntryException((new StringBuilder()).append("NO state transitions defined for device: ").append(getDeviceType()).toString());
            for(int i = 0; i < mTransitionsVector.size(); i++)
            {
                StateTransitions st = (StateTransitions)mTransitionsVector.elementAt(i);
                if(st.getNextStates().size() == 0)
                    throw new IncompleteDeviceEntryException((new StringBuilder()).append("NO Next states defined for start state: ").append(st.getStartState().getStartID()).append(" in Device: ").append(getDeviceType()).toString());
            }

        }

        private String mDeviceType;
        private Vector mTransitionsVector;
        final DeviceStateConfigParser this$0;

        public Device(String sDeviceType)
        {
            this$0 = DeviceStateConfigParser.this;
            super();
            mTransitionsVector = new Vector();
            mDeviceType = sDeviceType;
        }
    }


    public DeviceStateConfigParser(LoaderOptions options)
    {
        mLineNum = 1;
        mFileName = "";
        mStorableObject = null;
        mFileName = options.getFileName();
    }

    public String getStorableObject()
    {
        parseFileForStorableObject();
        return mStorableObject;
    }

    public FList parseFile()
    {
        Vector vDeviceList = parseFileVector();
        return getFList(vDeviceList);
    }

    private void parseFileForStorableObject()
    {
        mLineNum = 1;
        String sLine = null;
        boolean bFound = false;
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(mFileName));
            for(sLine = br.readLine(); sLine != null && !bFound; sLine = br.readLine())
            {
                sLine = sLine.trim();
                if(!sLine.startsWith("#") && sLine.length() > 0)
                {
                    String sLineType = getLineType(sLine);
                    if(sLineType.equals("StorableObjectType"))
                    {
                        mStorableObject = sLine;
                        bFound = true;
                    } else
                    {
                        ConfigLog.logAndExit((new StringBuilder()).append("Storable class should be specified first: Not found on").append(mLineNum).append(": ").append(sLine).toString(), -1);
                    }
                }
                mLineNum++;
            }

            br.close();
            if(!bFound)
                ConfigLog.logAndExit("Storable class Not found in the Configuration File", -1);
        }
        catch(IOException e)
        {
            System.out.println((new StringBuilder()).append("IOException e: ").append(e).toString());
        }
    }

    private Vector parseFileVector()
    {
        mLineNum = 1;
        String sLine = null;
        Vector vDeviceList = new Vector();
        mStorableObject = null;
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(mFileName));
            sLine = br.readLine();
            Device dDevice = null;
            StartState sStartState = null;
            NextState nNextState = null;
            StateTransitions sStateTransitions = null;
            for(; sLine != null; sLine = br.readLine())
            {
                sLine = sLine.trim();
                if(!sLine.startsWith("#") && sLine.length() > 0)
                {
                    String sLineType = getLineType(sLine);
                    if(sLineType.equals("StorableObjectType"))
                        mStorableObject = sLine;
                    else
                    if(sLineType.equals("DeviceType"))
                    {
                        if(dDevice != null)
                            dDevice.checkValid();
                        dDevice = createDevice(sLine, vDeviceList);
                    } else
                    if(sLineType.equals("StartState"))
                    {
                        if(dDevice != null)
                        {
                            sStartState = getStartState(sLine);
                            if(sStartState != null)
                                sStateTransitions = new StateTransitions(sStartState, dDevice);
                            else
                                ConfigLog.logAndExit((new StringBuilder()).append("Device: ").append(dDevice.getDeviceType()).append("start state info not found: ").append(mLineNum).append(": ").append(sLine).toString(), -1);
                        } else
                        {
                            ConfigLog.logAndExit((new StringBuilder()).append("No Device specified, Start state info found:").append(mLineNum).append(": ").append(sLine).toString(), -1);
                        }
                    } else
                    if(sLineType.equals("NextState"))
                    {
                        if(dDevice != null)
                        {
                            if(sStateTransitions != null)
                            {
                                nNextState = getNextState(sLine);
                                if(nNextState != null)
                                    sStateTransitions.addNextState(nNextState);
                                else
                                    ConfigLog.logAndExit((new StringBuilder()).append("Device: ").append(dDevice.getDeviceType()).append(" next state info not found: ").append(mLineNum).append(": ").append(sLine).toString(), -1);
                            }
                        } else
                        {
                            ConfigLog.logAndExit((new StringBuilder()).append("Device: ").append(dDevice.getDeviceType()).append(" Next state found before Start state info : ").append(mLineNum).append(": ").append(sLine).toString(), -1);
                        }
                    } else
                    {
                        ConfigLog.logAndExit((new StringBuilder()).append("Unexpected Entry found:").append(mLineNum).append(": ").append(sLine).toString(), -1);
                    }
                }
                mLineNum++;
            }

            br.close();
        }
        catch(IOException e)
        {
            System.out.println((new StringBuilder()).append("IOException e: ").append(e).toString());
        }
        catch(DuplicateEntryException e)
        {
            ConfigLog.logAndExit((new StringBuilder()).append("Line: ").append(mLineNum).append(": ").append(sLine).append(" Message: ").append(e.getMessage()).toString(), -1);
        }
        catch(IncompleteDeviceEntryException e)
        {
            ConfigLog.logAndExit((new StringBuilder()).append("Line: ").append(mLineNum).append(": ").append(sLine).append(" Message: ").append(e.getMessage()).toString(), -1);
        }
        return vDeviceList;
    }

    private Device createDevice(String sDevice, Vector vDeviceList)
        throws DuplicateEntryException
    {
        for(int i = 0; i < vDeviceList.size(); i++)
        {
            Device d = (Device)vDeviceList.elementAt(i);
            if(d.getDeviceType().equals(sDevice))
                throw new DuplicateEntryException((new StringBuilder()).append("Duplicate Device: ").append(sDevice).toString());
        }

        Device dDevice = new Device(sDevice);
        vDeviceList.addElement(dDevice);
        return dDevice;
    }

    private FList getFList(Vector vDevices)
    {
        FList createFlist = new FList();
        createFlist.set(FldProgramName.getInst(), "LoadDeviceStateConfig");
        createFlist.set(FldName.getInst(), "pin_device_state");
        createFlist.set(FldHostname.getInst(), "-");
        FList deviceTypeSubstruct = new FList();
        createFlist.set(FldTypeInfo.getInst(), deviceTypeSubstruct);
        SparseArray deviceStatesArray = new SparseArray();
        for(int i = 0; i < vDevices.size(); i++)
        {
            Device device = (Device)vDevices.elementAt(i);
            deviceTypeSubstruct.set(FldDeviceType.getInst(), device.getDeviceType());
            Vector vTransitions = device.getStateTransitions();
            for(int j = 0; j < vTransitions.size(); j++)
            {
                StateTransitions st = (StateTransitions)vTransitions.elementAt(j);
                StartState startState = st.getStartState();
                FList deviceStateElem = new FList();
                deviceStateElem.set(FldStateId.getInst(), startState.getStartID());
                deviceStateElem.set(FldStateType.getInst(), startState.getStateType());
                deviceStateElem.set(FldStringId.getInst(), startState.getID());
                deviceStateElem.set(FldStrVersion.getInst(), startState.getVersion());
                deviceStateElem.set(FldOpcode.getInst(), startState.getOpcode());
                deviceStateElem.set(FldFlags.getInst(), startState.getFlags());
                Vector vNextStates = st.getNextStates();
                SparseArray nextStatesArray = new SparseArray();
                for(int k = 0; k < vNextStates.size(); k++)
                {
                    NextState nextState = (NextState)vNextStates.elementAt(k);
                    FList nextStateElem = new FList();
                    nextStateElem.set(FldStateId.getInst(), nextState.getNextID());
                    nextStateElem.set(FldFlags.getInst(), nextState.getFlags());
                    nextStateElem.set(FldOpcode.getInst(), nextState.getOpcode());
                    nextStatesArray.add(nextStateElem);
                }

                deviceStateElem.set(FldNextStates.getInst(), nextStatesArray);
                deviceStatesArray.add(deviceStateElem);
            }

        }

        createFlist.set(FldDeviceStates.getInst(), deviceStatesArray);
        return createFlist;
    }

    private String getLineType(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        if(st.countTokens() == 6)
            return "StartState";
        if(st.countTokens() == 3)
            return "NextState";
        if(sLine.startsWith("/"))
        {
            if(mStorableObject == null)
                return "StorableObjectType";
            else
                return "DeviceType";
        } else
        {
            return "Unknown Entry";
        }
    }

    private StartState getStartState(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        try
        {
            int nStateID = Integer.parseInt(st.nextToken().trim());
            int nStateType = Integer.parseInt(st.nextToken().trim());
            int nStringID = Integer.parseInt(st.nextToken().trim());
            int nStringVersion = Integer.parseInt(st.nextToken().trim());
            int nOpcodeNum = Integer.parseInt(st.nextToken().trim());
            int nFlags = Integer.parseInt(st.nextToken().trim());
            return new StartState(nStateID, nStateType, nStringID, nStringVersion, nOpcodeNum, nFlags);
        }
        catch(NumberFormatException e)
        {
            ConfigLog.log(this, 2, e);
        }
        ConfigLog.logAndExit((new StringBuilder()).append("Exception in line:").append(mLineNum).append(":").append(sLine).toString(), -1);
        return null;
    }

    private NextState getNextState(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        try
        {
            int nStateID = Integer.parseInt(st.nextToken().trim());
            int nOpcode = Integer.parseInt(st.nextToken().trim());
            int nFlags = Integer.parseInt(st.nextToken().trim());
            return new NextState(nStateID, nOpcode, nFlags);
        }
        catch(NumberFormatException e)
        {
            ConfigLog.log(this, 2, e);
        }
        ConfigLog.logAndExit((new StringBuilder()).append("Exception in line:").append(mLineNum).append(":").append(sLine).toString(), -1);
        return null;
    }

    public static void main(String args[])
    {
        LoaderOptions options = LoaderOptions.createLoaderOptionsAndExitOnErrorOrHelp(args);
        ConfigLog.init(options);
        DeviceStateConfigParser dcsParser = new DeviceStateConfigParser(options);
        Vector vDevices = dcsParser.parseFileVector();
        for(int i = 0; i < vDevices.size(); i++)
        {
            Device device = (Device)vDevices.elementAt(i);
            ConfigLog.log((new StringBuilder()).append("DeviceType: ").append(device.getDeviceType()).toString());
            Vector vTransitions = device.getStateTransitions();
            for(int j = 0; j < vTransitions.size(); j++)
            {
                StateTransitions st = (StateTransitions)vTransitions.elementAt(j);
                StartState startState = st.getStartState();
                startState.dump();
                Vector vNextStates = st.getNextStates();
                for(int k = 0; k < vNextStates.size(); k++)
                {
                    NextState nextState = (NextState)vNextStates.elementAt(k);
                    nextState.dump();
                }

            }

        }

        System.exit(0);
    }

    private int mLineNum;
    private String mFileName;
    private String mStorableObject;
}