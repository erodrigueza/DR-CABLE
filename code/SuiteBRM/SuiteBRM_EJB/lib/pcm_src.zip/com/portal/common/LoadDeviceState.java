// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoadDeviceState.java

package com.portal.common;


// Referenced classes of package com.portal.common:
//            LoadPinConfig, DeviceStateConfigParser, LoadPinConfigParams, LoaderOptions, 
//            FileParser

public class LoadDeviceState extends LoadPinConfig
{

    public LoadDeviceState(LoaderOptions options)
    {
        super(options);
        mDeviceStateConfigParser = null;
    }

    public FileParser createParser(LoaderOptions options)
    {
        if(mDeviceStateConfigParser == null)
            mDeviceStateConfigParser = new DeviceStateConfigParser(options);
        return mDeviceStateConfigParser;
    }

    public String getStorableObject(LoaderOptions options)
    {
        if(mDeviceStateConfigParser == null)
            mDeviceStateConfigParser = new DeviceStateConfigParser(options);
        return mDeviceStateConfigParser.getStorableObject();
    }

    public static void main(String args[])
    {
        LoaderOptions options = LoaderOptions.createLoaderOptionsAndExitOnErrorOrHelp(args);
        LoadDeviceState ldConfig = new LoadDeviceState(options);
        ldConfig.processConfig(new LoadPinConfigParams(ldConfig.getStorableObject(options), 1, 2));
    }

    public volatile void processConfig(LoadPinConfigParams x0)
    {
        super.processConfig(x0);
    }

    private DeviceStateConfigParser mDeviceStateConfigParser;
}