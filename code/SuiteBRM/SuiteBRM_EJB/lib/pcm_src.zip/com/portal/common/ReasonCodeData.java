// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ReasonCodeData.java

package com.portal.common;

import java.io.Serializable;

public class ReasonCodeData
    implements Serializable
{

    ReasonCodeData(String reason, Integer reasonCode, Integer domainType, String domainName, String infranetLocaleStr)
    {
        m_reason = null;
        m_reasonCode = null;
        m_domainType = null;
        m_domainName = null;
        m_infranetLocale = null;
        m_reason = reason;
        m_reasonCode = reasonCode;
        m_domainType = domainType;
        m_domainName = domainName;
        m_infranetLocale = infranetLocaleStr;
    }

    public static boolean isValidReasonType(int reasonType)
    {
        return reasonType >= 1 && reasonType <= 43 || reasonType >= 100;
    }

    public String getReason()
    {
        return m_reason;
    }

    public Integer getReasonCode()
    {
        return m_reasonCode;
    }

    public Integer getDomainType()
    {
        return m_domainType;
    }

    public String getDomainName()
    {
        return m_domainName;
    }

    public String getInfranetLocale()
    {
        return m_infranetLocale;
    }

    public String toString()
    {
        return m_reason;
    }

    public static final int ACCT_DEBIT = 1;
    public static final int ACCT_ACTIVE_STATUS = 2;
    public static final int ACCT_INACTIVE_STATUS = 3;
    public static final int ACCT_CLOSED_STATUS = 4;
    public static final int ACCT_CHARGE = 5;
    public static final int ACCT_REFUND = 6;
    public static final int ACCT_CREDIT_LIMIT = 7;
    public static final int ACCT_CREDIT = 8;
    public static final int ACTION_RESCHEDULE = 9;
    public static final int ACTION_INSERT = 10;
    public static final int ACCOUNT_EXEMPT = 11;
    public static final int FIRST_VALID_REASON = 1;
    public static final int ITEM_DISPUTE_CREDIT = 34;
    public static final int ITEM_DISPUTE_DEBIT = 35;
    public static final int ITEM_SETTLE = 36;
    public static final int EVENT_DISPUTE_CRIDIT = 39;
    public static final int EVENT_DISPUTE_DEBIT = 40;
    public static final int EVENT_SETTLE = 41;
    public static final int LAST_VALID_REASON = 43;
    public static final int ACCT_NON_CURRENCY_INCREASE = 21;
    public static final int ACCT_NON_CURRENCY_REDUCE = 22;
    public static final int BILL_DEBIT = 24;
    public static final int BILL_CREDIT = 23;
    public static final int CONN_CURRENCY_CREDIT = 28;
    public static final int CONN_CURRENCY_DEBIT = 29;
    public static final int CONN_NON_CURRENCY_INCREASE = 30;
    public static final int CONN_NON_CURRENCY_REDUCE = 31;
    public static final int ITEM_ADJ_DEBIT = 33;
    public static final int ITEM_ADJ_CREDIT = 32;
    public static final int EVENT_ADJ_DEBIT = 38;
    public static final int EVENT_ADJ_CREDIT = 37;
    public static final int CUSTOM_REASON_CODE = 100;
    public static final int CORRECTION_REASON_CODE = 43;
    private String m_reason;
    private Integer m_reasonCode;
    private Integer m_domainType;
    private String m_domainName;
    private String m_infranetLocale;
}