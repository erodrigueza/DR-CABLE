// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PCurrencyFormatter.java

package com.portal.common;

import com.portal.pcm.PortalContext;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Hashtable;

// Referenced classes of package com.portal.common:
//            FormatInfo, BEIDManager, BEIDData

public class PCurrencyFormatter extends DecimalFormat
{

    private PCurrencyFormatter(int currencyID)
    {
        if(!isCurrencyID(currencyID))
            throw new IllegalArgumentException("Not a currencyID");
        FormatInfo fmtInfo = new FormatInfo(currencyID);
        DecimalFormatSymbols fmtSymbols = new DecimalFormatSymbols();
        fmtSymbols.setCurrencySymbol(fmtInfo.getLocalCurrencySymbol());
        fmtSymbols.setInternationalCurrencySymbol(fmtInfo.getInternationalCurrencySymbol());
        if(currencyID != 978)
        {
            fmtSymbols.setDecimalSeparator(fmtInfo.getDecimalSeparator());
            fmtSymbols.setMonetaryDecimalSeparator(fmtInfo.getDecimalSeparator());
            fmtSymbols.setGroupingSeparator(fmtInfo.getGroupSeparator());
        }
        String pattern = fmtInfo.getFormatPattern();
        applyPattern(pattern);
        if(mConnection != null)
        {
            BEIDManager beidMgr = BEIDManager.getInstance(mConnection);
            BEIDData beidData = beidMgr.getData(currencyID);
            String internationalSymbol = beidData.getStringCode();
            String currencySymbol = beidData.getSymbol();
            int rounding = beidData.getRounding().intValue();
            if(rounding >= 0)
            {
                setMaximumFractionDigits(rounding);
                setMinimumFractionDigits(rounding);
            }
            if(currencySymbol != null || currencySymbol.length() != 0)
            {
                if(currencyID == 978 && currencySymbol.equalsIgnoreCase("E"))
                    currencySymbol = EURO_SYMBOL;
                fmtSymbols.setCurrencySymbol(currencySymbol);
            }
            if(internationalSymbol != null || internationalSymbol.length() != 0)
                fmtSymbols.setInternationalCurrencySymbol(internationalSymbol);
        }
        setDecimalFormatSymbols(fmtSymbols);
        cachedFmtInfo.put(Integer.toString(currencyID), this);
    }

    public static void setContext(PortalContext connection)
    {
        mConnection = connection;
    }

    public static int getRoundingMethod(int currencyID)
    {
        if(mConnection != null)
        {
            BEIDManager beidMgr = BEIDManager.getInstance(mConnection);
            BEIDData beidData = beidMgr.getData(currencyID);
            return beidData.getJavaRoundingMode().intValue();
        } else
        {
            return -1;
        }
    }

    public static boolean isCurrencyID(int currencyID)
    {
        return currencyID >= 4 && currencyID <= 1000;
    }

    public static PCurrencyFormatter getInstance(int currencyID)
    {
        if(cachedFmtInfo.containsKey(Integer.toString(currencyID)))
        {
            return (PCurrencyFormatter)cachedFmtInfo.get(Integer.toString(currencyID));
        } else
        {
            PCurrencyFormatter curFmt = new PCurrencyFormatter(currencyID);
            return curFmt;
        }
    }

    private static Hashtable cachedFmtInfo = new Hashtable(10);
    private static final String EURO_SYMBOL = new String(" \u20AC");
    private static PortalContext mConnection;

}