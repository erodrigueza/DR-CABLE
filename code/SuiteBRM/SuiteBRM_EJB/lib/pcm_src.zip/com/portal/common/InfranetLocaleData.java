// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   InfranetLocaleData.java

package com.portal.common;

import java.io.Serializable;
import java.util.Locale;

public class InfranetLocaleData
    implements Serializable, Comparable
{

    InfranetLocaleData(String infranetLocale, String javaLocale, int descriptionID, String localeDescription, String descriptionLocale)
    {
        m_infranetLocale = null;
        m_javaLocale = null;
        m_descriptionID = 0;
        m_description = null;
        m_descriptionLocale = null;
        m_infranetLocale = infranetLocale;
        m_javaLocale = javaLocale;
        m_descriptionID = descriptionID;
        m_description = localeDescription;
        m_descriptionLocale = descriptionLocale;
    }

    public String getInfranetLocale()
    {
        return m_infranetLocale;
    }

    public String getJavaLocale()
    {
        return m_javaLocale;
    }

    public int getLocaleDescriptionID()
    {
        return m_descriptionID;
    }

    public String getLocaleDescription()
    {
        return m_description;
    }

    public String getDescriptionLocale()
    {
        return m_descriptionLocale;
    }

    public static boolean isEqual(String infranetLocale1, String infranetLocale2, boolean extactMatch)
    {
        if(infranetLocale1 == null || infranetLocale2 == null)
            return false;
        boolean rtn = infranetLocale1.equalsIgnoreCase(infranetLocale2);
        if(!rtn && !extactMatch)
            try
            {
                rtn = infranetLocale1.substring(0, 2).equalsIgnoreCase(infranetLocale2.substring(0, 2));
            }
            catch(StringIndexOutOfBoundsException e)
            {
                rtn = false;
            }
        return rtn;
    }

    public boolean isEqual(String infranetLocale, boolean extactMatch)
    {
        return isEqual(m_infranetLocale, infranetLocale, extactMatch);
    }

    public boolean isEqual(Locale javaLocale, boolean extactMatch)
    {
        return isEqual(m_javaLocale, getJavaLocaleStr(javaLocale), extactMatch);
    }

    public String toString()
    {
        return m_description;
    }

    public int compareTo(Object o)
    {
        return m_description.compareTo(((InfranetLocaleData)o).toString());
    }

    public static String getJavaLocaleStr(Locale javaLocale)
    {
        String language = javaLocale.getLanguage();
        String country = javaLocale.getCountry();
        if(language != null && country != null)
            language = (new StringBuilder()).append(language).append("_").append(country).toString();
        return language;
    }

    private String m_infranetLocale;
    private String m_javaLocale;
    private int m_descriptionID;
    private String m_description;
    private String m_descriptionLocale;
}