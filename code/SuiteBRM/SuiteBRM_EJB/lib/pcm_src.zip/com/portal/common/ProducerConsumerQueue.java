// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ProducerConsumerQueue.java

package com.portal.common;

import java.util.LinkedList;

public class ProducerConsumerQueue
{

    public ProducerConsumerQueue()
    {
        mDeque = new LinkedList();
        mWaiters = 0;
    }

    public synchronized void addFirst(Object o)
    {
        mDeque.addFirst(o);
        if(mWaiters > 0)
            notify();
    }

    public synchronized void addPriority(Object o)
    {
        mDeque.addLast(o);
        if(mWaiters > 0)
            notify();
    }

    public synchronized Object removeLast()
    {
        while(mDeque.size() == 0) 
        {
            mWaiters++;
            try
            {
                wait();
            }
            catch(InterruptedException e) { }
            mWaiters--;
        }
        return mDeque.removeLast();
    }

    public synchronized Object removeLast(long maxTime)
    {
        for(; mDeque.size() == 0; mWaiters--)
        {
            mWaiters++;
            try
            {
                wait(maxTime);
                continue;
            }
            catch(InterruptedException e) { }
            if(mDeque.size() == 0)
            {
                mWaiters--;
                return null;
            }
        }

        return mDeque.removeLast();
    }

    public synchronized boolean hasWaiters()
    {
        return mWaiters > 0;
    }

    public int size()
    {
        return mDeque.size();
    }

    private LinkedList mDeque;
    private int mWaiters;
}