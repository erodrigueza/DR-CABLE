// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CurrencyRateManager.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Vector;

// Referenced classes of package com.portal.common:
//            InfranetCachedData, ExchangeRate, CurrencyRateException, BEIDManager

public class CurrencyRateManager extends InfranetCachedData
{
    private static class CRMInstanceBuilder extends InfranetCachedData.InstanceBuilder
    {

        public String getClassName()
        {
            return "com.portal.common.CurrencyRateManager";
        }

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return new CurrencyRateManager(connection);
        }

        private CRMInstanceBuilder()
        {
        }

    }

    private class SrcDestPair
    {

        int m_CurA;
        int m_CurB;
        Vector m_RateArray;
        final CurrencyRateManager this$0;

        public SrcDestPair(int currencyA, int currencyB, int intialRateArraySize)
        {
            this$0 = CurrencyRateManager.this;
            super();
            m_CurA = 0;
            m_CurB = 0;
            m_RateArray = null;
            m_CurA = currencyA;
            m_CurB = currencyB;
            m_RateArray = new Vector(intialRateArraySize);
        }
    }


    protected CurrencyRateManager(PortalContext connection)
    {
        super(connection);
        m_SrcDestTbl = null;
        m_SrcDestTbl = new Vector(50);
    }

    public static CurrencyRateManager getInstance(PortalContext connection)
    {
        return getInstance(connection, false);
    }

    public static CurrencyRateManager getInstance(PortalContext connection, boolean rebuild)
    {
        return (CurrencyRateManager)getInstanceImpl(connection, rebuild, m_instBuilder);
    }

    public BigDecimal convertCurrency(int srcCurrencyID, int destCurrencyID, Date transactionTime, BigDecimal amount)
        throws CurrencyRateException
    {
        ExchangeRate rate = lookupRate(srcCurrencyID, destCurrencyID, transactionTime);
        if(isTriangulationRequired(srcCurrencyID, destCurrencyID))
        {
            BigDecimal euroAmt = convertCurrency(srcCurrencyID, 978, transactionTime, amount);
            return convertCurrency(978, destCurrencyID, transactionTime, euroAmt);
        }
        boolean convertAtoB;
        int rateOp;
        if(srcCurrencyID == rate.m_CurrencyA.intValue())
        {
            convertAtoB = true;
            rateOp = rate.m_OperatorAtoB.intValue();
        } else
        {
            convertAtoB = false;
            if(rate.m_OperatorAtoB.intValue() == 0)
                rateOp = 1;
            else
                rateOp = 0;
        }
        BigDecimal rtnAmt = null;
        int scale = convertAtoB ? rate.m_RoundingB.intValue() : rate.m_RoundingA.intValue();
        int roundMode = convertAtoB ? rate.m_JavaRoundingModeB.intValue() : rate.m_JavaRoundingModeA.intValue();
        if(rateOp == 0)
        {
            rtnAmt = amount.multiply(rate.m_RateAtoB);
            rtnAmt = rtnAmt.setScale(scale, roundMode);
        } else
        {
            rtnAmt = amount.divide(rate.m_RateAtoB, scale, roundMode);
        }
        return rtnAmt;
    }

    protected boolean isTriangulationRequired(int srcCurrencyID, int destCurrencyID)
    {
        BEIDManager BEIDMan = BEIDManager.getInstance(m_Connection);
        return BEIDMan.isEMUCurrency(srcCurrencyID) && BEIDMan.isEMUCurrency(destCurrencyID);
    }

    public static boolean isTimeLT(Date testTime, Date baseTime)
    {
        return baseTime.getTime() == 0L || testTime.before(baseTime);
    }

    public static boolean isTimeLTE(Date testTime, Date baseTime)
    {
        return baseTime.getTime() == 0L || !testTime.after(baseTime);
    }

    public static boolean isTimeGT(Date testTime, Date baseTime)
    {
        return baseTime.getTime() != 0L && testTime.after(baseTime);
    }

    public static boolean isTimeGTE(Date testTime, Date baseTime)
    {
        return baseTime.getTime() != 0L && !testTime.before(baseTime);
    }

    public static boolean isTimeEQ(Date testTime, Date baseTime)
    {
        return testTime.equals(baseTime);
    }

    public static boolean isTimeWithinRange(Date testTime, Date startTime, Date endTime)
    {
        return isTimeLTE(testTime, endTime) && isTimeGTE(testTime, startTime);
    }

    protected ExchangeRate loadCurrencyRate(int srcCurrencyID, int destCurrencyID, Date transactionDate)
        throws CurrencyRateException
    {
        FList inFlist = new FList();
        FList curFlist = new FList();
        FList outFlist = null;
        ExchangeRate theRate = null;
        int errReason = 500;
        try
        {
            inFlist.set(FldPoid.getInst(), m_Connection.getUserID());
            curFlist.set(FldCurrencySrc.getInst(), srcCurrencyID);
            curFlist.set(FldCurrencyDst.getInst(), destCurrencyID);
            curFlist.set(FldEndT.getInst(), transactionDate);
            inFlist.setElement(FldCurrencies.getInst(), 0, curFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("CurrencyRateManager.loadCurrencyRate - Currency rate input Flist.\n").append(inFlist.toString()).toString());
            outFlist = m_Connection.opcode(99, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("CurrencyRateManager.loadCurrencyRate - Creency rate output FList:\n").append(outFlist.toString()).toString());
            errReason = 501;
            theRate = new ExchangeRate(outFlist, m_Connection);
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("CurrencyRateManager.loadCurrencyRate - Currency rate input Flist.\n").append(inFlist.toString()).toString());
                String tmp = outFlist != null ? outFlist.toString() : "<null flist>\n";
                DefaultLog.log(this, 2, (new StringBuilder()).append("CurrencyRateManager.loadCurrencyRate - Currency rate output FList:\n").append(tmp).toString());
            }
            throw new CurrencyRateException(srcCurrencyID, destCurrencyID, transactionDate, excptn, errReason);
        }
        return theRate;
    }

    protected ExchangeRate lookupRate(int srcCurrencyID, int destCurrencyID, Date transTime)
        throws CurrencyRateException
    {
        Vector rateArray = null;
        int index = 0;
        int numEntries = m_SrcDestTbl.size();
        do
        {
            if(index >= numEntries)
                break;
            SrcDestPair srcDestPair = (SrcDestPair)m_SrcDestTbl.elementAt(index);
            if(srcCurrencyID == srcDestPair.m_CurA && destCurrencyID == srcDestPair.m_CurB || srcCurrencyID == srcDestPair.m_CurB && destCurrencyID == srcDestPair.m_CurA)
            {
                rateArray = srcDestPair.m_RateArray;
                break;
            }
            index++;
        } while(true);
        ExchangeRate rate = null;
        if(rateArray != null)
        {
            int index = 0;
            for(int numRates = rateArray.size(); index < numRates; index++)
            {
                rate = (ExchangeRate)rateArray.elementAt(index);
                if(rate.isTimeWithinRange(transTime))
                    return rate;
            }

        } else
        {
            SrcDestPair srcDestPair = new SrcDestPair(srcCurrencyID, destCurrencyID, BEIDManager.getInstance(m_Connection).getNumEMUCurrencies());
            m_SrcDestTbl.addElement(srcDestPair);
            rateArray = srcDestPair.m_RateArray;
        }
        rate = loadCurrencyRate(srcCurrencyID, destCurrencyID, transTime);
        rateArray.addElement(rate);
        return rate;
    }

    public static final int CURRENCY_OPERATOR_MULTIPLY = 0;
    public static final int CURRENCY_OPERATOR_DIVIDE = 1;
    public static final int CURRENCY_OPERATOR_NONE = 2;
    public static final long TIME_NEVER = 0L;
    private Vector m_SrcDestTbl;
    private static CRMInstanceBuilder m_instBuilder = new CRMInstanceBuilder();

}