// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BEIDManager.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.math.BigDecimal;
import java.util.*;

// Referenced classes of package com.portal.common:
//            InfranetCachedData, BEIDData, CurrencyData, CurrencyRateException, 
//            CurrencyRateManager

public class BEIDManager extends InfranetCachedData
{
    private static class BMInstanceBuilder extends InfranetCachedData.InstanceBuilder
    {

        public String getClassName()
        {
            return "com.portal.common.BEIDManager";
        }

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return new BEIDManager(connection);
        }

        private BMInstanceBuilder()
        {
        }

    }


    protected BEIDManager(PortalContext connection)
    {
        super(connection);
        m_DataMap = null;
        m_CachedBEIDData = null;
        m_GotEMUCurrencies = false;
        m_CachedCurData = null;
        m_EMUCurrencies = null;
        m_SupportedEMUCurrencies = null;
        m_CurDataMap = null;
        m_Bundle = null;
        m_Connection = connection;
        m_Bundle = ResourceBundle.getBundle("com.portal.common.JavaCommonResources");
        m_DataMap = new Hashtable(20, 20F);
        m_EMUCurrencies = new Vector(20, 10);
        m_SupportedEMUCurrencies = new Vector(20, 10);
        m_CurDataMap = new Hashtable(20, 20F);
        readCreateBEIDDataObjects();
    }

    public static BEIDManager getInstance(PortalContext connection)
    {
        return getInstance(connection, false);
    }

    public static BEIDManager getInstance(PortalContext connection, boolean rebuild)
    {
        return (BEIDManager)getInstanceImpl(connection, rebuild, m_instBuilder);
    }

    public int getNumBEIDResources()
    {
        return m_DataMap.size();
    }

    public BEIDData getData(int resourceID)
    {
        return getData(new Integer(resourceID));
    }

    public BEIDData getData(Integer resourceID)
    {
        if(m_CachedBEIDData != null && resourceID.equals(m_CachedBEIDData.getResourceID()))
        {
            return m_CachedBEIDData;
        } else
        {
            m_CachedBEIDData = (BEIDData)m_DataMap.get(resourceID);
            return m_CachedBEIDData;
        }
    }

    public String getDescription(int resourceID)
    {
        BEIDData beidData = getData(resourceID);
        if(beidData == null)
            return new String();
        else
            return beidData.getDescription();
    }

    public String getSymbol(int resourceID)
    {
        BEIDData beidData = getData(resourceID);
        if(beidData == null)
            return new String();
        else
            return beidData.getSymbol();
    }

    public Enumeration getSupportedBEIDDataObjects()
    {
        return m_DataMap.elements();
    }

    public BEIDData[] getSupportedBEIDDataObjectsAsArray()
    {
        Enumeration beidEnum = m_DataMap.elements();
        BEIDData beidArray[] = new BEIDData[m_DataMap.size()];
        for(int index = 0; beidEnum.hasMoreElements(); index++)
            beidArray[index] = (BEIDData)beidEnum.nextElement();

        return beidArray;
    }

    public boolean isEMUCurrency(int currencyID)
    {
        loadEMUCurrenciesCheck();
        int index = 0;
        for(int numEMUCurs = m_EMUCurrencies.size(); index < numEMUCurs; index++)
        {
            Integer tmpID = (Integer)m_EMUCurrencies.elementAt(index);
            if(tmpID.intValue() == currencyID)
                return true;
        }

        return false;
    }

    public static boolean isEuro(int currencyID)
    {
        return currencyID == 978;
    }

    public static boolean isCurrency(int currencyID)
    {
        return currencyID >= 4 && currencyID <= 1000;
    }

    public static int BEIDRoundingModeToJavaRoudningMode(int beidRoundingMode)
    {
        int rtn;
        switch(beidRoundingMode)
        {
        case 1: // '\001'
            rtn = 0;
            break;

        case 2: // '\002'
            rtn = 1;
            break;

        case 3: // '\003'
            rtn = 6;
            break;

        case 0: // '\0'
        default:
            rtn = 4;
            break;
        }
        return rtn;
    }

    public int getNumEMUCurrencies()
    {
        loadEMUCurrenciesCheck();
        return m_EMUCurrencies.size();
    }

    public int getNumSupportedCurrencies()
    {
        return m_CurDataMap.size();
    }

    public int getNumSupportedEMUCurrencies()
    {
        loadEMUCurrenciesCheck();
        return m_SupportedEMUCurrencies.size();
    }

    public CurrencyData getCurrencyData(int currencyID)
    {
        return getCurrencyData(new Integer(currencyID));
    }

    public CurrencyData getCurrencyData(Integer currencyID)
    {
        if(m_CachedCurData != null && currencyID.equals(m_CachedCurData.getResourceID()))
        {
            return m_CachedCurData;
        } else
        {
            m_CachedCurData = (CurrencyData)m_CurDataMap.get(currencyID);
            return m_CachedCurData;
        }
    }

    public BigDecimal convertCurrency(int srcCurrencyID, int destCurrencyID, Date transactionTime, BigDecimal amount)
        throws CurrencyRateException
    {
        CurrencyRateManager rateMan = CurrencyRateManager.getInstance(m_Connection);
        return rateMan.convertCurrency(srcCurrencyID, destCurrencyID, transactionTime, amount);
    }

    public Enumeration getEMUCurrencyIDs()
    {
        loadEMUCurrenciesCheck();
        return m_EMUCurrencies.elements();
    }

    public Integer[] getEMUCurrencyIDsAsArray()
    {
        Integer idArray[] = new Integer[m_EMUCurrencies.size()];
        m_EMUCurrencies.copyInto(idArray);
        return idArray;
    }

    public Enumeration getSupportedCurrencyDataObjects()
    {
        return m_CurDataMap.elements();
    }

    public CurrencyData[] getSupportedCurrencyDataObjectsAsArray()
    {
        Enumeration curEnum = m_CurDataMap.elements();
        CurrencyData curArray[] = new CurrencyData[m_CurDataMap.size()];
        for(int index = 0; curEnum.hasMoreElements(); index++)
            curArray[index] = (CurrencyData)curEnum.nextElement();

        return curArray;
    }

    public Enumeration getSupportedEMUCurrencyDataObjects()
    {
        return m_SupportedEMUCurrencies.elements();
    }

    public CurrencyData[] getSupportedEMUCurrencyDataObjectsAsArray()
    {
        CurrencyData secArray[] = new CurrencyData[m_SupportedEMUCurrencies.size()];
        m_SupportedEMUCurrencies.copyInto(secArray);
        return secArray;
    }

    protected FList searchForConfigObject(Poid objPoid)
    {
        FList outFlist = new FList();
        FList inFlist = new FList();
        try
        {
            Poid searchPoid = new Poid(m_Connection.getCurrentDB(), 500L, "/search");
            inFlist.set(FldPoid.getInst(), searchPoid);
            FList argsFlist = new FList();
            argsFlist.set(FldPoid.getInst(), objPoid);
            inFlist.setElement(FldArgs.getInst(), 1, argsFlist);
            inFlist.setElement(FldResults.getInst(), -1);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("BEIDManager::searchForConfigObject - Search input Flist.\n").append(inFlist).toString());
            outFlist = m_Connection.opcode(7, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("BEIDManager::searchForConfigObject - Search output Flist.\n").append(outFlist).toString());
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("BEIDManager::searchForConfigObject - Search input Flist.\n").append(inFlist).toString());
                String tmp = outFlist != null ? outFlist.toString() : "<null flist>\n";
                DefaultLog.log(this, 2, (new StringBuilder()).append("BEIDManager::searchForConfigObject - Search output Flist.\n").append(tmp).toString());
            }
            return null;
        }
        return outFlist;
    }

    private synchronized boolean readCreateBEIDDataObjects()
    {
        FList outFlist = null;
        SparseArray resultsArray;
        FList theResult;
        SparseArray beidArray;
        Enumeration beidIterator;
        Integer resourceID;
        FList beidEntryFlist;
        String stringCode;
        String description;
        String symbol;
        Integer status;
        String statusDesc;
        Integer rounding;
        Integer roundingMode;
        BigDecimal toleranceAmountMin;
        BigDecimal toleranceAmountMax;
        BigDecimal tolerancePercent;
        SparseArray beidRulesArray;
        Integer javaRoundingMode;
        Enumeration envRules;
        BEIDData beidData;
        FList rule;
        boolean isEMUCur;
        CurrencyData curData;
        try
        {
            Poid objPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/config/beid");
            outFlist = searchForConfigObject(objPoid);
            if(outFlist == null)
            {
                if(DefaultLog.doLog(2))
                    DefaultLog.log(this, 2, "BEIDManager::readCreateCurrencyDataObjects - null FList returned!!");
                return false;
            }
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("BEIDManager::readCreateCurrencyDataObjects - EMU Currency search output Flist.\n").append(outFlist).toString());
            }
            m_DataMap.clear();
            m_CurDataMap.clear();
            m_SupportedEMUCurrencies.removeAllElements();
            cleanupAfterInfranetError();
            return false;
        }
        resultsArray = outFlist.get(FldResults.getInst());
        theResult = resultsArray.getAnyElement();
        if(theResult == null)
            throw new EBufException(30, outFlist);
        beidArray = theResult.get(FldBalances.getInst());
        beidIterator = beidArray.getKeyEnumerator();
        if(!beidIterator.hasMoreElements())
            throw new EBufException(30, outFlist);
_L9:
        if(!beidIterator.hasMoreElements()) goto _L2; else goto _L1
_L1:
        resourceID = (Integer)beidIterator.nextElement();
        beidEntryFlist = beidArray.elementAt(resourceID);
        stringCode = beidEntryFlist.get(FldBeidStrCode.getInst()).trim();
        description = beidEntryFlist.get(FldName.getInst()).trim();
        symbol = beidEntryFlist.get(FldSymbol.getInst()).trim();
        status = beidEntryFlist.get(FldStatus.getInst());
        statusDesc = getStatusAsString(status.intValue());
        rounding = null;
        roundingMode = null;
        toleranceAmountMin = null;
        toleranceAmountMax = null;
        tolerancePercent = null;
        if(!beidEntryFlist.hasField(FldRules.getInst())) goto _L4; else goto _L3
_L3:
        beidRulesArray = beidEntryFlist.get(FldRules.getInst());
        envRules = beidRulesArray.getValueEnumerator();
_L8:
        if(!envRules.hasMoreElements()) goto _L6; else goto _L5
_L5:
        rule = (FList)envRules.nextElement();
        if(rule.get(FldProcessingStage.getInst()).intValue() != 3 || !rule.get(FldEventType.getInst()).equalsIgnoreCase("*")) goto _L8; else goto _L7
_L7:
        rounding = rule.get(FldRounding.getInst());
        roundingMode = rule.get(FldRoundingMode.getInst());
        toleranceAmountMin = rule.get(FldToleranceAmountMin.getInst());
        toleranceAmountMax = rule.get(FldToleranceAmountMax.getInst());
        tolerancePercent = rule.get(FldTolerancePercent.getInst());
          goto _L6
_L4:
        rounding = beidEntryFlist.get(FldRounding.getInst());
        roundingMode = beidEntryFlist.get(FldRoundingMode.getInst());
        toleranceAmountMin = beidEntryFlist.get(FldToleranceAmountMin.getInst());
        toleranceAmountMax = beidEntryFlist.get(FldToleranceAmountMax.getInst());
        tolerancePercent = beidEntryFlist.get(FldTolerancePercent.getInst());
_L6:
        javaRoundingMode = new Integer(BEIDRoundingModeToJavaRoudningMode(roundingMode.intValue()));
        beidData = null;
        if(BEIDData.isBEIDCurrencyResource(resourceID.intValue()))
        {
            isEMUCur = isEMUCurrency(resourceID.intValue());
            curData = new CurrencyData(resourceID, stringCode, description, symbol, status, statusDesc, rounding, roundingMode, javaRoundingMode, toleranceAmountMin, toleranceAmountMax, tolerancePercent, isEMUCur, isEuro(resourceID.intValue()));
            m_CurDataMap.put(resourceID, curData);
            beidData = curData;
            if(isEMUCur)
                m_SupportedEMUCurrencies.addElement(curData);
        } else
        {
            beidData = new BEIDData(resourceID, stringCode, description, symbol, status, statusDesc, rounding, roundingMode, javaRoundingMode, toleranceAmountMin, toleranceAmountMax, tolerancePercent);
        }
        m_DataMap.put(resourceID, beidData);
          goto _L9
_L2:
        readSecondaryCurrencies();
        return true;
    }

    private synchronized boolean readEMUCurrencyList()
    {
        FList outFlist = null;
        SparseArray resultsArray;
        FList theResult;
        SparseArray emuArray;
        Enumeration emuIterator;
        FList emuFlist;
        Integer cur;
        try
        {
            Poid objPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/config/currency/emu");
            outFlist = searchForConfigObject(objPoid);
            if(outFlist == null)
                return false;
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("CurrencyManager::ReadEMUCurrencyList - EMU Currency search output Flist.\n").append(outFlist).toString());
            }
            m_EMUCurrencies.removeAllElements();
            cleanupAfterInfranetError();
            return false;
        }
        resultsArray = outFlist.get(FldResults.getInst());
        theResult = resultsArray.getAnyElement();
        if(theResult == null)
            throw new EBufException(30, outFlist);
        emuArray = theResult.get(FldCurrencyEmuMembers.getInst());
        for(emuIterator = emuArray.getValueEnumerator(); emuIterator.hasMoreElements(); m_EMUCurrencies.addElement(cur))
        {
            emuFlist = (FList)emuIterator.nextElement();
            cur = emuFlist.get(FldCurrency.getInst());
        }

        return true;
    }

    private synchronized boolean readSecondaryCurrencies()
    {
        if(!loadEMUCurrenciesCheck())
        {
            cleanupAfterInfranetError();
            return false;
        }
        FList outFlist = null;
        SparseArray resultsArray;
        FList theResult;
        SparseArray supCombArray;
        Enumeration supCombIterator;
        FList supCombFlist;
        Integer primCurID;
        boolean requiredFlag;
        CurrencyData curData;
        SparseArray secondaryCurArray;
        Enumeration secondaryCurIterator;
        FList secondaryCurFlist;
        Integer secondaryCurID;
        CurrencyData secData;
        try
        {
            Poid objPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/config/currency/supportedcombinations");
            outFlist = searchForConfigObject(objPoid);
            if(outFlist == null)
                return false;
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("CurrencyManager::readSecondaryCurrencies - Supported Combinations output Flist.\n").append(outFlist).toString());
            }
            cleanupAfterInfranetError();
            return false;
        }
        resultsArray = outFlist.get(FldResults.getInst());
        theResult = resultsArray.getAnyElement();
        if(theResult == null)
            throw new EBufException(30, outFlist);
        supCombArray = theResult.get(FldCurSupportedComb.getInst());
        supCombIterator = supCombArray.getValueEnumerator();
        do
        {
            if(!supCombIterator.hasMoreElements())
                break;
            supCombFlist = (FList)supCombIterator.nextElement();
            primCurID = supCombFlist.get(FldCurrency.getInst());
            requiredFlag = supCombFlist.get(FldCurSecondaryReq.getInst()).intValue() != 0;
            curData = getCurrencyData(primCurID);
            if(curData == null)
                throw new EBufException(30, outFlist);
            curData.m_IsSecondaryCurrencyRequired = requiredFlag;
            if(requiredFlag || supCombFlist.hasField(FldCurSupportedSecCur.getInst()))
            {
                secondaryCurArray = supCombFlist.get(FldCurSupportedSecCur.getInst());
                secondaryCurIterator = secondaryCurArray.getValueEnumerator();
                while(secondaryCurIterator.hasMoreElements()) 
                {
                    secondaryCurFlist = (FList)secondaryCurIterator.nextElement();
                    secondaryCurID = secondaryCurFlist.get(FldCurrencySecondary.getInst());
                    secData = getCurrencyData(secondaryCurID);
                    if(secData == null)
                        throw new EBufException(30, outFlist);
                    curData.m_SecondaryCurrencies.addElement(secData);
                }
            }
        } while(true);
        return true;
    }

    private synchronized boolean loadEMUCurrenciesCheck()
    {
        boolean rtn = true;
        if(!m_GotEMUCurrencies)
        {
            rtn = readEMUCurrencyList();
            m_GotEMUCurrencies = true;
        }
        return rtn;
    }

    private void cleanupAfterInfranetError()
    {
        m_GotEMUCurrencies = true;
    }

    private String getStatusAsString(int status)
    {
        String str = null;
        switch(status)
        {
        case 0: // '\0'
            str = m_Bundle.getString("curclass.beid.status.not.set");
            break;

        case 1: // '\001'
            str = m_Bundle.getString("curclass.beid.status.active");
            break;

        case 2: // '\002'
            str = m_Bundle.getString("curclass.beid.status.inactive");
            break;

        default:
            str = m_Bundle.getString("curclass.beid.status.undefined");
            break;
        }
        return str;
    }

    public static final String PIN_STR_BEID_POID_TYPE = "/config/beid";
    public static final String PIN_STR_SEARCH_POID_TYPE = "/config/currency/supportedcombinations";
    public static final String PIN_STR_EMU_CURRENCY_POID_TYPE = "/config/currency/emu";
    private Hashtable m_DataMap;
    private BEIDData m_CachedBEIDData;
    private boolean m_GotEMUCurrencies;
    private CurrencyData m_CachedCurData;
    private Vector m_EMUCurrencies;
    private Vector m_SupportedEMUCurrencies;
    private Hashtable m_CurDataMap;
    private ResourceBundle m_Bundle;
    private static BMInstanceBuilder m_instBuilder = new BMInstanceBuilder();

}