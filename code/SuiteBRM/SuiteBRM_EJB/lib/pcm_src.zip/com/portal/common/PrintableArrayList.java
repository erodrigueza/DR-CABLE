// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrintableArrayList.java

package com.portal.common;

import java.awt.*;
import java.awt.print.*;
import java.util.ArrayList;
import java.util.Collection;
import javax.swing.UIManager;

// Referenced classes of package com.portal.common:
//            HFPageFormat, PrintManager

public class PrintableArrayList extends ArrayList
    implements Printable
{

    public PrintableArrayList()
    {
        mPageHeader = null;
        mDescList = null;
    }

    public PrintableArrayList(Collection c)
    {
        super(c);
        mPageHeader = null;
        mDescList = null;
    }

    public PrintableArrayList(int initialCapacity)
    {
        super(initialCapacity);
        mPageHeader = null;
        mDescList = null;
    }

    public int print(Graphics g, PageFormat pf, int pageIndex)
        throws PrinterException
    {
        int returnValue = 1;
        if(size() == 0)
            return returnValue;
        Graphics2D g2 = (Graphics2D)g.create();
        if(pf instanceof HFPageFormat)
        {
            HFPageFormat hfpf = (HFPageFormat)pf;
            hfpf.setLeftHeaderText(getPageHeader());
            hfpf.setLeftFooterText(PrintManager.getDateAndTime());
            hfpf.setRightFooterText(Integer.toString(pageIndex + 1));
            if(pageIndex == 0)
                hfpf.setDescArray(getDesc());
            else
                hfpf.setDescArray(null);
            hfpf.print(g2, pf, pageIndex);
        }
        int pageHeight = (int)pf.getImageableHeight();
        g2.translate(pf.getImageableX(), pf.getImageableY());
        g2.setClip(0, 0, (int)pf.getImageableWidth(), pageHeight);
        g2.setFont(getFont());
        FontMetrics fm = g2.getFontMetrics();
        int maxLineHeight = fm.getMaxAscent() + fm.getMaxDescent() + LINE_SPACING;
        int linePerPage = (int)Math.floor(pageHeight / maxLineHeight);
        int totalLineCount = size();
        int lastLineIndex = totalLineCount - 1;
        int pageFirstLineIndex = linePerPage * pageIndex;
        int lineCount = 0;
        for(int i = pageFirstLineIndex; i <= lastLineIndex && lineCount < linePerPage; i++)
            g2.drawString(get(i).toString(), 0, lineCount++ * maxLineHeight + fm.getMaxAscent());

        if(pageFirstLineIndex <= lastLineIndex)
            returnValue = 0;
        g2.dispose();
        return returnValue;
    }

    public void setPageHeader(String header)
    {
        mPageHeader = header;
    }

    public String getPageHeader()
    {
        return mPageHeader;
    }

    public void setDesc(ArrayList al)
    {
        mDescList = al;
    }

    public ArrayList getDesc()
    {
        return mDescList;
    }

    public void setFont(Font font)
    {
        mFont = font;
    }

    public Font getFont()
    {
        return mFont;
    }

    private String mPageHeader;
    private ArrayList mDescList;
    private static Font mFont = UIManager.getFont("TextArea.font");
    private static int LINE_SPACING = 0;

}