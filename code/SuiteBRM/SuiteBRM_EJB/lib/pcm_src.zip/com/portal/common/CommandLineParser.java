// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CommandLineParser.java

package com.portal.common;

import java.text.MessageFormat;
import java.util.*;

public class CommandLineParser
{
    public class OptionDataException extends OptionException
    {

        final CommandLineParser this$0;

        public OptionDataException(String option, String msg)
        {
            this$0 = CommandLineParser.this;
            super(option, msg);
        }
    }

    public class ValueOutOfBoundsException extends OptionException
    {

        final CommandLineParser this$0;

        public ValueOutOfBoundsException(String msg)
        {
            this$0 = CommandLineParser.this;
            super(msg);
        }

        public ValueOutOfBoundsException(String option, String msg)
        {
            this$0 = CommandLineParser.this;
            super(option, msg);
        }
    }

    public class NoSuchOptionException extends OptionException
    {

        final CommandLineParser this$0;

        public NoSuchOptionException(String option, String msg)
        {
            this$0 = CommandLineParser.this;
            super(option, msg);
        }
    }

    public abstract class OptionException extends Exception
    {

        public String getOption()
        {
            return mOptName;
        }

        private String mOptName;
        final CommandLineParser this$0;

        protected OptionException(String msg)
        {
            this$0 = CommandLineParser.this;
            super(msg);
            mOptName = null;
        }

        protected OptionException(String option, String msg)
        {
            this$0 = CommandLineParser.this;
            super(msg);
            mOptName = null;
            mOptName = option;
        }

        private OptionException()
        {
            this$0 = CommandLineParser.this;
            super();
            mOptName = null;
        }
    }

    public class InvalidOptionsException extends Exception
    {

        public String[] getArgs()
        {
            return mArgs;
        }

        public String getHelp()
        {
            return mHelpText;
        }

        private String mHelpText;
        private String mArgs[];
        final CommandLineParser this$0;

        public InvalidOptionsException(CommandLineParser parser, String msg)
        {
            this$0 = CommandLineParser.this;
            super(msg);
            mHelpText = null;
            mArgs = null;
            mArgs = parser.getArgs();
            mHelpText = parser.getHelp();
        }

        private InvalidOptionsException()
        {
            this$0 = CommandLineParser.this;
            super();
            mHelpText = null;
            mArgs = null;
        }
    }


    public static CommandLineParser createParser(String args[])
        throws InvalidOptionsException
    {
        return new CommandLineParser(args, null);
    }

    protected CommandLineParser(String args[])
        throws InvalidOptionsException
    {
        mOptionMap = new HashMap(5);
        mLeadingTokens = new String[0];
        mTrailingTokens = new String[0];
        mArgs = null;
        mBundle = null;
        mArgs = args;
        mBundle = ResourceBundle.getBundle("com.portal.common.JavaCommonResources");
    }

    private CommandLineParser(String args[], Object notUsed)
        throws InvalidOptionsException
    {
        this(args);
        parse();
    }

    public String[] getArgs()
    {
        return mArgs;
    }

    public boolean containsOption(String option)
    {
        return mOptionMap.containsKey(option);
    }

    public int getNumValues(String option)
        throws NoSuchOptionException
    {
        return getValues(option).length;
    }

    public String[] getValues(String option)
        throws NoSuchOptionException
    {
        String optName = option.toLowerCase();
        String values[] = (String[])(String[])mOptionMap.get(optName);
        if(values == null)
        {
            Object args[] = {
                option
            };
            throw new NoSuchOptionException(option, constructErrMsg("clp.format_msg.option_not_found", args));
        } else
        {
            return values;
        }
    }

    public String[] getValues(String option, int numValues)
        throws NoSuchOptionException, ValueOutOfBoundsException
    {
        String values[] = getValues(option);
        int totalValues = values.length;
        if(numValues == -1 || numValues == totalValues)
            return values;
        if(numValues < 0 || numValues > totalValues)
        {
            Object args[] = {
                option, new Integer(totalValues), new Integer(numValues)
            };
            throw new ValueOutOfBoundsException(option, constructErrMsg("clp.format_msg.values_out_of_range", args));
        }
        String rtnValues[] = new String[numValues];
        for(int i = 0; i < numValues; i++)
            rtnValues[i] = values[i];

        return rtnValues;
    }

    public String getValue(String option)
        throws NoSuchOptionException, ValueOutOfBoundsException
    {
        return getValues(option, 1)[0];
    }

    public int getNumLeadingTokens()
    {
        return mLeadingTokens.length;
    }

    public String[] getLeadingTokens()
    {
        return mLeadingTokens;
    }

    public String getLeadingToken(int index)
        throws ValueOutOfBoundsException
    {
        if(index < 0 || index >= mLeadingTokens.length)
        {
            Object args[] = {
                new Integer(index)
            };
            throw new ValueOutOfBoundsException(constructErrMsg("clp.format_msg.leading_token_out_of_range", args));
        } else
        {
            return mLeadingTokens[index];
        }
    }

    public int getNumTrailingTokens()
    {
        return mTrailingTokens.length;
    }

    public int getNumOptions()
    {
        return mOptionMap.size();
    }

    public String[] getTrailingTokens()
    {
        return mTrailingTokens;
    }

    public String getTrailingToken(int index)
        throws ValueOutOfBoundsException
    {
        if(index < 0 || index >= mTrailingTokens.length)
        {
            Object args[] = {
                new Integer(index)
            };
            throw new ValueOutOfBoundsException(constructErrMsg("clp.format_msg.trailing_token_out_of_range", args));
        } else
        {
            return mTrailingTokens[index];
        }
    }

    public String toString()
    {
        StringBuffer sb = new StringBuffer(30);
        sb.append(getStrFromBundle("clp.misc.leading_tokens"));
        sb.append(strArrayToString(mLeadingTokens));
        sb.append("\r\n ");
        sb.append(getStrFromBundle("clp.misc.flags_and_values"));
        for(Iterator itr = mOptionMap.entrySet().iterator(); itr.hasNext();)
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)itr.next();
            String sa[] = (String[])(String[])entry.getValue();
            sb.append("\r\n  ");
            sb.append((String)entry.getKey());
            sb.append(": ");
            int i = 0;
            int len = sa.length;
            while(i < len) 
            {
                sb.append(sa[i]);
                if(i + 1 < len)
                    sb.append(", ");
                i++;
            }
        }

        sb.append("\r\n ");
        sb.append(getStrFromBundle("clp.misc.trailing_tokens"));
        sb.append(strArrayToString(mLeadingTokens));
        return sb.toString();
    }

    public boolean isHelp()
    {
        return false;
    }

    public String getHelp()
    {
        return new String("");
    }

    public static String strArrayToString(String sa[])
    {
        StringBuffer str = new StringBuffer(100);
        int i = 0;
        for(int len = sa.length; i < len; i++)
        {
            if(i > 0)
                str.append(", ");
            str.append("'");
            str.append(sa[i]);
            str.append("'");
        }

        return str.toString();
    }

    protected void validateLeadingTokens(ArrayList arraylist)
        throws InvalidOptionsException
    {
    }

    protected void validateOption(String s, ArrayList arraylist, boolean flag)
        throws InvalidOptionsException
    {
    }

    protected void validateTrailingTokens(ArrayList arraylist, int i)
        throws InvalidOptionsException
    {
    }

    protected void validateRequiredParameters()
        throws InvalidOptionsException
    {
    }

    protected boolean storeAllTokensAsLeadingTokens()
    {
        return true;
    }

    protected void postParse()
        throws InvalidOptionsException
    {
    }

    protected final void parse()
        throws InvalidOptionsException
    {
        boolean foundLeadingTokens = false;
        ArrayList values = new ArrayList(5);
        int numLastOptionArgs = 0;
        int i = 0;
        int numArgs = mArgs.length;
        do
        {
            if(i >= numArgs)
                break;
            String curArg = mArgs[i];
            boolean isOption = curArg.startsWith("-");
            if(isOption)
                i++;
            values.clear();
            do
            {
                if(i >= numArgs)
                    break;
                String arg = mArgs[i];
                if(arg.startsWith("-"))
                    break;
                values.add(arg);
                i++;
            } while(true);
            boolean isLastOption = i == numArgs;
            if(!foundLeadingTokens)
            {
                ArrayList leadingTokens = !isOption && (!isLastOption || storeAllTokensAsLeadingTokens()) ? values : new ArrayList(0);
                validateLeadingTokens(leadingTokens);
                mLeadingTokens = buildStrArray(leadingTokens);
                foundLeadingTokens = true;
            }
            if(isOption)
            {
                String optName = curArg.toLowerCase();
                if(mOptionMap.containsKey(optName))
                {
                    Object args[] = {
                        curArg
                    };
                    throw new InvalidOptionsException(this, constructErrMsg("clp.format_msg.duplicate_option", args));
                }
                ArrayList optValues = isLastOption ? new ArrayList(values) : values;
                validateOption(curArg, optValues, isLastOption);
                if(isLastOption)
                    numLastOptionArgs = optValues.size();
                mOptionMap.put(optName, buildStrArray(optValues));
            }
            if(isLastOption)
            {
                ArrayList trailingTokens = !isOption && storeAllTokensAsLeadingTokens() ? new ArrayList(0) : values;
                validateTrailingTokens(trailingTokens, numLastOptionArgs);
                mTrailingTokens = buildStrArray(trailingTokens);
            }
        } while(true);
        validateRequiredParameters();
        postParse();
    }

    protected final String getStrFromBundle(String key)
    {
        return getStrFromBundle(mBundle, key);
    }

    protected final String getStrFromBundle(ResourceBundle bundle, String key)
    {
        String str = null;
        try
        {
            str = mBundle.getString(key);
        }
        catch(MissingResourceException e)
        {
            StringBuffer sb = new StringBuffer(30);
            sb.append("<Cannot find string for '");
            sb.append(key);
            sb.append("'>");
            str = sb.toString();
        }
        return str;
    }

    protected final String constructErrMsg(String errFormatKey, Object msgArgs[])
    {
        return constructErrMsg(mBundle, errFormatKey, msgArgs);
    }

    protected final String constructErrMsg(ResourceBundle bundle, String errFormatKey, Object msgArgs[])
    {
        String msg = null;
        try
        {
            String formatMsg = mBundle.getString(errFormatKey);
            msg = MessageFormat.format(formatMsg, msgArgs);
        }
        catch(MissingResourceException e)
        {
            StringBuffer sb = new StringBuffer(30);
            sb.append("<Cannot find error message for'");
            sb.append(errFormatKey);
            sb.append("'>");
            msg = sb.toString();
        }
        return msg;
    }

    private String[] buildStrArray(ArrayList list)
    {
        String sa[] = new String[list.size()];
        int i = 0;
        for(int len = sa.length; i < len; i++)
            sa[i] = (String)list.get(i);

        return sa;
    }

    public static final int ALL = -1;
    private HashMap mOptionMap;
    private String mLeadingTokens[];
    private String mTrailingTokens[];
    private String mArgs[];
    private ResourceBundle mBundle;
}