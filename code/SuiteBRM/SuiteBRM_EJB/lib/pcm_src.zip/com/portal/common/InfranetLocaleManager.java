// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   InfranetLocaleManager.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.io.Serializable;
import java.util.*;

// Referenced classes of package com.portal.common:
//            InfranetCachedData, InfranetLocaleData

public class InfranetLocaleManager extends InfranetCachedData
{
    private class InternalLocaleData
        implements Serializable
    {

        String getInfranetLocale()
        {
            return m_infranetLocale;
        }

        String getJavaLocale()
        {
            return m_javaLocale;
        }

        Integer getLocaleDescriptionID()
        {
            return m_descriptionID;
        }

        private String m_infranetLocale;
        private String m_javaLocale;
        private Integer m_descriptionID;
        final InfranetLocaleManager this$0;

        InternalLocaleData(String infranetLocale, String javaLocale, Integer descriptionID)
        {
            this$0 = InfranetLocaleManager.this;
            super();
            m_infranetLocale = null;
            m_javaLocale = null;
            m_descriptionID = null;
            m_infranetLocale = infranetLocale;
            m_javaLocale = javaLocale;
            m_descriptionID = descriptionID;
        }
    }

    private static class ILMInstanceBuilder extends InfranetCachedData.InstanceBuilder
    {

        public String getClassName()
        {
            return "com.portal.common.InfranetLocaleManager";
        }

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return new InfranetLocaleManager(connection);
        }

        private ILMInstanceBuilder()
        {
        }

    }


    protected InfranetLocaleManager(PortalContext connection)
    {
        super(connection);
        m_LocDataMap = null;
        m_JavaMap = null;
        m_LocaleMsgIdMap = null;
        m_DisplayLocales = null;
        BuildHashTable();
    }

    public static InfranetLocaleManager getInstance(PortalContext connection)
    {
        return getInstance(connection, false);
    }

    public static InfranetLocaleManager getInstance(PortalContext connection, boolean rebuild)
    {
        return (InfranetLocaleManager)getInstanceImpl(connection, rebuild, m_instBuilder);
    }

    public Enumeration getLocales(String infranetTextLocale, int matchType)
    {
        if(infranetTextLocale == null)
            infranetTextLocale = "en_US";
        String displayLocale = getLocaleThatMatches(infranetTextLocale, matchType);
        if(displayLocale == null)
            return null;
        Enumeration dataEnum = m_LocDataMap.elements();
        Vector dataVect = new Vector(getNumLocales());
        do
        {
            if(!dataEnum.hasMoreElements())
                break;
            InternalLocaleData internalData = (InternalLocaleData)dataEnum.nextElement();
            InfranetLocaleData data = buildLocaleData(internalData, displayLocale);
            if(data != null)
                dataVect.addElement(data);
        } while(true);
        return dataVect.elements();
    }

    public Enumeration getLocales(Locale javaLocale, int matchType)
    {
        if(javaLocale == null)
        {
            return null;
        } else
        {
            String javaLocStr = InfranetLocaleData.getJavaLocaleStr(javaLocale);
            return getLocales(MapJavaLocaleToInfranetLocale(javaLocStr), matchType);
        }
    }

    public InfranetLocaleData[] getLocalesAsArray(String infranetTextLocale, int matchType)
    {
        Enumeration locEnum = getLocales(infranetTextLocale, matchType);
        if(locEnum == null)
            return null;
        InfranetLocaleData locs[] = new InfranetLocaleData[getNumLocales()];
        for(int index = 0; locEnum.hasMoreElements(); index++)
        {
            InfranetLocaleData locData = (InfranetLocaleData)locEnum.nextElement();
            locs[index] = locData;
        }

        return locs;
    }

    public InfranetLocaleData[] getLocalesAsArray(Locale javaLocale, int matchType)
    {
        if(javaLocale == null)
        {
            return null;
        } else
        {
            String javaLocStr = InfranetLocaleData.getJavaLocaleStr(javaLocale);
            return getLocalesAsArray(MapJavaLocaleToInfranetLocale(javaLocStr), matchType);
        }
    }

    public InfranetLocaleData getLocaleData(String infranetLocale, String infranetTextLocale, int matchType)
    {
        if(infranetLocale == null || infranetTextLocale == null)
            return null;
        InternalLocaleData locData = (InternalLocaleData)m_LocDataMap.get(infranetLocale.toLowerCase());
        if(locData == null)
            return null;
        String displayLocale = getLocaleThatMatches(infranetTextLocale, matchType);
        if(displayLocale == null)
            return null;
        else
            return buildLocaleData(locData, displayLocale);
    }

    public InfranetLocaleData getLocaleData(String infranetLocale, Locale javaTextLocale, int matchType)
    {
        if(infranetLocale == null || javaTextLocale == null)
        {
            return null;
        } else
        {
            String javaLocStr = InfranetLocaleData.getJavaLocaleStr(javaTextLocale);
            return getLocaleData(infranetLocale, MapJavaLocaleToInfranetLocale(javaLocStr), matchType);
        }
    }

    public int getNumLocales()
    {
        return m_LocDataMap.size();
    }

    public String MapJavaLocaleToInfranetLocale(String javaLocale)
    {
        if(javaLocale == null)
            return null;
        String infranetLocale = null;
        InternalLocaleData locData = (InternalLocaleData)m_JavaMap.get(javaLocale.toLowerCase());
        if(locData != null)
            infranetLocale = locData.getInfranetLocale();
        return infranetLocale;
    }

    public String MapInfranetLocaleToJavaLocale(String infranetLocale)
    {
        if(infranetLocale == null)
            return null;
        String javaLocale = null;
        InternalLocaleData locData = (InternalLocaleData)m_LocDataMap.get(infranetLocale.toLowerCase());
        if(locData != null)
            javaLocale = locData.getJavaLocale();
        return javaLocale;
    }

    private String getLocaleThatMatches(String infranetTextLocale, int matchType)
    {
label0:
        {
            if(matchType == 0 || matchType == 2)
            {
                String rtnLocale = (String)m_DisplayLocales.get(infranetTextLocale.toLowerCase());
                if(rtnLocale != null)
                    return rtnLocale;
            }
            if(matchType != 1 && matchType != 2)
                break label0;
            Enumeration locales = m_DisplayLocales.elements();
            String rtnLocale;
            do
            {
                if(!locales.hasMoreElements())
                    break label0;
                rtnLocale = (String)locales.nextElement();
            } while(!InfranetLocaleData.isEqual(rtnLocale, infranetTextLocale, false));
            return rtnLocale;
        }
        return "en_US";
    }

    private boolean readLocaleNameDescriptions()
    {
        boolean rtn = true;
        m_LocaleMsgIdMap = new Hashtable(20, 20F);
        m_DisplayLocales = new Hashtable(20, 20F);
        FList inFlist = new FList();
        FList outFlist = new FList();
        try
        {
            Poid searchPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/search");
            inFlist.set(FldPoid.getInst(), searchPoid);
            inFlist.set(FldFlags.getInst(), 256);
            inFlist.set(FldTemplate.getInst(), "select X from /strings where F1 like V1 ");
            FList arg1Flist = new FList();
            arg1Flist.set(FldDomain.getInst(), "Locale Descriptions%");
            inFlist.setElement(FldArgs.getInst(), 1, arg1Flist);
            inFlist.setElement(FldResults.getInst(), -1);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("InfranetLocaleManager::readLocaleNameDescriptions - Search input Flist.\n").append(inFlist.toString()).toString());
            outFlist = m_Connection.opcode(7, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("InfranetLocaleManager::readLocaleNameDescriptions - Search output Flist.\n").append(outFlist.toString()).toString());
            SparseArray resultsArray = outFlist.get(FldResults.getInst());
            String infranetLocale;
            for(Enumeration resultsIterator = resultsArray.getValueEnumerator(); resultsIterator.hasMoreElements(); m_DisplayLocales.put(infranetLocale.toLowerCase(), infranetLocale))
            {
                FList strFList = (FList)resultsIterator.nextElement();
                String localeDescription = strFList.get(FldString.getInst());
                Integer msgID = strFList.get(FldStringId.getInst());
                infranetLocale = strFList.get(FldLocale.getInst());
                String localeIDKey = (new StringBuilder()).append(infranetLocale.toLowerCase()).append(":").append(msgID.toString()).toString();
                m_LocaleMsgIdMap.put(localeIDKey, localeDescription);
            }

        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("InfranetLocaleManager::readLocaleNameDescriptions - Search input Flist.\n").append(inFlist.toString()).toString());
                String tmp = outFlist != null ? outFlist.toString() : "<null flist>\n";
                DefaultLog.log(this, 2, (new StringBuilder()).append("InfranetLocaleManager::readLocaleNameDescriptions - Search output Flist.\n").append(tmp).toString());
            }
            rtn = false;
        }
        return rtn;
    }

    private void BuildHashTable()
    {
        readLocaleNameDescriptions();
        m_LocDataMap = new Hashtable(20, 20F);
        m_JavaMap = new Hashtable(20, 20F);
        ResourceBundle bundle = null;
        try
        {
            bundle = ResourceBundle.getBundle("com.portal.common.JavaCommon");
        }
        catch(MissingResourceException exception)
        {
            return;
        }
        try
        {
            int index = 0;
            do
            {
                String baseKey = (new StringBuilder()).append("curclass.ilm").append((new Integer(index)).toString()).toString();
                Integer descriptionID = new Integer(bundle.getString((new StringBuilder()).append(baseKey).append(".desc_id").toString()));
                String infranetLocale = bundle.getString((new StringBuilder()).append(baseKey).append(".infranet_locale").toString());
                String javaLocale = bundle.getString((new StringBuilder()).append(baseKey).append(".java_locale").toString());
                String descrLocale = bundle.getString((new StringBuilder()).append(baseKey).append(".desc_locale").toString());
                String localeIDKey = (new StringBuilder()).append(descrLocale.toLowerCase()).append(":").append(descriptionID.toString()).toString();
                if(m_LocaleMsgIdMap.get(localeIDKey) == null)
                {
                    String localeDescription = bundle.getString((new StringBuilder()).append(baseKey).append(".desc_text").toString());
                    m_LocaleMsgIdMap.put(localeIDKey, localeDescription);
                }
                m_DisplayLocales.put(descrLocale.toLowerCase(), descrLocale);
                InternalLocaleData locData = new InternalLocaleData(infranetLocale, javaLocale, descriptionID);
                m_LocDataMap.put(infranetLocale.toLowerCase(), locData);
                m_JavaMap.put(javaLocale.toLowerCase(), locData);
                index++;
            } while(true);
        }
        catch(MissingResourceException exception)
        {
            return;
        }
    }

    private InfranetLocaleData buildLocaleData(InternalLocaleData internalData, String displayLocale)
    {
        String infranetLocale = internalData.getInfranetLocale();
        Integer msgID = internalData.getLocaleDescriptionID();
        String msgKey = (new StringBuilder()).append(displayLocale.toLowerCase()).append(":").append(msgID.toString()).toString();
        String description = (String)m_LocaleMsgIdMap.get(msgKey);
        if(description == null)
            description = (new StringBuilder()).append(infranetLocale).append(":").append("<no description>").toString();
        InfranetLocaleData data = new InfranetLocaleData(infranetLocale, internalData.getJavaLocale(), msgID.intValue(), description, displayLocale);
        return data;
    }

    public static final int LocaleExactMatch = 0;
    public static final int LocaleLangMatch = 1;
    public static final int LocaleExactMatchThenLangMatch = 2;
    private Hashtable m_LocDataMap;
    private Hashtable m_JavaMap;
    private Hashtable m_LocaleMsgIdMap;
    private Hashtable m_DisplayLocales;
    private static ILMInstanceBuilder m_instBuilder = new ILMInstanceBuilder();

}