// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   DevicePermitMapConfigParser.java

package com.portal.common;

import com.portal.pcm.FList;
import com.portal.pcm.SparseArray;
import com.portal.pcm.fields.*;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;

// Referenced classes of package com.portal.common:
//            FileParser, LoaderOptions, ConfigLog

public class DevicePermitMapConfigParser extends FileParser
{
    private class DuplicateEntryException extends Exception
    {

        final DevicePermitMapConfigParser this$0;

        public DuplicateEntryException(String sMessage)
        {
            this$0 = DevicePermitMapConfigParser.this;
            super(sMessage);
        }
    }

    private class Device
    {

        public String getDeviceType()
        {
            return mDeviceType;
        }

        public void addService(String sService)
            throws DuplicateEntryException
        {
            for(int i = 0; i < mServicesVector.size(); i++)
            {
                String service = (String)mServicesVector.elementAt(i);
                if(service.equals(sService))
                    throw new DuplicateEntryException((new StringBuilder()).append("Duplicate service: ").append(sService).append(" found for device: ").append(getDeviceType()).toString());
            }

            mServicesVector.addElement(sService);
        }

        public Vector getServices()
        {
            return mServicesVector;
        }

        private String mDeviceType;
        private Vector mServicesVector;
        final DevicePermitMapConfigParser this$0;

        public Device(String sDeviceType)
        {
            this$0 = DevicePermitMapConfigParser.this;
            super();
            mServicesVector = new Vector();
            mDeviceType = sDeviceType;
        }
    }


    public DevicePermitMapConfigParser(LoaderOptions options)
    {
        mLineNum = 1;
        mFileName = options.getFileName();
    }

    public FList parseFile()
    {
        Vector vDeviceList = parseFileVector();
        return getFList(vDeviceList);
    }

    private FList getFList(Vector vDevices)
    {
        if(vDevices.size() <= 0)
        {
            ConfigLog.log("No Devices found in the configuration file");
            return null;
        }
        FList createFlist = new FList();
        createFlist.set(FldProgramName.getInst(), "LoadDevicePermitMap");
        createFlist.set(FldName.getInst(), "pin_device_permit_map");
        createFlist.set(FldHostname.getInst(), "-");
        SparseArray devicesArray = new SparseArray();
        for(int i = 0; i < vDevices.size(); i++)
        {
            Device device = (Device)vDevices.elementAt(i);
            ConfigLog.log((new StringBuilder()).append("DeviceType: ").append(device.getDeviceType()).toString());
            FList devicesElem = new FList();
            devicesElem.set(FldDeviceType.getInst(), device.getDeviceType());
            SparseArray permittedsArray = new SparseArray();
            Vector vServices = device.getServices();
            for(int j = 0; j < vServices.size(); j++)
            {
                String service = (String)vServices.elementAt(j);
                ConfigLog.log((new StringBuilder()).append("\tService:").append(service).toString());
                FList permittedElement = new FList();
                permittedElement.set(FldPermitted.getInst(), service);
                permittedsArray.add(permittedElement);
            }

            devicesElem.set(FldPermitteds.getInst(), permittedsArray);
            devicesArray.add(devicesElem);
        }

        createFlist.set(FldDevices.getInst(), devicesArray);
        return createFlist;
    }

    private Vector parseFileVector()
    {
        String sLine = null;
        mLineNum = 1;
        Vector vDeviceList = new Vector();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(mFileName));
            sLine = br.readLine();
            Device dDevice = null;
            for(; sLine != null; sLine = br.readLine())
            {
                sLine = sLine.trim();
                if(!sLine.startsWith("#") && sLine.length() > 0)
                {
                    String sLineType = getLineType(sLine);
                    if(sLineType.equals("DeviceService"))
                    {
                        String sDevice = getDeviceServiceDevice(sLine);
                        String sService = getDeviceServiceService(sLine);
                        if(sDevice != null && sService != null)
                        {
                            if(vDeviceList.size() > 0)
                            {
                                ConfigLog.logAndExit((new StringBuilder()).append("Incorrect Format in configuration file,Only one device allowed, 2nd device detected\nLLine: ").append(mLineNum).append(" ").append(sLine).toString(), -1);
                            } else
                            {
                                dDevice = createDevice(sDevice, vDeviceList);
                                dDevice.addService(sService);
                            }
                        } else
                        {
                            ConfigLog.logAndExit((new StringBuilder()).append("Incorrect Format in configuration file,Device or Service not specified\nLine: ").append(mLineNum).append(" ").append(sLine).toString(), -1);
                        }
                    } else
                    if(sLineType.equals("Service"))
                    {
                        if(dDevice != null)
                        {
                            String sService = getService(sLine);
                            dDevice.addService(sService);
                        } else
                        {
                            ConfigLog.logAndExit((new StringBuilder()).append("Incorrect Format in configuration file,Service found before device\nLine: ").append(mLineNum).append(" ").append(sLine).toString(), -1);
                        }
                    } else
                    {
                        ConfigLog.logAndExit((new StringBuilder()).append("Incorrect Format in configuration file,Invalid Line\nLine: ").append(mLineNum).append(" ").append(sLine).toString(), -1);
                    }
                }
                mLineNum++;
            }

            br.close();
        }
        catch(IOException e)
        {
            ConfigLog.logAndExit((new StringBuilder()).append("IOException e: ").append(e).toString(), -1);
        }
        catch(DuplicateEntryException e)
        {
            ConfigLog.logAndExit((new StringBuilder()).append("Line: ").append(mLineNum).append(": ").append(sLine).append(" Message: ").append(e.getMessage()).toString(), -1);
        }
        return vDeviceList;
    }

    private Device createDevice(String sDevice, Vector vDeviceList)
        throws DuplicateEntryException
    {
        for(int i = 0; i < vDeviceList.size(); i++)
        {
            Device d = (Device)vDeviceList.elementAt(i);
            if(d.getDeviceType().equals(sDevice))
                throw new DuplicateEntryException((new StringBuilder()).append("Duplicate Device: ").append(sDevice).toString());
        }

        Device dDevice = new Device(sDevice);
        vDeviceList.addElement(dDevice);
        return dDevice;
    }

    private String getLineType(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        if(st.countTokens() == 2)
            return "DeviceService";
        if(st.countTokens() == 1)
            return "Service";
        else
            return "ignoreLine";
    }

    private String getDeviceServiceDevice(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        return st.nextToken().trim();
    }

    private String getDeviceServiceService(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        st.nextToken();
        return st.nextToken().trim();
    }

    private String getService(String sLine)
    {
        StringTokenizer st = new StringTokenizer(sLine, ":");
        return st.nextToken().trim();
    }

    public static void main(String args[])
    {
        LoaderOptions options = LoaderOptions.createLoaderOptionsAndExitOnErrorOrHelp(args);
        ConfigLog.init(options);
        DevicePermitMapConfigParser dpmsParser = new DevicePermitMapConfigParser(options);
        Vector vDevices = dpmsParser.parseFileVector();
        for(int i = 0; i < vDevices.size(); i++)
        {
            Device device = (Device)vDevices.elementAt(i);
            ConfigLog.log((new StringBuilder()).append("DeviceType: ").append(device.getDeviceType()).toString());
            Vector vServices = device.getServices();
            for(int j = 0; j < vServices.size(); j++)
            {
                String service = (String)vServices.elementAt(j);
                ConfigLog.log((new StringBuilder()).append("\tService:").append(service).toString());
            }

        }

        System.exit(0);
    }

    private int mLineNum;
    private String mFileName;
}