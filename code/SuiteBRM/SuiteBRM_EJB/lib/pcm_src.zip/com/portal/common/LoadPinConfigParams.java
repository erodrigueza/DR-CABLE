// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoadPinConfigParams.java

package com.portal.common;


public class LoadPinConfigParams
{

    public LoadPinConfigParams(String sObjectName, int nInsertOpcode, int nDeleteOpcode)
    {
        mObjectName = null;
        mInsertOpcode = -1;
        mDeleteOpcode = -1;
        mObjectName = sObjectName;
        mInsertOpcode = nInsertOpcode;
        mDeleteOpcode = nDeleteOpcode;
    }

    public String getObjectName()
    {
        return mObjectName;
    }

    public int getInsertOpcode()
    {
        return mInsertOpcode;
    }

    public int getDeleteOpcode()
    {
        return mDeleteOpcode;
    }

    private String mObjectName;
    private int mInsertOpcode;
    private int mDeleteOpcode;
}