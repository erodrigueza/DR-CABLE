// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ExchangeRate.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Date;

// Referenced classes of package com.portal.common:
//            BEIDManager, BEIDData, CurrencyRateManager

public class ExchangeRate
{

    ExchangeRate(FList curRateFlist, PortalContext connection)
        throws EBufException
    {
        m_CurrencyA = null;
        m_CurrencyB = null;
        m_RateAtoB = null;
        m_OperatorAtoB = null;
        m_RoundingA = null;
        m_RoundingB = null;
        m_StartTime = null;
        m_EndTime = null;
        m_JavaRoundingModeA = null;
        m_JavaRoundingModeB = null;
        try
        {
            SparseArray rateArray = curRateFlist.get(FldAmounts.getInst());
            FList theRate = rateArray.getAnyElement();
            if(theRate == null)
                throw new EBufException(30, curRateFlist);
            m_CurrencyA = theRate.get(FldCurrencySrc.getInst());
            m_CurrencyB = theRate.get(FldCurrencyDst.getInst());
            m_RateAtoB = theRate.get(FldCurrencyRate.getInst());
            m_OperatorAtoB = theRate.get(FldCurrencyOperator.getInst());
            m_StartTime = theRate.get(FldStartT.getInst());
            m_EndTime = theRate.get(FldEndT.getInst());
            if(theRate.hasField(FldRoundingSrc.getInst()))
                m_RoundingA = theRate.get(FldRoundingSrc.getInst());
            if(theRate.hasField(FldRoundingDst.getInst()))
                m_RoundingB = theRate.get(FldRoundingDst.getInst());
            BEIDManager beidMan = BEIDManager.getInstance(connection);
            m_JavaRoundingModeA = beidMan.getData(m_CurrencyA).getJavaRoundingMode();
            m_JavaRoundingModeB = beidMan.getData(m_CurrencyB).getJavaRoundingMode();
        }
        catch(EBufException excptn)
        {
            DefaultLog.log(this, 2, excptn);
            DefaultLog.log(this, 2, (new StringBuilder()).append("ExchangeRate::ctor - Currency rate input Flist.\n").append(curRateFlist.toString()).toString());
            throw excptn;
        }
        logRate();
    }

    public boolean isTimeWithinRange(Date testTime)
    {
        return CurrencyRateManager.isTimeWithinRange(testTime, m_StartTime, m_EndTime);
    }

    public void logRate()
    {
        Object args[] = {
            m_CurrencyA, m_CurrencyB, m_RateAtoB, m_OperatorAtoB, m_RoundingA, m_RoundingB, m_StartTime, m_EndTime
        };
        String formatMsg = new String("Rate:\tSource currency = {0, number, integer}\n\tDest currency = {1, number, integer}\n\tExchange rate = {2, number}\n\tOperator = {3, number, integer}\n\tRoundingA = {4, number, integer}\n\tRoundingB = {5, number, integer}\n\tStart = {6, date} ; {6, time}\n\tEnd = {7, date} ; {7, time}");
        String msg = MessageFormat.format(formatMsg, args);
        DefaultLog.log(this, 8, msg);
    }

    Integer m_CurrencyA;
    Integer m_CurrencyB;
    BigDecimal m_RateAtoB;
    Integer m_OperatorAtoB;
    Integer m_RoundingA;
    Integer m_RoundingB;
    Date m_StartTime;
    Date m_EndTime;
    Integer m_JavaRoundingModeA;
    Integer m_JavaRoundingModeB;
}