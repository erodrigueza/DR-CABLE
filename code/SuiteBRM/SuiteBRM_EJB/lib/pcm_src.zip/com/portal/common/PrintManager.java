// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PrintManager.java

package com.portal.common;

import java.awt.*;
import java.awt.print.*;
import java.io.PrintStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.JTableHeader;

// Referenced classes of package com.portal.common:
//            NullPrintableException, HFPageFormat, PrintableArrayList, PrintPreview, 
//            PreviewPanel

public class PrintManager
{

    public PrintManager()
    {
        this((JComponent)null);
    }

    public PrintManager(JComponent comp)
    {
        dtDisplay = true;
        pnDisplay = true;
        mLeftPageHeader = null;
        mRightPageHeader = null;
        if(comp != null)
            subject = comp;
        initPrintManager();
    }

    public PrintManager(PrintableArrayList aList)
    {
        dtDisplay = true;
        pnDisplay = true;
        mLeftPageHeader = null;
        mRightPageHeader = null;
        if(aList != null)
            subject = aList;
        initPrintManager();
    }

    public void setPageFormat(HFPageFormat pf)
    {
        pageFormat = pf;
    }

    public void setPrintable(JComponent comp)
    {
        if(comp != null)
            subject = comp;
    }

    public void setPrintable(PrintableArrayList aList)
    {
        if(aList != null)
            subject = aList;
    }

    public int getFormattedPagesCount(JComponent jc, PageFormat pf)
    {
        int nPages = 0;
        if((double)jc.getWidth() * pf.getImageableHeight() != 0.0D)
        {
            int compHeight = 0;
            if(jc instanceof JTable)
                compHeight = ((JTable)jc).getTableHeader().getHeight();
            compHeight += jc.getHeight();
            nPages = (int)Math.ceil(((double)compHeight * pf.getImageableWidth()) / ((double)jc.getWidth() * pf.getImageableHeight()));
        }
        return nPages;
    }

    public void executePrinting()
        throws NullPrintableException
    {
        if(subject == null)
            throw new NullPrintableException("Null");
        if(printJob == null)
            printJob = PrinterJob.getPrinterJob();
        if(pageFormat == null)
            pageFormat = new HFPageFormat(printJob.defaultPage());
        if(subject instanceof JComponent)
            printJob.setPageable(createBook((JComponent)subject, pageFormat));
        else
        if(subject instanceof PrintableArrayList)
            printJob.setPrintable((PrintableArrayList)subject, pageFormat);
        boolean ok = printJob.printDialog();
        if(ok)
        {
            Thread printing = new Thread() {

                public void run()
                {
                    try
                    {
                        printJob.print();
                    }
                    catch(Exception pe)
                    {
                        System.out.println("Printing Exception Occured!");
                        pe.printStackTrace();
                    }
                }

                final PrintManager this$0;

            
            {
                this$0 = PrintManager.this;
                super();
            }
            }
;
            printing.start();
        }
    }

    public void executePrinting(JComponent waitComp)
        throws NullPrintableException
    {
        Cursor currentCursor;
        if(subject == null)
            throw new NullPrintableException("Null");
        currentCursor = Cursor.getPredefinedCursor(0);
        if(waitComp == null)
            break MISSING_BLOCK_LABEL_73;
        currentCursor = waitComp.getCursor();
        try
        {
            waitComp.setCursor(Cursor.getPredefinedCursor(3));
            executePrinting();
        }
        catch(Exception e)
        {
            waitComp.setCursor(currentCursor);
            break MISSING_BLOCK_LABEL_77;
        }
        waitComp.setCursor(currentCursor);
        break MISSING_BLOCK_LABEL_77;
        Exception exception;
        exception;
        waitComp.setCursor(currentCursor);
        throw exception;
        executePrinting();
    }

    protected Book createBook(JComponent compToPrint, HFPageFormat pf)
    {
        book = new Book();
        int iPagesCount = getFormattedPagesCount(compToPrint, pf);
        for(int i = 0; i < iPagesCount; i++)
        {
            PrintPreview pvw = new PrintPreview(compToPrint, pf, i);
            book.append(pvw, pf);
        }

        return book;
    }

    public void setLeftPageHeader(String header)
    {
        mLeftPageHeader = header;
        pageFormat.setLeftHeaderText(mLeftPageHeader);
    }

    public void setRightPageHeader(String header)
    {
        mRightPageHeader = header;
        pageFormat.setRightHeaderText(mRightPageHeader);
    }

    public void setDescArray(ArrayList descList)
    {
        pageFormat.setDescArray(descList);
    }

    public void showPageSetup()
    {
        if(printJob == null)
            printJob = PrinterJob.getPrinterJob();
        if(pageFormat == null)
            pageFormat = new HFPageFormat(new HFPageFormat(printJob.defaultPage()));
        pageFormat.setPageFormat(printJob.pageDialog(pageFormat));
        printJob.validatePage(pageFormat);
    }

    public void showPreview()
        throws NullPrintableException
    {
        if(subject == null)
            throw new NullPrintableException("Null");
        if(printJob == null)
            printJob = PrinterJob.getPrinterJob();
        if(pageFormat == null)
            pageFormat = new HFPageFormat(printJob.defaultPage());
        PreviewPanel pvwPanel = null;
        if(subject instanceof JComponent)
            pvwPanel = new PreviewPanel(this, (JComponent)subject, pageFormat, 0);
        else
        if(subject instanceof PrintableArrayList)
            pvwPanel = new PreviewPanel(this, (JComponent)null, pageFormat, 0);
        pvwDialog = new JDialog(previewDialogParent, true);
        pvwDialog.setSize(new Dimension((int)pageFormat.getWidth() + 120, ((int)pageFormat.getHeight() * 5) / 7));
        pvwDialog.getContentPane().add(pvwPanel);
        pvwDialog.show();
        pvwDialog.validate();
    }

    public void showDateAndTime(boolean b)
    {
        dtDisplay = b;
    }

    public void showPageNumbers(boolean b)
    {
        pnDisplay = b;
    }

    public boolean getPageNumbersStatus()
    {
        return pnDisplay;
    }

    public boolean getDateAndTimeStatus()
    {
        return dtDisplay;
    }

    public static String getDateAndTime()
    {
        DateFormat dtF = DateFormat.getDateTimeInstance(3, 1);
        String dt = dtF.format(new Date());
        return dt;
    }

    public void setPreviewDialogParent(JFrame frame)
    {
        if(frame != null)
            previewDialogParent = frame;
    }

    private void initPrintManager()
    {
        setPreviewDialogParent(new JFrame());
        printJob = PrinterJob.getPrinterJob();
        pageFormat = new HFPageFormat(printJob.defaultPage());
    }

    private Object subject;
    private PrinterJob printJob;
    private HFPageFormat pageFormat;
    private boolean dtDisplay;
    private boolean pnDisplay;
    private Book book;
    private JDialog pvwDialog;
    private JFrame previewDialogParent;
    private String mLeftPageHeader;
    private String mRightPageHeader;

}