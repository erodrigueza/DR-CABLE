// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PaymentMethodData.java

package com.portal.common;

import java.io.Serializable;

public class PaymentMethodData
    implements Serializable
{
    public static class OpcodeInfo
        implements Serializable
    {

        public String getEventName()
        {
            return m_EventName;
        }

        public int getFlags()
        {
            return m_Flags;
        }

        public String getOpcodeName()
        {
            return m_OpcodeName;
        }

        public int getOpcode()
        {
            return m_Opcode;
        }

        private String m_EventName;
        private int m_Flags;
        private String m_OpcodeName;
        private int m_Opcode;

        OpcodeInfo(String eventName, int flags, String opcodeName, int opcode)
        {
            m_EventName = null;
            m_Flags = 0;
            m_OpcodeName = null;
            m_Opcode = 0;
            m_EventName = eventName;
            m_Flags = flags;
            m_OpcodeName = opcodeName;
            m_Opcode = opcode;
        }
    }


    PaymentMethodData(int paymentMethodIndex, String payinfoClassName, String paymentEventName, String refundEventName, OpcodeInfo opcodes[])
    {
        m_PaymentMethodIndex = 0;
        m_PayinfoClassName = null;
        m_PaymentEventName = null;
        m_RefundEventName = null;
        m_OpcodeArray = null;
        m_OpcodeArray = new OpcodeInfo[3];
        try
        {
            m_PaymentMethodIndex = paymentMethodIndex;
            m_PayinfoClassName = payinfoClassName;
            m_PaymentEventName = paymentEventName;
            m_RefundEventName = refundEventName;
            m_OpcodeArray[0] = opcodes[0];
            m_OpcodeArray[1] = opcodes[1];
            m_OpcodeArray[2] = opcodes[2];
        }
        catch(Exception excptn)
        {
            m_PaymentMethodIndex = 0;
            m_PayinfoClassName = "";
            m_PaymentEventName = "";
            m_RefundEventName = "";
            m_OpcodeArray[0] = new OpcodeInfo("", 0, "", 0);
            m_OpcodeArray[1] = new OpcodeInfo("", 0, "", 0);
            m_OpcodeArray[2] = new OpcodeInfo("", 0, "", 0);
        }
    }

    public int getPaymentMethodIndex()
    {
        return m_PaymentMethodIndex;
    }

    public String getPayinfoClassName()
    {
        return m_PayinfoClassName;
    }

    public String getPaymentEventName()
    {
        return m_PaymentEventName;
    }

    public String getRefundEventName()
    {
        return m_RefundEventName;
    }

    public OpcodeInfo[] getOpcodeArray()
    {
        return m_OpcodeArray;
    }

    public static final int EVENT_VALIDATE_INDEX = 0;
    public static final int EVENT_CHAGRE_INDEX = 1;
    public static final int EVENT_RECOVER_INDEX = 2;
    private int m_PaymentMethodIndex;
    private String m_PayinfoClassName;
    private String m_PaymentEventName;
    private String m_RefundEventName;
    private OpcodeInfo m_OpcodeArray[];
}