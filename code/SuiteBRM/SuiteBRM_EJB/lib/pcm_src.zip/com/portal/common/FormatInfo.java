// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   PCurrencyFormatter.java

package com.portal.common;

import java.util.*;

class FormatInfo
{

    public FormatInfo(int currencyID)
    {
        String fmtStr = null;
        try
        {
            fmtStr = bundle.getString(Integer.toString(currencyID));
        }
        catch(MissingResourceException mre)
        {
            try
            {
                ResourceBundle bundle2 = ResourceBundle.getBundle("CustomizedResources");
                fmtStr = bundle2.getString(Integer.toString(currencyID));
            }
            catch(MissingResourceException mre2)
            {
                fmtStr = bundle.getString("840");
            }
        }
        initFmtInfo(fmtStr);
    }

    private void initFmtInfo(String fmtStr)
    {
        StringTokenizer strT = new StringTokenizer(fmtStr, ":");
        int count = strT.countTokens();
        try
        {
            mLocalCurrencySymbol = strT.nextToken();
            mInternationalCurrencySymbol = strT.nextToken();
            mGroupSeparator = strT.nextToken().charAt(0);
            mDecimalSeparator = strT.nextToken().charAt(0);
            mFormatPattern = strT.nextToken();
            mFormatPattern = mFormatPattern.replace('M', '\244');
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public String getLocalCurrencySymbol()
    {
        return mLocalCurrencySymbol;
    }

    public String getInternationalCurrencySymbol()
    {
        return mInternationalCurrencySymbol;
    }

    public char getDecimalSeparator()
    {
        return mDecimalSeparator;
    }

    public char getGroupSeparator()
    {
        return mGroupSeparator;
    }

    public String getFormatPattern()
    {
        return mFormatPattern;
    }

    static ResourceBundle bundle = ResourceBundle.getBundle("com.portal.common.CurrencyFormatter");
    private String mLocalCurrencySymbol;
    private String mInternationalCurrencySymbol;
    private char mDecimalSeparator;
    private char mGroupSeparator;
    private String mFormatPattern;

}