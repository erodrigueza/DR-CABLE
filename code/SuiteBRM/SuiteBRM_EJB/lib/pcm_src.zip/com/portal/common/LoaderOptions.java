// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoaderOptions.java

package com.portal.common;

import java.io.PrintStream;

// Referenced classes of package com.portal.common:
//            Options, CommandLineParser

public class LoaderOptions extends Options
{

    public static LoaderOptions createLoaderOptions(String args[])
        throws CommandLineParser.InvalidOptionsException
    {
        return new LoaderOptions(args, null);
    }

    public static LoaderOptions createLoaderOptionsAndExitOnErrorOrHelp(String args[])
    {
        LoaderOptions options = null;
        try
        {
            options = new LoaderOptions(args, null);
            if(options.isHelp())
            {
                System.out.println(options.getHelp());
                System.exit(0);
            }
        }
        catch(CommandLineParser.InvalidOptionsException e)
        {
            System.out.println((new StringBuilder()).append(e.getMessage()).append("\r\n").toString());
            System.out.println(e.getHelp());
            System.exit(1);
        }
        return options;
    }

    protected LoaderOptions(String args[])
        throws CommandLineParser.InvalidOptionsException
    {
        super(args, 0, 1);
        mFileName = null;
        addOptionDef(new Options.FlagOptionDef(this, "-v", getStrFromBundle("option.desc.verbose")));
        addOptionDef(new Options.FlagOptionDef(this, "-d", getStrFromBundle("option.desc.debug")));
    }

    private LoaderOptions(String args[], Object notUsed)
        throws CommandLineParser.InvalidOptionsException
    {
        this(args);
        parse();
    }

    public boolean isDebug()
    {
        return containsOption("-d");
    }

    public boolean isVerbose()
    {
        return containsOption("-v");
    }

    public String getFileName()
    {
        return mFileName;
    }

    protected String getSyntaxHelp()
    {
        return "This program supports the following: [options] <file name>\r\n\r\nwhere <file name> is the file to load the data from.";
    }

    protected void postParse()
        throws CommandLineParser.InvalidOptionsException
    {
        super.postParse();
        try
        {
            mFileName = getTrailingToken(0);
        }
        catch(CommandLineParser.OptionException e)
        {
            throw new CommandLineParser.InvalidOptionsException(this, this, (new StringBuilder()).append("Error in PostParse().\r\n ").append(e.getMessage()).toString());
        }
    }

    public static final String VERBOSE = "-v";
    public static final String DEBUG = "-d";
    private String mFileName;
}