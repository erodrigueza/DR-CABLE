// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   HFPageFormat.java

package com.portal.common;

import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.util.ArrayList;
import javax.swing.UIManager;

public class HFPageFormat extends PageFormat
    implements Printable, Cloneable
{

    public HFPageFormat(PageFormat pf)
    {
        mLeftHeaderText = null;
        mRightHeaderText = null;
        mLeftFooterText = null;
        mRightFooterText = null;
        mDescArray = null;
        mHeaderHeight = 0;
        mFooterHeight = 0;
        mDescAreaHeight = 0;
        setPageFormat(pf);
        mHeaderHeight = LINE_HEIGHT + PADDING;
        mFooterHeight = LINE_HEIGHT + PADDING;
    }

    public void setPageFormat(PageFormat pf)
    {
        setPaper(pf.getPaper());
    }

    public int print(Graphics g, PageFormat format, int pageIndex)
    {
        Graphics2D g2d = (Graphics2D)g.create();
        g2d.setPaint(Color.black);
        paintHeader(g2d, format, pageIndex);
        paintDescriptionArea(g2d, format, pageIndex);
        paintFooter(g2d, format, pageIndex);
        g2d.dispose();
        return 0;
    }

    public Object clone()
    {
        HFPageFormat newPage = (HFPageFormat)super.clone();
        newPage.setLeftHeaderText(mLeftHeaderText);
        newPage.setRightHeaderText(mRightHeaderText);
        newPage.setLeftFooterText(mLeftFooterText);
        newPage.setRightFooterText(mRightFooterText);
        if(mDescArray != null)
            newPage.mDescArray = (ArrayList)mDescArray.clone();
        else
            newPage.mDescArray = null;
        return newPage;
    }

    public double getImageableHeight()
    {
        double imageableHeight = super.getImageableHeight();
        int extraHeight = getHeaderHeight() + getDescAreaHeight() + getFooterHeight();
        return imageableHeight - (double)extraHeight;
    }

    public double getImageableY()
    {
        double imageableY = super.getImageableY();
        int extraHeaderY = getHeaderHeight() + getDescAreaHeight();
        return imageableY + (double)extraHeaderY;
    }

    public int getHeaderHeight()
    {
        if(getLeftHeaderText() == null && getRightHeaderText() == null)
            return 0;
        else
            return mHeaderHeight;
    }

    public int getDescAreaHeight()
    {
        if(getDescArray() == null)
            return 0;
        else
            return mDescAreaHeight;
    }

    public int getFooterHeight()
    {
        if(getLeftHeaderText() == null && getRightHeaderText() == null)
            return 0;
        else
            return mFooterHeight;
    }

    public void setHeaderFont(Font f)
    {
        mHeaderFont = f;
    }

    public void setDescFont(Font f)
    {
        mDescFont = f;
    }

    public void setFooterFont(Font f)
    {
        mFooterFont = f;
    }

    public Font getHeaderFont()
    {
        return mHeaderFont;
    }

    public Font getDescFont()
    {
        return mDescFont;
    }

    public Font getFooterFont()
    {
        return mFooterFont;
    }

    public void setLeftHeaderText(String text)
    {
        mLeftHeaderText = text;
    }

    public void setRightHeaderText(String text)
    {
        mRightHeaderText = text;
    }

    public void setDescArray(ArrayList descList)
    {
        mDescArray = descList;
        if(mDescArray == null)
        {
            mDescAreaHeight = 0;
        } else
        {
            int maxLineHeight = LINE_HEIGHT + LINE_SPACING;
            mDescAreaHeight = maxLineHeight * mDescArray.size() + PADDING;
        }
    }

    public void setLeftFooterText(String text)
    {
        mLeftFooterText = text;
    }

    public void setRightFooterText(String text)
    {
        mRightFooterText = text;
    }

    public String getLeftHeaderText()
    {
        return mLeftHeaderText;
    }

    public String getRightHeaderText()
    {
        return mRightHeaderText;
    }

    public ArrayList getDescArray()
    {
        return mDescArray;
    }

    public String getLeftFooterText()
    {
        return mLeftFooterText;
    }

    public String getRightFooterText()
    {
        return mRightFooterText;
    }

    protected void paintHeader(Graphics g, PageFormat format, int pageIndex)
    {
        if(getLeftHeaderText() == null && getRightHeaderText() == null)
        {
            mHeaderHeight = 0;
            return;
        }
        Graphics2D g2 = (Graphics2D)g.create();
        g2.setFont(getHeaderFont());
        FontMetrics fm = g2.getFontMetrics();
        int maxAscent = fm.getMaxAscent();
        int maxDescent = fm.getMaxDescent();
        mHeaderHeight = maxAscent + maxDescent + PADDING;
        g2.translate(super.getImageableX(), super.getImageableY());
        g2.setClip(0, 0, (int)getImageableWidth(), getHeaderHeight());
        if(getLeftHeaderText() != null)
            g2.drawString(getLeftHeaderText(), 0, maxAscent);
        if(getRightHeaderText() != null)
            g2.drawString(getRightHeaderText(), (int)getImageableWidth() - fm.stringWidth(getRightHeaderText()), maxAscent);
        g2.drawLine(0, maxAscent + maxDescent, (int)getImageableWidth(), maxAscent + maxDescent);
        g2.dispose();
    }

    protected void paintDescriptionArea(Graphics g, PageFormat format, int pageIndex)
    {
        if(mDescArray == null)
        {
            mDescAreaHeight = 0;
            return;
        }
        Graphics2D g2 = (Graphics2D)g.create();
        g2.setFont(getDescFont());
        FontMetrics fm = g2.getFontMetrics();
        int headerHeight = getHeaderHeight();
        int maxLineHeight = fm.getMaxAscent() + fm.getMaxDescent() + LINE_SPACING;
        int size = mDescArray.size();
        mDescAreaHeight = maxLineHeight * size + PADDING;
        g2.translate(super.getImageableX(), super.getImageableY() + (double)getHeaderHeight());
        g2.setClip(0, 0, (int)getImageableWidth(), getDescAreaHeight());
        for(int i = 0; i < size; i++)
            g2.drawString(mDescArray.get(i).toString(), 0, i * maxLineHeight + fm.getMaxAscent());

        g2.dispose();
    }

    protected void paintFooter(Graphics g, PageFormat format, int pageIndex)
    {
        if(getLeftFooterText() == null && getRightFooterText() == null)
        {
            mFooterHeight = 0;
            return;
        }
        Graphics2D g2 = (Graphics2D)g.create();
        g2.setFont(getFooterFont());
        FontMetrics fm = g2.getFontMetrics();
        int maxAscent = fm.getMaxAscent();
        int maxDescent = fm.getMaxDescent();
        mFooterHeight = maxAscent + maxDescent + PADDING;
        double imageableEndY = super.getImageableY() + super.getImageableHeight();
        double footerY = (imageableEndY - (double)getFooterHeight()) + (double)PADDING;
        g2.translate(super.getImageableX(), footerY);
        g2.setClip(0, 0, (int)getImageableWidth(), getFooterHeight());
        g2.drawLine(0, 0, (int)getImageableWidth(), 0);
        if(getLeftFooterText() != null)
            g2.drawString(getLeftFooterText(), 0, maxAscent);
        if(getRightFooterText() != null)
            g2.drawString(getRightFooterText(), (int)getImageableWidth() - fm.stringWidth(getRightFooterText()), maxAscent);
        g2.dispose();
    }

    private String mLeftHeaderText;
    private String mRightHeaderText;
    private String mLeftFooterText;
    private String mRightFooterText;
    private ArrayList mDescArray;
    private static Font mHeaderFont = UIManager.getFont("Label.font");
    private static Font mDescFont = UIManager.getFont("Header.font");
    private static Font mFooterFont = UIManager.getFont("TextArea.font");
    private int mHeaderHeight;
    private int mFooterHeight;
    private int mDescAreaHeight;
    private static int PADDING = 5;
    private static int LINE_SPACING = 1;
    private static int LINE_HEIGHT = 15;

}