// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoadPinConfig.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.util.Enumeration;

// Referenced classes of package com.portal.common:
//            FileParser, LoadPinConfigParams, ConfigLog, LoaderOptions

abstract class LoadPinConfig
{

    public LoadPinConfig(LoaderOptions options)
    {
        mOptions = null;
        mContext = null;
        mOptions = options;
        ConfigLog.init(options);
    }

    public void processConfig(LoadPinConfigParams configParams)
    {
        boolean logout = true;
        try
        {
            ConfigLog.log("before connection open ");
            mContext = new PortalContext();
            mContext.connect();
            ConfigLog.log("connection open ");
            FileParser fileParser = createParser(mOptions);
            if(fileParser != null)
            {
                FList parseFlist = fileParser.parseFile();
                if(parseFlist != null)
                {
                    ConfigLog.log(this, 8, "Parser output  flist:");
                    ConfigLog.log(this, 8, parseFlist.toString());
                    updateInfranet(parseFlist, configParams);
                } else
                {
                    ConfigLog.log("Parser Error: Exiting");
                }
            } else
            {
                ConfigLog.log("Parser Error: Exiting");
            }
            mContext.close(logout);
            ConfigLog.log("connection closed ");
        }
        catch(EBufException ebuf)
        {
            ConfigLog.log(this, 2, ebuf);
        }
    }

    protected abstract FileParser createParser(LoaderOptions loaderoptions);

    protected void updateParseFlist(FList flist, FList flist1)
        throws EBufException
    {
    }

    private void updateInfranet(FList parseFlist, LoadPinConfigParams configParams)
        throws EBufException
    {
        try
        {
            long db_no = mContext.getCurrentDB();
            Poid objPoid = new Poid(db_no, -1L, configParams.getObjectName());
            String template = (new StringBuilder()).append("select X from ").append(configParams.getObjectName()).append(" where ( F1 = V1 and F2 = V2 ) ").toString();
            FList searchFlist = new FList();
            searchFlist.set(FldTemplate.getInst(), template);
            searchFlist.set(FldFlags.getInst(), 0);
            Poid searchPoid = new Poid(db_no, -1L, "/search/pin");
            searchFlist.set(FldPoid.getInst(), searchPoid);
            FList poidInfoElem = new FList();
            poidInfoElem.set(FldPoid.getInst(), objPoid);
            FList readFlist = new FList();
            readFlist.set(FldPoid.getInst(), mContext.getUserID());
            readFlist.set(FldAccountObj.getInst());
            FList readResults = mContext.opcode(4, readFlist);
            ConfigLog.log(this, 8, "Read output flist:");
            ConfigLog.log(this, 8, readResults.toString());
            readResults.dump();
            FList acctInfoElem = new FList();
            acctInfoElem.set(FldAccountObj.getInst(), readResults.get(FldAccountObj.getInst()));
            SparseArray argsArray = new SparseArray();
            argsArray.add(1, poidInfoElem);
            argsArray.add(2, acctInfoElem);
            searchFlist.set(FldArgs.getInst(), argsArray);
            searchFlist.setElement(FldResults.getInst(), 0);
            FList transactionFlist = new FList();
            Poid transactionPoid = new Poid(db_no, 0L, configParams.getObjectName());
            transactionFlist.set(FldPoid.getInst(), transactionPoid);
            FList outFlist = mContext.opcode(12, 0x10000, transactionFlist);
            ConfigLog.log("transaction open ");
            ConfigLog.log(this, 8, "Search input flist:");
            ConfigLog.log(this, 8, searchFlist.toString());
            FList resultFlist = mContext.opcode(7, searchFlist);
            ConfigLog.log(this, 8, "Search output flist:");
            ConfigLog.log(this, 8, resultFlist.toString());
            resultFlist.dump();
            SparseArray array = null;
            if(!resultFlist.isEmpty() && resultFlist.hasField(FldResults.getInst()))
            {
                array = resultFlist.get(FldResults.getInst());
                FList resFlist;
                for(Enumeration valueEnum = array.getValueEnumerator(); valueEnum.hasMoreElements(); ConfigLog.log(this, 8, resFlist.toString()))
                {
                    FList nextflist = (FList)valueEnum.nextElement();
                    ConfigLog.log(this, 8, "delete input flist:");
                    ConfigLog.log(this, 8, nextflist.toString());
                    resFlist = mContext.opcode(configParams.getDeleteOpcode(), nextflist);
                    ConfigLog.log(this, 8, "delete output flist:");
                }

            }
            updateParseFlist(parseFlist, resultFlist);
            parseFlist.set(FldPoid.getInst(), transactionPoid);
            ConfigLog.log(this, 8, "create input flist:");
            ConfigLog.log(this, 8, parseFlist.toString());
            FList createFlist = mContext.opcode(configParams.getInsertOpcode(), parseFlist);
            ConfigLog.log(this, 8, "create output flist:");
            ConfigLog.log(this, 8, createFlist.toString());
            mContext.opcode(14, null);
            ConfigLog.log("transaction committed");
        }
        catch(EBufException ebuf)
        {
            mContext.opcode(13, null);
            ConfigLog.log(this, 2, ebuf);
        }
    }

    protected LoaderOptions mOptions;
    protected PortalContext mContext;
}