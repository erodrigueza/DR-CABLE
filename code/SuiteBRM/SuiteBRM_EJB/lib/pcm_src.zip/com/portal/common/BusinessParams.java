// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:06 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   BusinessParams.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.math.BigDecimal;
import java.util.*;

// Referenced classes of package com.portal.common:
//            InfranetCachedData, BusParamException, Rounding

public class BusinessParams extends InfranetCachedData
{
    private class ParamData
    {

        public Integer getInt()
            throws BusParamException
        {
            try
            {
                return Integer.valueOf(m_ParamValue);
            }
            catch(NumberFormatException e)
            {
                String msg = new String((new StringBuilder()).append("Cannot convert the value '").append(m_ParamValue).append("' for the parameter '").append(m_ParamName).append("' to an Integer").toString());
                if(DefaultLog.doLog(2))
                    DefaultLog.log(this, 2, msg);
                throw new BusParamException(msg, 46);
            }
        }

        public BigDecimal getDecimal()
            throws BusParamException
        {
            try
            {
                return new BigDecimal(m_ParamValue);
            }
            catch(NumberFormatException e)
            {
                String msg = new String((new StringBuilder()).append("Cannot convert the value '").append(m_ParamValue).append("' for the parameter '").append(m_ParamName).append("' to a BigDecimal").toString());
                if(DefaultLog.doLog(2))
                    DefaultLog.log(this, 2, msg);
                throw new BusParamException(msg, 46);
            }
        }

        public String getString()
        {
            return m_ParamValue;
        }

        private String m_ParamName;
        private Integer m_ParamType;
        private String m_paramDesc;
        private String m_ParamValue;
        final BusinessParams this$0;

        public ParamData(String paramName, Integer paramType, String paramDesc, String paramValue)
        {
            this$0 = BusinessParams.this;
            super();
            m_ParamName = null;
            m_ParamType = null;
            m_paramDesc = null;
            m_ParamValue = null;
            m_ParamName = paramName;
            m_ParamType = paramType;
            m_paramDesc = paramDesc;
            m_ParamValue = paramValue;
        }
    }

    private class ParamGroup
    {

        public ParamData getParamData(String paramName)
        {
            return (ParamData)m_ParamMap.get(paramName);
        }

        private String m_GroupName;
        private Hashtable m_ParamMap;
        final BusinessParams this$0;

        public ParamGroup(String groupName, Hashtable paramMap)
        {
            this$0 = BusinessParams.this;
            super();
            m_GroupName = null;
            m_ParamMap = null;
            m_GroupName = groupName;
            m_ParamMap = paramMap;
        }
    }

    private static class BPInstanceBuilder extends InfranetCachedData.InstanceBuilder
    {

        public String getClassName()
        {
            return "com.portal.common.BusinessParams";
        }

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return new BusinessParams(connection);
        }

        private BPInstanceBuilder()
        {
        }

    }


    protected BusinessParams(PortalContext connection)
    {
        super(connection);
        m_GroupMap = null;
        m_GroupMap = new Hashtable(5, 5F);
        readBusinessParameters();
    }

    public static BusinessParams getInstance(PortalContext connection)
    {
        return getInstance(connection, false);
    }

    public static BusinessParams getInstance(PortalContext connection, boolean rebuild)
    {
        return (BusinessParams)getInstanceImpl(connection, rebuild, m_instBuilder);
    }

    public boolean doesParamExist(String groupName, String paramName)
    {
        try
        {
            return getParam(groupName, paramName) != null;
        }
        catch(BusParamException e)
        {
            return false;
        }
    }

    public Integer getInt(String groupName, String paramName)
        throws BusParamException
    {
        ParamData pd = getParam(groupName, paramName);
        return pd.getInt();
    }

    public String getString(String groupName, String paramName)
        throws BusParamException
    {
        ParamData pd = getParam(groupName, paramName);
        return pd.getString();
    }

    public BigDecimal getDecimal(String groupName, String paramName)
        throws BusParamException
    {
        ParamData pd = getParam(groupName, paramName);
        return pd.getDecimal();
    }

    public Date roundTo12AMApplyHourOffset(Date time)
    {
        int offset = 0;
        try
        {
            Integer tmp = getInt("billing", "billing_cycle_offset");
            offset = tmp.intValue();
        }
        catch(BusParamException e)
        {
            DefaultLog.log(this, 2, "Unable to get the billing cycle offset, default to zero");
            DefaultLog.log(this, 2, e);
        }
        return Rounding.roundTo12AMApplyHourOffset(time, offset);
    }

    protected FList searchForConfigObjects()
    {
        FList outFlist = new FList();
        FList inFlist = new FList();
        try
        {
            Poid searchPoid = new Poid(getCurrentDB(), -1L, "/search");
            inFlist.set(FldPoid.getInst(), searchPoid);
            inFlist.set(FldTemplate.getInst(), new String("select X from /config/business_params where F1 = V1 "));
            inFlist.set(FldFlags.getInst(), 0);
            FList argsFlist = new FList();
            Poid objPoid = new Poid(getCurrentDB(), -1L, "/config/business_params");
            inFlist.setElement(FldArgs.getInst(), 1, argsFlist);
            argsFlist.set(FldPoid.getInst(), objPoid);
            inFlist.setElement(FldResults.getInst(), -1);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("BusinessParams::searchForConfigObjects - Search input Flist.\r\n").append(inFlist.toString()).toString());
            outFlist = opcode(7, 0, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("BusinessParams::searchForConfigObjects - Search output Flist.\r\n").append(outFlist.toString()).toString());
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("BusinessParams::searchForConfigObjects - Search input Flist.\r\n").append(inFlist.toString()).toString());
                String tmp = outFlist != null ? outFlist.toString() : "<null flist>\n";
                DefaultLog.log(this, 2, (new StringBuilder()).append("BusinessParams::searchForConfigObjects - Search output Flist.\r\n").append(tmp).toString());
            }
            return null;
        }
        return outFlist;
    }

    protected FList opcode(int op, int flags, FList in)
        throws EBufException
    {
        return m_Connection.opcode(op, flags, in);
    }

    public long getCurrentDB()
    {
        return m_Connection.getCurrentDB();
    }

    private synchronized boolean readBusinessParameters()
    {
        FList outFlist = searchForConfigObjects();
        if(outFlist == null)
        {
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, "BusinessParams::readBusinessParameters - null FList returned!!");
            return false;
        }
        try
        {
            SparseArray resultsArray = outFlist.get(FldResults.getInst());
            Enumeration resultsIterator = resultsArray.getKeyEnumerator();
            if(!resultsIterator.hasMoreElements())
                throw new EBufException(30, outFlist);
            do
            {
                if(!resultsIterator.hasMoreElements())
                    break;
                Integer index = (Integer)resultsIterator.nextElement();
                FList resultFlist = resultsArray.elementAt(index);
                String groupName = resultFlist.get(FldName.getInst());
                SparseArray paramsArray = resultFlist.get(FldParams.getInst());
                Enumeration paramsIterator = paramsArray.getKeyEnumerator();
                if(m_GroupMap.get(groupName) != null)
                {
                    if(DefaultLog.doLog(2))
                        DefaultLog.log(this, 2, (new StringBuilder()).append("BusinessParams::readBusinessParameters - Duplicate parameter group '").append(groupName).append("'will be ignored.\r\n").append(outFlist.toString()).toString());
                } else
                {
                    Hashtable paramMap = new Hashtable(20, 10F);
                    do
                    {
                        if(!paramsIterator.hasMoreElements())
                            break;
                        Integer index1 = (Integer)paramsIterator.nextElement();
                        FList paramFlist = paramsArray.elementAt(index1);
                        String paramName = paramFlist.get(FldParamName.getInst());
                        Integer paramType = paramFlist.get(FldParamType.getInst());
                        String paramDesc = paramFlist.get(FldDescr.getInst());
                        String paramValue = paramFlist.get(FldParamValue.getInst());
                        if(paramMap.get(paramName) != null)
                        {
                            if(DefaultLog.doLog(2))
                                DefaultLog.log(this, 2, (new StringBuilder()).append("BusinessParams::readBusinessParameters - Duplicate parameter '").append(paramName).append("'will be ignored.\r\n").append(resultFlist.toString()).toString());
                        } else
                        {
                            ParamData pData = new ParamData(paramName, paramType, paramDesc, paramValue);
                            paramMap.put(paramName, pData);
                        }
                    } while(true);
                    ParamGroup group = new ParamGroup(groupName, paramMap);
                    m_GroupMap.put(groupName, group);
                }
            } while(true);
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("BusinessParams::readBusinessParameters - EMU Currency search output Flist.\r\n").append(outFlist.toString()).toString());
            }
            return false;
        }
        return true;
    }

    private ParamData getParam(String groupName, String paramName)
        throws BusParamException
    {
        if(groupName == null || paramName == null)
        {
            String msg = new String("Null parameter passed for group name or parameter name");
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, msg);
            throw new BusParamException(msg, 39);
        }
        ParamData pd = null;
        ParamGroup pg = (ParamGroup)m_GroupMap.get(groupName);
        if(pg != null)
            pd = pg.getParamData(paramName);
        if(pg == null || pd == null)
        {
            String msg = new String((new StringBuilder()).append("Cannot find the parameter '").append(paramName).append("' in the group '").append(groupName).append("'").toString());
            if(DefaultLog.doLog(2))
                DefaultLog.log(this, 2, msg);
            throw new BusParamException(msg, 3);
        } else
        {
            return pd;
        }
    }

    public static final String PIN_OBJ_TYPE_BUS_PARAMS = "/config/business_params";
    public static final String BILLING_PARAMS = "billing";
    public static final String BILLING_CYCLE_OFFSET = "billing_cycle_offset";
    public static final String BDOM_BILLING_DIR = "move_day_forward";
    public static final String ENABLE_CORRECTIVE_INVOICES = "enable_corrective_invoices";
    private Hashtable m_GroupMap;
    private static BPInstanceBuilder m_instBuilder = new BPInstanceBuilder();

}