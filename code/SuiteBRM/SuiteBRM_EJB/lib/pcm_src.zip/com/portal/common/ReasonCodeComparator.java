// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ReasonCodeManager.java

package com.portal.common;

import java.util.Comparator;

// Referenced classes of package com.portal.common:
//            ReasonCodeData

class ReasonCodeComparator
    implements Comparator
{

    ReasonCodeComparator()
    {
    }

    public boolean equals(Object obj)
    {
        return obj instanceof ReasonCodeData;
    }

    public int compare(Object obj1, Object obj2)
    {
        if(obj1 != null && obj2 != null)
        {
            int val = obj1.toString().toUpperCase().compareTo(obj2.toString().toUpperCase());
            return val;
        } else
        {
            return -1;
        }
    }
}