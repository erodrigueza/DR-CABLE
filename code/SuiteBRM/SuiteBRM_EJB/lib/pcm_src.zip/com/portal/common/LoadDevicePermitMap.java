// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:08 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   LoadDevicePermitMap.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.util.Enumeration;

// Referenced classes of package com.portal.common:
//            LoadPinConfig, DevicePermitMapConfigParser, LoadPinConfigParams, ConfigLog, 
//            LoaderOptions, FileParser

public class LoadDevicePermitMap extends LoadPinConfig
{

    public LoadDevicePermitMap(LoaderOptions loader)
    {
        super(loader);
    }

    public FileParser createParser(LoaderOptions options)
    {
        return new DevicePermitMapConfigParser(options);
    }

    public void updateParseFlist(FList parseFlist, FList resultFlist)
        throws EBufException
    {
        ConfigLog.log(this, 8, "Original create input flist:");
        ConfigLog.log(this, 8, parseFlist.toString());
        SparseArray parseArray = null;
        parseArray = parseFlist.get(FldDevices.getInst());
        FList arrayElem = parseArray.getAnyElement();
        String newDevice = arrayElem.get(FldDeviceType.getInst());
        FList deviceFlist = null;
        SparseArray resultsArray = null;
        SparseArray devicesArray = null;
        if(!resultFlist.isEmpty() && resultFlist.hasField(FldResults.getInst()))
        {
            resultsArray = resultFlist.get(FldResults.getInst());
            deviceFlist = resultsArray.getAnyElement();
            if(deviceFlist == null)
            {
                ConfigLog.log(this, 8, "No devices in the database");
                return;
            }
            devicesArray = deviceFlist.get(FldDevices.getInst());
        } else
        {
            ConfigLog.log(this, 8, "No devices in the database");
            return;
        }
        String oldDevice = "";
        if(!devicesArray.isEmpty())
        {
            Enumeration valueEnum = devicesArray.getValueEnumerator();
            do
            {
                if(!valueEnum.hasMoreElements())
                    break;
                FList nextflist = (FList)valueEnum.nextElement();
                nextflist.dump();
                oldDevice = nextflist.get(FldDeviceType.getInst());
                if(!oldDevice.equals(newDevice))
                    parseArray.add(nextflist);
            } while(true);
            ConfigLog.log(this, 8, "Modified create input flist for device permit map:");
            ConfigLog.log(this, 8, parseFlist.toString());
        }
    }

    public static void main(String args[])
    {
        LoaderOptions options = LoaderOptions.createLoaderOptionsAndExitOnErrorOrHelp(args);
        LoadDevicePermitMap ldPermitMapConfig = new LoadDevicePermitMap(options);
        ldPermitMapConfig.processConfig(new LoadPinConfigParams("/config/device_permit_map", 1, 2));
    }

    public volatile void processConfig(LoadPinConfigParams x0)
    {
        super.processConfig(x0);
    }
}