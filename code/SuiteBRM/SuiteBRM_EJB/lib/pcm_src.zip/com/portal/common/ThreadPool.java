// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ThreadPool.java

package com.portal.common;


// Referenced classes of package com.portal.common:
//            ProducerConsumerQueue

public class ThreadPool extends ThreadGroup
{
    class PriorityRunnable
    {

        void clear()
        {
            mRun = null;
        }

        Runnable mRun;
        int mPri;
        final ThreadPool this$0;

        PriorityRunnable(Runnable r, int p)
        {
            this$0 = ThreadPool.this;
            super();
            mRun = r;
            mPri = p;
        }
    }

    class PoolThread extends Thread
    {

        public void run()
        {
            Object toRun = null;
label0:
            do
            {
                if(mTimeout == 0L)
                    toRun = mToRun.removeLast();
                else
                    while((toRun = mToRun.removeLast(mTimeout)) == null) 
                        if(doIDie())
                            break label0;
                mOldPri = getPriority();
                try
                {
                    if(toRun instanceof PriorityRunnable)
                    {
                        PriorityRunnable pr = (PriorityRunnable)toRun;
                        setPriority(pr.mPri);
                        pr.mRun.run();
                        pr.clear();
                        setPriority(mOldPri);
                    } else
                    {
                        ((Runnable)toRun).run();
                    }
                }
                catch(Throwable t)
                {
                    t.printStackTrace();
                }
            } while(true);
        }

        int mOldPri;
        final ThreadPool this$0;

        PoolThread(int num)
        {
            this$0 = ThreadPool.this;
            super(ThreadPool.this, (new StringBuilder()).append("PoolThread-").append(num).toString());
            setDaemon(true);
        }
    }


    public ThreadPool()
    {
        this(DEFAULT_MIN_THREADS, DEFAULT_MAX_THREADS, DEFAULT_THREAD_TIME);
    }

    public ThreadPool(int minThreads, int maxThreads, long timeUnused)
    {
        super("ThreadPool Group");
        mToRun = new ProducerConsumerQueue();
        mMin = minThreads;
        mMax = maxThreads;
        mTimeout = timeUnused;
        if(mMin > 0)
        {
            (new PoolThread(0)).start();
            if(mMin > 1)
                mToRun.addFirst(new Runnable() {

                    public void run()
                    {
                        for(int i = 1; i < mMin; i++)
                            (new PoolThread(i)).start();

                    }

                    final ThreadPool this$0;

            
            {
                this$0 = ThreadPool.this;
                super();
            }
                }
);
        }
        mCnt = mMin;
        mName = mMin;
    }

    public synchronized void runThis(Runnable item)
    {
        runThis(item, -1);
    }

    public synchronized void runThis(Runnable item, int pri)
    {
        if(!mToRun.hasWaiters() && mCnt < mMax)
        {
            Thread t = new PoolThread(mName);
            mName++;
            mCnt++;
            t.start();
        }
        if(pri == -1)
        {
            mToRun.addFirst(item);
        } else
        {
            if(pri < 1)
                pri = 1;
            if(pri > 10)
                pri = 1;
            mToRun.addFirst(new PriorityRunnable(item, pri));
        }
    }

    synchronized boolean doIDie()
    {
        if(mCnt == mMin)
        {
            return false;
        } else
        {
            mCnt--;
            return true;
        }
    }

    public static int DEFAULT_MIN_THREADS = 0;
    public static int DEFAULT_MAX_THREADS = 20;
    public static long DEFAULT_THREAD_TIME = 0L;
    private int mMin;
    private int mMax;
    private int mCnt;
    private int mName;
    private long mTimeout;
    private ProducerConsumerQueue mToRun;




}