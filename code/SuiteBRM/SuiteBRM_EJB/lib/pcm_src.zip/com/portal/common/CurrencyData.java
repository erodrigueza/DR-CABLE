// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CurrencyData.java

package com.portal.common;

import java.math.BigDecimal;
import java.util.*;

// Referenced classes of package com.portal.common:
//            BEIDData

public class CurrencyData extends BEIDData
{

    CurrencyData(Integer resourceID, String stringCode, String description, String symbol, Integer status, String statusAsString, Integer rounding, 
            Integer roundingMode, Integer javaRoundingMode, BigDecimal toleranceAmountMin, BigDecimal toleranceAmountMax, BigDecimal tolerancePercent, boolean isEMUCurrency, boolean isEuro)
    {
        super(resourceID, stringCode, description, symbol, status, statusAsString, rounding, roundingMode, javaRoundingMode, toleranceAmountMin, toleranceAmountMax, tolerancePercent);
        m_IsEMUCurrency = false;
        m_IsEuro = false;
        m_IsSecondaryCurrencyRequired = false;
        m_SecondaryCurrencies = new Vector(10, 10);
        m_IsEMUCurrency = isEMUCurrency;
        m_IsEuro = isEuro;
    }

    public boolean isEMUCurrency()
    {
        return m_IsEMUCurrency;
    }

    public boolean isEuro()
    {
        return m_IsEuro;
    }

    public int getNumSecondaryCurrencies()
    {
        return m_SecondaryCurrencies.size();
    }

    public boolean isSecondaryCurrencyRequired()
    {
        return m_IsSecondaryCurrencyRequired;
    }

    public boolean isSecondaryCurrency(int secondaryCurrencyID)
    {
        int index = 0;
        for(int numElements = m_SecondaryCurrencies.size(); index < numElements; index++)
        {
            CurrencyData curData = (CurrencyData)m_SecondaryCurrencies.elementAt(index);
            if(curData.m_ResourceID.intValue() == secondaryCurrencyID)
                return true;
        }

        return false;
    }

    public Enumeration getSecondaryCurrencies()
    {
        Collections.sort(m_SecondaryCurrencies);
        return m_SecondaryCurrencies.elements();
    }

    public static CurrencyData getCurrencyDataNone(String description)
    {
        CurrencyData currencyDataNone = new CurrencyData(new Integer(0), null, description, null, null, null, null, null, null, null, null, null, false, false);
        return currencyDataNone;
    }

    private boolean m_IsEMUCurrency;
    private boolean m_IsEuro;
    boolean m_IsSecondaryCurrencyRequired;
    Vector m_SecondaryCurrencies;
}