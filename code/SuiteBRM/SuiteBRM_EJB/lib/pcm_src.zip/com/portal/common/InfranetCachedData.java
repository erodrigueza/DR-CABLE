// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   InfranetCachedData.java

package com.portal.common;

import com.portal.pcm.DefaultLog;
import com.portal.pcm.PortalContext;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Properties;

public class InfranetCachedData
{
    protected static abstract class InstanceBuilder
    {

        public abstract String getClassName();

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return null;
        }

        public InfranetCachedData createInstanceSimple(Object connection)
        {
            return null;
        }

        protected InstanceBuilder()
        {
        }
    }


    protected InfranetCachedData(PortalContext connection)
    {
        m_Connection = null;
        m_Connection = connection;
    }

    public static synchronized boolean createDataManagers(PortalContext connection, Properties props)
    {
        boolean rtn;
        if(connection == null || props == null)
            return false;
        rtn = false;
        int index;
        int count;
        index = 0;
        count = 0;
_L8:
        String className;
        InfranetCachedData dataMan;
        String propKey = (new StringBuilder()).append("infranet.cached.data.manager.class").append((new Integer(index)).toString()).toString();
        className = props.getProperty(propKey);
        if(className == null)
            break; /* Loop/switch isn't completed */
        String key = buildKey(connection, className);
        dataMan = (InfranetCachedData)m_BrandObjectMap.get(key);
        if(dataMan == null) goto _L2; else goto _L1
_L1:
        count++;
          goto _L3
_L2:
        Class dmClass = null;
        dmClass = Class.forName(className);
          goto _L4
        ClassNotFoundException excptn;
        excptn;
        if(DefaultLog.doLog(2))
        {
            DefaultLog.log(connection, 2, excptn);
            DefaultLog.log(connection, 2, (new StringBuilder()).append("InfranetCachedData::createDataManagers() - Unable to load the class <").append(className.toString()).append(">\n").toString());
        }
          goto _L3
_L4:
        Method getInstMeth = null;
        Class params[] = {
            com/portal/pcm/PortalContext
        };
        getInstMeth = dmClass.getMethod("getInstance", params);
          goto _L5
        Exception excptn;
        excptn;
        if(DefaultLog.doLog(2))
        {
            DefaultLog.log(connection, 2, excptn);
            DefaultLog.log(connection, 2, (new StringBuilder()).append("InfranetCachedData::createDataManagers() - Unable to get the getInstance() method for <").append(className.toString()).append(">\n").toString());
        }
          goto _L3
_L5:
        Object args[] = {
            connection
        };
        dataMan = (InfranetCachedData)getInstMeth.invoke(null, args);
          goto _L6
        args;
        if(DefaultLog.doLog(2))
        {
            DefaultLog.log(connection, 2, ((Throwable) (args)));
            DefaultLog.log(connection, 2, (new StringBuilder()).append("InfranetCachedData::createDataManagers() - Unable to call getInstance() for <").append(className.toString()).append(">\n").toString());
        }
          goto _L3
_L6:
        if(dataMan != null)
            count++;
_L3:
        index++;
        if(true) goto _L8; else goto _L7
_L7:
        rtn = index == count;
        break MISSING_BLOCK_LABEL_370;
        Exception excptn;
        excptn;
        if(DefaultLog.doLog(2))
        {
            DefaultLog.log(connection, 2, excptn);
            DefaultLog.log(connection, 2, "InfranetCachedData::createDataManagers() - Error encountered when creating the data managers.\n");
        }
        return rtn;
    }

    protected static synchronized InfranetCachedData getInstanceImpl(PortalContext connection, boolean rebuild, InstanceBuilder instBuilder)
    {
        String key = buildKey(connection, instBuilder.getClassName());
        InfranetCachedData dataMan = (InfranetCachedData)m_BrandObjectMap.get(key);
        if(dataMan != null && !rebuild)
            return dataMan;
        dataMan = instBuilder.createInstance(connection);
        if(dataMan != null)
            m_BrandObjectMap.put(key, dataMan);
        return dataMan;
    }

    protected static synchronized InfranetCachedData getInstanceImplSimple(Object connection, boolean rebuild, InstanceBuilder instBuilder)
    {
        String key = buildKeySimple(connection, instBuilder.getClassName());
        InfranetCachedData dataMan = (InfranetCachedData)m_BrandObjectMap.get(key);
        if(dataMan != null && !rebuild)
            return dataMan;
        dataMan = instBuilder.createInstanceSimple(connection);
        if(dataMan != null)
            m_BrandObjectMap.put(key, dataMan);
        return dataMan;
    }

    protected static String buildKey(PortalContext connection, String dmClassName)
    {
        return buildKeySimple(connection, dmClassName);
    }

    protected static String buildKeySimple(Object connection, String dmClassName)
    {
        String key = (new StringBuilder()).append(dmClassName).append(":").append(new String("OnlyOneForNow")).toString();
        return key;
    }

    private static Hashtable m_BrandObjectMap = new Hashtable(10, 10F);
    protected PortalContext m_Connection;

}