// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:09 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   SystemDefaultsManager.java

package com.portal.common;

import com.portal.pcm.*;
import com.portal.pcm.fields.*;
import java.util.Enumeration;

// Referenced classes of package com.portal.common:
//            InfranetCachedData, PaymentMethodData, BusinessTypeData

public class SystemDefaultsManager extends InfranetCachedData
{
    private static class SDInstanceBuilder extends InfranetCachedData.InstanceBuilder
    {

        public String getClassName()
        {
            return "com.portal.common.SystemDefaultsManager";
        }

        public InfranetCachedData createInstance(PortalContext connection)
        {
            return new SystemDefaultsManager(connection);
        }

        private SDInstanceBuilder()
        {
        }

    }


    protected SystemDefaultsManager(PortalContext connection)
    {
        super(connection);
        m_PayMethodArray = null;
        m_PrimaryCurrency = null;
        m_SecondaryCurrency = null;
        m_BusinessTypesArray = null;
        getPaymentMethodData();
    }

    public static SystemDefaultsManager getInstance(PortalContext connection)
    {
        return getInstance(connection, false);
    }

    public static SystemDefaultsManager getInstance(PortalContext connection, boolean rebuild)
    {
        return (SystemDefaultsManager)getInstanceImpl(connection, rebuild, m_instBuilder);
    }

    public int getPrimaryCurrency()
    {
        readDefaultsFromRootAccount();
        return m_PrimaryCurrency.intValue();
    }

    public PaymentMethodData[] getPaymentMethodData()
    {
        if(m_PayMethodArray != null)
            return m_PayMethodArray;
        FList inFlist = new FList();
        FList outFlist = null;
        try
        {
            Poid searchPoid = new Poid(m_Connection.getCurrentDB(), 500L, "/search");
            inFlist.set(FldPoid.getInst(), searchPoid);
            FList argsFlist = new FList();
            Poid configPaymentPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/config/payment");
            argsFlist.set(FldPoid.getInst(), configPaymentPoid);
            inFlist.setElement(FldArgs.getInst(), 1, argsFlist);
            inFlist.setElement(FldResults.getInst(), -1);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("SystemDefaultsManager::getPaymentMethodData - Search input Flist.\n").append(inFlist.toString()).toString());
            outFlist = m_Connection.opcode(7, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("SystemDefaultsManager::getPaymentMethodData - Search output Flist.\n").append(outFlist.toString()).toString());
            SparseArray resultsArray = outFlist.get(FldResults.getInst());
            FList resultFlist = resultsArray.getAnyElement();
            if(resultFlist == null)
                throw new EBufException(30, outFlist);
            SparseArray methodDataArray = resultFlist.get(FldPayTypes.getInst());
            Enumeration paymentMethodIterator = methodDataArray.getKeyEnumerator();
            m_PayMethodArray = new PaymentMethodData[methodDataArray.getSize()];
            for(int index = 0; paymentMethodIterator.hasMoreElements(); index++)
            {
                Integer paymentMethodID = (Integer)paymentMethodIterator.nextElement();
                FList payMethFlist = methodDataArray.elementAt(paymentMethodID);
                String payinfoClassName = payMethFlist.get(FldPayinfoType.getInst());
                String paymentEventName = payMethFlist.get(FldPaymentEventType.getInst());
                String refundEventName = payMethFlist.get(FldRefundEventType.getInst());
                PaymentMethodData.OpcodeInfo opcodes[] = new PaymentMethodData.OpcodeInfo[3];
                for(int index2 = 0; index2 < 3; index2++)
                {
                    FList opcodeFlist = payMethFlist.getElement(FldOpcodes.getInst(), index2);
                    String eventName = opcodeFlist.get(FldEventType.getInst());
                    Integer flags = opcodeFlist.get(FldFlags.getInst());
                    String opcodeName = opcodeFlist.get(FldName.getInst());
                    Integer opcode = opcodeFlist.get(FldOpcode.getInst());
                    opcodes[index2] = new PaymentMethodData.OpcodeInfo(eventName, flags.intValue(), opcodeName, opcode.intValue());
                }

                PaymentMethodData data = new PaymentMethodData(paymentMethodID.intValue(), payinfoClassName, paymentEventName, refundEventName, opcodes);
                m_PayMethodArray[index] = data;
            }

        }
        catch(EBufException excptn)
        {
            String strOutFlist = outFlist != null ? outFlist.toString() : "<null Flist>";
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("SystemDefaultsManager::getPaymentMethodData - Payment Method info input Flist.\n").append(inFlist.toString()).toString());
                DefaultLog.log(this, 2, (new StringBuilder()).append("SystemDefaultsManager::getPaymentMethodData - Payment Method info output Flist.\n").append(strOutFlist).toString());
            }
            m_PayMethodArray = new PaymentMethodData[0];
        }
        return m_PayMethodArray;
    }

    public int[] getPaymentMethodIndicies()
    {
        PaymentMethodData paymentMethodData[] = getPaymentMethodData();
        int count = paymentMethodData.length;
        int paymentMethodIndicies[] = new int[count];
        for(int index = 0; index < count; index++)
            paymentMethodIndicies[index] = paymentMethodData[index].getPaymentMethodIndex();

        return paymentMethodIndicies;
    }

    public BusinessTypeData[] getBusinessTypes()
    {
        if(m_BusinessTypesArray != null)
            return m_BusinessTypesArray;
        FList inFlist = new FList();
        FList outFlist = null;
        try
        {
            Poid searchPoid = new Poid(m_Connection.getCurrentDB(), 500L, "/search");
            inFlist.set(FldPoid.getInst(), searchPoid);
            FList argsFlist = new FList();
            Poid objPoid = new Poid(m_Connection.getCurrentDB(), -1L, "/config/business_type");
            argsFlist.set(FldPoid.getInst(), objPoid);
            inFlist.setElement(FldArgs.getInst(), 1, argsFlist);
            inFlist.setElement(FldResults.getInst(), -1);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("SystemDefaultsManager::getBusinessTypes - Search input Flist.\n").append(inFlist.toString()).toString());
            outFlist = m_Connection.opcode(7, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("SystemDefaultsManager::getBusinessTypes - Search output Flist.\n").append(outFlist.toString()).toString());
            SparseArray resultsArray = outFlist.get(FldResults.getInst());
            FList theResult = resultsArray.getAnyElement();
            if(theResult == null)
                throw new EBufException(30, outFlist);
            if(theResult.hasField(FldBusinessTypeArray.getInst()))
            {
                SparseArray businessTypes = theResult.get(FldBusinessTypeArray.getInst());
                Enumeration businessTypesIterator = businessTypes.getKeyEnumerator();
                m_BusinessTypesArray = new BusinessTypeData[businessTypes.getSize()];
                for(int i = 0; businessTypesIterator.hasMoreElements(); i++)
                {
                    Integer businessTypeID = (Integer)businessTypesIterator.nextElement();
                    FList businessTypeFlist = businessTypes.elementAt(businessTypeID);
                    String businessTypeDesc = businessTypeFlist.get(FldDescr.getInst());
                    BusinessTypeData data = new BusinessTypeData(businessTypeID.intValue(), businessTypeDesc);
                    m_BusinessTypesArray[i] = data;
                }

            }
        }
        catch(EBufException ebe)
        {
            if(DefaultLog.doLog(2))
            {
                DefaultLog.log(this, 2, ebe);
                DefaultLog.log(this, 2, (new StringBuilder()).append("SystemDefaultsManager::getBusinessTypes - Search input Flist.\n").append(inFlist.toString()).toString());
                String tmp = outFlist != null ? outFlist.toString() : "<null flist>\n";
                DefaultLog.log(this, 2, (new StringBuilder()).append("SystemDefaultsManager::getBusinessTypes - Search output Flist.\n").append(tmp).toString());
            }
            m_BusinessTypesArray = null;
        }
        return m_BusinessTypesArray;
    }

    private void readDefaultsFromRootAccount()
    {
        if(m_PrimaryCurrency != null)
            return;
        FList inFlist = new FList();
        FList outFlist = null;
        try
        {
            Poid rootAcctPoid = new Poid(m_Connection.getCurrentDB(), 1L, "/account");
            inFlist.set(FldPoid.getInst(), rootAcctPoid);
            Integer tmp = new Integer(0);
            inFlist.set(FldCurrency.getInst(), tmp);
            inFlist.set(FldCurrencySecondary.getInst(), tmp);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("SystemDefaultsManager::readDefaultsFromRootAccount - Search input Flist.\n").append(inFlist.toString()).toString());
            outFlist = m_Connection.opcode(4, inFlist);
            if(DefaultLog.doLog(8))
                DefaultLog.log(this, 8, (new StringBuilder()).append("SystemDefaultsManager::readDefaultsFromRootAccount - Search output Flist.\n").append(outFlist.toString()).toString());
            m_PrimaryCurrency = outFlist.get(FldCurrency.getInst());
            m_SecondaryCurrency = outFlist.get(FldCurrencySecondary.getInst());
        }
        catch(EBufException excptn)
        {
            if(DefaultLog.doLog(2))
            {
                String strOutFlist = outFlist != null ? outFlist.toString() : "<null Flist>";
                DefaultLog.log(this, 2, excptn);
                DefaultLog.log(this, 2, (new StringBuilder()).append("SystemDefaultsManager::readDefaultsFromRootAccount - Payment Method info input Flist.\n").append(inFlist.toString()).toString());
                DefaultLog.log(this, 2, (new StringBuilder()).append("SystemDefaultsManager::readDefaultsFromRootAccount - Payment Method info output Flist.\n").append(strOutFlist).toString());
            }
            m_PrimaryCurrency = new Integer(0);
            m_SecondaryCurrency = new Integer(0);
        }
    }

    private static SDInstanceBuilder m_instBuilder = new SDInstanceBuilder();
    private PaymentMethodData m_PayMethodArray[];
    private Integer m_PrimaryCurrency;
    private Integer m_SecondaryCurrency;
    private BusinessTypeData m_BusinessTypesArray[];

}