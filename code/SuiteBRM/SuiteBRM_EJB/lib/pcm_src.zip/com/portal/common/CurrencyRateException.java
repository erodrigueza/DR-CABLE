// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 15/08/2012 01:39:07 p.m.
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CurrencyRateException.java

package com.portal.common;

import com.portal.pcm.EBufException;
import com.portal.pcm.PortalException;
import java.util.Date;

public class CurrencyRateException extends PortalException
{

    public CurrencyRateException(int srcCurrencyID, int destCurrencyID, Date transactionDate, EBufException ebufExcptn, int reasonCode)
    {
        super("");
        m_SrcCurID = 0;
        m_DestCurID = 0;
        m_TransDate = null;
        m_EBufExcptn = null;
        m_ReasonCode = 0;
        m_SrcCurID = srcCurrencyID;
        m_DestCurID = destCurrencyID;
        m_TransDate = transactionDate;
        m_EBufExcptn = ebufExcptn;
        m_ReasonCode = reasonCode;
    }

    public int getSrcCurI()
    {
        return m_SrcCurID;
    }

    public int getDestCurID()
    {
        return m_DestCurID;
    }

    public Date getTransDate()
    {
        return m_TransDate;
    }

    public EBufException getEBufException()
    {
        return m_EBufExcptn;
    }

    public int getReason()
    {
        return m_ReasonCode;
    }

    public static final int RATE_NOT_FOUND = 500;
    public static final int RATE_CANNOT_BE_PARSED = 501;
    private int m_SrcCurID;
    private int m_DestCurID;
    private Date m_TransDate;
    private EBufException m_EBufExcptn;
    private int m_ReasonCode;
}